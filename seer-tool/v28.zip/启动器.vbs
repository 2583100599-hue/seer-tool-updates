Option Explicit

Dim fso, shell, baseDir, mainPy, pythonExe
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

baseDir = fso.GetParentFolderName(WScript.ScriptFullName)
mainPy = fso.BuildPath(baseDir, "main.py")

pythonExe = FindPython(shell, fso)

If pythonExe = "" Then
    MsgBox "Python 3.10-3.13 was not found." & vbCrLf & vbCrLf & _
           "Install Python and PySide6, then run this launcher again.", _
           vbCritical, "Handle Login Tool"
    WScript.Quit 1
End If

shell.CurrentDirectory = baseDir
shell.Run Quote(pythonExe) & " " & Quote(mainPy), 0, False

Set shell = Nothing
Set fso = Nothing

Function Quote(ByVal s)
    Quote = Chr(34) & s & Chr(34)
End Function

Function FindPython(ByVal sh, ByVal fs)
    Dim env, pathValue, parts, i, p, candidates, j
    FindPython = ""

    Set env = sh.Environment("Process")
    pathValue = env("PATH")
    parts = Split(pathValue, ";")

    ' PATH: prefer pythonw, then pyw, then python/py.
    For i = 0 To UBound(parts)
        p = Trim(parts(i))
        If p <> "" Then
            If fs.FileExists(fs.BuildPath(p, "pythonw.exe")) Then FindPython = fs.BuildPath(p, "pythonw.exe"): Exit Function
            If fs.FileExists(fs.BuildPath(p, "pyw.exe")) Then FindPython = fs.BuildPath(p, "pyw.exe"): Exit Function
            If fs.FileExists(fs.BuildPath(p, "python.exe")) Then FindPython = fs.BuildPath(p, "python.exe"): Exit Function
            If fs.FileExists(fs.BuildPath(p, "py.exe")) Then FindPython = fs.BuildPath(p, "py.exe"): Exit Function
        End If
    Next

    candidates = Array( _
        sh.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python313\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python312\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python311\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python310\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%ProgramFiles%\Python313\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%ProgramFiles%\Python312\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%ProgramFiles%\Python311\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%ProgramFiles%\Python310\pythonw.exe"), _
        sh.ExpandEnvironmentStrings("%WINDIR%\pyw.exe"), _
        sh.ExpandEnvironmentStrings("%WINDIR%\py.exe") _
    )

    For j = 0 To UBound(candidates)
        If fs.FileExists(candidates(j)) Then FindPython = candidates(j): Exit Function
    Next
End Function
