import json, os, csv, time, threading
from pathlib import Path
from datetime import datetime
from PySide6.QtCore import Qt, QObject, QDateTime, QTimer, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QPushButton,
    QLineEdit, QComboBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QCheckBox, QTextEdit, QMessageBox, QSpinBox, QDateTimeEdit, QGroupBox,
    QAbstractItemView, QFileDialog, QDialogButtonBox
)

class ConditionBuilderDialog(QDialog):
    """可视化 AND/OR/NOT 条件编辑器，输出兼容 WorkflowEngine 的 JSON。"""
    def __init__(self, parent=None, logic=None):
        super().__init__(parent); self.setWindowTitle('可视化条件编辑器'); self.resize(760, 520)
        self.logic = logic if isinstance(logic, dict) else {'op':'and','items':[]}
        lay=QVBoxLayout(self); lay.addWidget(QLabel('构建条件：支持 AND / OR / NOT；每行是一个基础条件。'))
        top=QHBoxLayout(); top.addWidget(QLabel('组合方式：')); self.op=QComboBox(); self.op.addItems(['AND','OR','NOT']); self.op.setCurrentText(str(self.logic.get('op','and')).upper()); top.addWidget(self.op); top.addStretch(); lay.addLayout(top)
        self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['条件类型','目标句柄','关键字/文字','窗口标题','ClassName','删除']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); lay.addWidget(self.table)
        bar=QHBoxLayout(); add=QPushButton('＋ 添加条件'); add.clicked.connect(self.add_row); bar.addWidget(add); bar.addStretch(); lay.addLayout(bar)
        bb=QHBoxLayout(); ok=QPushButton('确定'); cancel=QPushButton('取消'); ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject); bb.addStretch(); bb.addWidget(ok); bb.addWidget(cancel); lay.addLayout(bb)
        items=self.logic.get('items',[]) if self.logic.get('op')!='not' else [self.logic.get('item',{})]
        for x in items: self.add_row(x)
        if not items: self.add_row()
    def add_row(self, node=None):
        r=self.table.rowCount(); self.table.insertRow(r)
        c=QComboBox(); choices=[('文字包含关键字','keyword_contains'),('文字不包含关键字','keyword_not_contains'),('文字完全等于','text_equals'),('文字不等于','text_not_equals'),('文字非空','text_not_empty'),('句柄存在','handle_exists'),('句柄可见','handle_visible'),('句柄已启用','handle_enabled'),('窗口存在','window_exists'),('窗口不存在','window_not_exists')]
        for a,b in choices:c.addItem(a,b)
        node=node or {}; typ=node.get('condition','keyword_contains')
        for i in range(c.count()):
            if c.itemData(i)==typ:c.setCurrentIndex(i);break
        self.table.setCellWidget(r,0,c)
        t=QLineEdit(str(node.get('target',''))); self.table.setCellWidget(r,1,t)
        k=QLineEdit(str(node.get('keyword',node.get('expected','')))); self.table.setCellWidget(r,2,k)
        d=QPushButton('删除'); d.clicked.connect(lambda _,row=r:self.remove_row(row)); self.table.setCellWidget(r,5,d)
    def remove_row(self,row):
        # 不依赖创建按钮时捕获的旧行号；删除上一行后，后面的行会移动。
        btn = self.sender()
        if btn is not None:
            for r in range(self.table.rowCount()):
                if self.table.cellWidget(r, 5) is btn:
                    row = r
                    break
        if 0<=row<self.table.rowCount():
            self.table.removeRow(row)
    def get_logic(self):
        op=self.op.currentText().lower(); items=[]
        for r in range(self.table.rowCount()):
            c=self.table.cellWidget(r,0); t=self.table.cellWidget(r,1); k=self.table.cellWidget(r,2); tt=self.table.cellWidget(r,3); cls=self.table.cellWidget(r,4)
            if not c: continue
            node={'condition':c.currentData(),'target':t.text().strip(),'keyword':k.text(),'title':tt.text().strip(),'class_name':cls.text().strip()}
            items.append(node)
        if op=='not': return {'op':'not','item':items[0] if items else {'condition':'text_not_empty','target':''}}
        return {'op':op,'items':items}

class DebuggerSignals(QObject):
    log = Signal(str)
    step_finished = Signal(int, bool, str)


class DebuggerDialog(QDialog):
    """单步调试器：步骤在工作线程执行，断点前暂停并通过信号安全刷新界面。"""
    def __init__(self,parent,workflow,account,exe,ProcessManager,WorkflowEngine):
        super().__init__(parent)
        self.setWindowTitle('工作流单步调试器 · 断点/变量监视')
        self.resize(1100,700)
        self.workflow=workflow; self.account=account; self.exe=exe; self.PM=ProcessManager; self.Engine=WorkflowEngine
        self.pm=None; self.pid=None; self.idx=0
        self.engine=WorkflowEngine(); self.breaks=set(); self.started=False
        self.signals = DebuggerSignals(self)
        self.signals.log.connect(self.log)
        self.signals.step_finished.connect(self._on_step_finished)
        self.engine.logger=lambda m:self.signals.log.emit(str(m))
        self._continuing=False
        self._ignore_current_breakpoint_once=False
        self._paused_at_breakpoint=False
        self._step_in_flight=False
        self._stop_requested=False
        self._close_after_stop=False
        self._step_thread=None
        lay=QVBoxLayout(self)
        head=QHBoxLayout(); head.addWidget(QLabel(f'账号：{account.account}'))
        self.step_label=QLabel('步骤：0 / %d'%len(workflow.get('steps',[]))); head.addWidget(self.step_label); head.addStretch(); lay.addLayout(head)
        self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(['步骤','操作','启用','断点','摘要']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); lay.addWidget(self.table)
        self.refresh_steps()
        ctl=QHBoxLayout(); self.start_btn=QPushButton('启动软件并进入调试'); self.start_btn.clicked.connect(self.start_debug)
        self.prev=QPushButton('上一步'); self.next=QPushButton('⏭ 执行下一步'); self.cont=QPushButton('▶ 继续到断点'); self.stop=QPushButton('停止调试')
        for b in (self.prev,self.next,self.cont,self.stop): b.setEnabled(False)
        self.next.clicked.connect(self.next_step); self.cont.clicked.connect(self.continue_run); self.prev.clicked.connect(self.prev_step); self.stop.clicked.connect(self.stop_debug)
        ctl.addWidget(self.start_btn); ctl.addWidget(self.prev); ctl.addWidget(self.next); ctl.addWidget(self.cont); ctl.addWidget(self.stop); lay.addLayout(ctl)
        split=QHBoxLayout(); self.vars=QTextEdit(); self.vars.setReadOnly(True); self.vars.setPlaceholderText('实时变量 / 句柄'); self.logbox=QTextEdit(); self.logbox.setReadOnly(True); split.addWidget(self.vars,1); split.addWidget(self.logbox,2); lay.addLayout(split)

    def refresh_steps(self):
        labels={
            'wait':'等待几秒','check_keyword':'检测句柄内是否有关键字','wait_keyword':'等待直到关键字出现','wait_condition':'等待直到条件满足',
            'if_condition':'条件判断 IF / ELSE','find_window':'查找主窗口','find_child':'查找窗口内的控件','set_text':'输入文字',
            'click':'点击按钮/控件','send_key':'发送键盘按键','close_window':'关闭窗口','if_window_exists':'如果窗口存在则执行',
            'set_variable':'设置工作流变量','set_status':'更新账号状态','log':'写入运行日志'
        }
        self.table.setRowCount(0)
        for i,s in enumerate(self.workflow.get('steps',[])):
            r=self.table.rowCount(); self.table.insertRow(r); self.table.setItem(r,0,QTableWidgetItem(str(i+1)))
            action=str(s.get('action','')); self.table.setItem(r,1,QTableWidgetItem(labels.get(action,action)))
            self.table.setItem(r,2,QTableWidgetItem('是' if s.get('enabled',True) else '否'))
            cb=QCheckBox(); cb.setChecked(i in self.breaks); cb.stateChanged.connect(lambda st,ix=i:self.toggle_break(ix,st)); self.table.setCellWidget(r,3,cb)
            summary=json.dumps({k:v for k,v in s.items() if k not in ('then','else')},ensure_ascii=False)[:180]
            if s.get('remark'): summary='备注：'+str(s.get('remark'))+' ｜ '+summary
            self.table.setItem(r,4,QTableWidgetItem(summary))

    def toggle_break(self,i,st):
        (self.breaks.add(i) if st else self.breaks.discard(i))
        if not st and i == self.idx:
            self._paused_at_breakpoint = False

    def log(self,m):
        self.logbox.append(str(m))

    def start_debug(self):
        try:
            self.pm=self.PM(); self.pid=self.pm.start(self.exe); self.engine.stop_event.clear(); self.engine.resume()
            self.engine.handles={}; self.engine.handle_specs={}; self.engine.variables={}
            self.engine.runtime_context={'run_no':1,'total':1,'step':0,'step_count':len(self.workflow.get('steps',[])),'last_text':'','status':''}
            self.idx=0; self.started=True; self._continuing=False
            self._ignore_current_breakpoint_once=False; self._paused_at_breakpoint=False
            self._stop_requested=False; self._close_after_stop=False; self._step_in_flight=False
            self.next.setEnabled(True); self.cont.setEnabled(True); self.prev.setEnabled(False); self.stop.setEnabled(True); self.start_btn.setEnabled(False)
            self.log(f'调试实例已启动，PID={self.pid}。请注意：步骤会真实操作该独立软件实例。')
            self.refresh_state()
        except Exception as e:
            try:
                if self.pm: self.pm.stop()
            except Exception: pass
            self.pm=None; self.pid=None
            QMessageBox.critical(self,'启动调试失败',str(e))

    def next_step(self):
        """手动执行当前一步；手动单步会有意越过当前步的断点。"""
        if not self.started or self._step_in_flight or self.idx>=len(self.workflow.get('steps',[])):
            return
        self._continuing=False
        self._ignore_current_breakpoint_once=False
        self._paused_at_breakpoint=False
        self._execute_current_step()

    def _execute_current_step(self):
        if not self.started or self._step_in_flight or self.idx>=len(self.workflow.get('steps',[])):
            self._continuing=False
            self._restore_debug_controls()
            return
        current=self.idx
        step=self.workflow['steps'][current]
        self.engine.runtime_context['step']=current+1
        if step.get('enabled',True) is False:
            self.log(f'步骤 {current+1} 已禁用，跳过')
            self.idx+=1
            self.refresh_state()
            if self.idx>=len(self.workflow.get('steps',[])):
                self._continuing=False
                self.log('已到达工作流末尾。')
                self._restore_debug_controls()
            elif self._continuing:
                QTimer.singleShot(0, self._continue_tick)
            else:
                self._restore_debug_controls()
            return
        self._step_in_flight=True
        self._restore_debug_controls()
        self.log(f'--- 执行步骤 {current+1}：{step.get("action")} ---')
        self._step_thread=threading.Thread(
            target=self._run_step_worker, args=(current, step), daemon=True,
            name=f'WorkflowDebuggerStep-{current+1}'
        )
        self._step_thread.start()

    def _run_step_worker(self, current, step):
        try:
            self.engine.run_step(step, self.account, self.pid)
            self.signals.step_finished.emit(current, True, '')
        except Exception as exc:
            self.signals.step_finished.emit(current, False, f'{type(exc).__name__}: {exc}')

    def _on_step_finished(self, current, success, error):
        self._step_in_flight=False
        self._step_thread=None
        if self._stop_requested:
            self._finalize_stop()
            if self._close_after_stop:
                QTimer.singleShot(0, self.close)
            return
        if success:
            self.log(f'步骤 {current+1} 执行完成')
        else:
            self.log(f'步骤 {current+1} 执行失败：{error}')
        if self.idx == current:
            self.idx += 1
        self.refresh_state()
        if self.idx>=len(self.workflow.get('steps',[])):
            self._continuing=False
            self.log('已到达工作流末尾。')
            self._restore_debug_controls()
        elif self._continuing:
            # 每一步在工作线程执行；完成后才排入下一步，UI 线程不会被 wait/Win32 调用占住。
            QTimer.singleShot(0, self._continue_tick)
        else:
            self._restore_debug_controls()

    def continue_run(self):
        if not self.started or self._step_in_flight or self.idx>=len(self.workflow.get('steps',[])):
            return
        self._continuing=True
        # 只有真正停在断点时再次继续，才允许越过当前断点一次。
        self._ignore_current_breakpoint_once = self._paused_at_breakpoint and self.idx in self.breaks
        self._paused_at_breakpoint=False
        self.cont.setEnabled(False); self.next.setEnabled(False); self.prev.setEnabled(False)
        self.log('开始继续执行；每步在工作线程运行，命中下一个断点时暂停。')
        QTimer.singleShot(0, self._continue_tick)

    def _continue_tick(self):
        if not self._continuing or not self.started:
            self._restore_debug_controls(); return
        if self._step_in_flight:
            return
        if self.idx>=len(self.workflow.get('steps',[])):
            self._continuing=False; self._restore_debug_controls(); return
        if self.idx in self.breaks:
            if self._ignore_current_breakpoint_once:
                self._ignore_current_breakpoint_once=False
            else:
                self._continuing=False
                self._paused_at_breakpoint=True
                self.log(f'命中断点：第 {self.idx+1} 步（尚未执行该步骤）')
                self._restore_debug_controls()
                self.refresh_state()
                return
        self._execute_current_step()

    def _restore_debug_controls(self):
        active=self.started and not self._step_in_flight and not self._stop_requested
        self.next.setEnabled(active and self.idx<len(self.workflow.get('steps',[])))
        self.cont.setEnabled(active and self.idx<len(self.workflow.get('steps',[])))
        self.prev.setEnabled(active and self.idx>0)
        self.stop.setEnabled(self.started or self._step_in_flight)

    def prev_step(self):
        if not self.started or self._step_in_flight:
            return
        self._continuing=False
        self._ignore_current_breakpoint_once=False
        self._paused_at_breakpoint=False
        self.log('“上一步”仅回退调试列表位置，不会撤销已经对目标软件执行的操作；再次执行可能重复产生实际操作。')
        self.idx=max(0,self.idx-1); self.refresh_state(); self._restore_debug_controls()

    def stop_debug(self):
        if self._step_in_flight:
            if not self._stop_requested:
                self._stop_requested=True
                self._continuing=False
                self.engine.stop()
                self.engine.resume()
                self.next.setEnabled(False); self.cont.setEnabled(False); self.prev.setEnabled(False); self.stop.setEnabled(False)
                self.log('已请求停止；当前步骤返回后将关闭调试实例。')
            return
        self._continuing=False; self._ignore_current_breakpoint_once=False; self._paused_at_breakpoint=False
        self._finalize_stop()

    def _finalize_stop(self):
        try:
            if self.pm: self.pm.stop()
        except Exception as e:
            self.log(f'停止调试实例时出现提示：{type(e).__name__}: {e}')
        self.pm=None; self.pid=None; self.started=False
        self._continuing=False; self._stop_requested=False; self._ignore_current_breakpoint_once=False; self._paused_at_breakpoint=False
        self.start_btn.setEnabled(True)
        self._restore_debug_controls()
        self.log('调试已停止。再次启动会创建新的独立软件实例。')

    def refresh_state(self):
        total=len(self.workflow.get('steps',[]))
        self.step_label.setText(f'步骤：{self.idx} / {total}')
        self.vars.setPlainText(json.dumps({'runtime_context':self.engine.runtime_context,'variables':self.engine.variables,'handles':{k:f'0x{int(v):X}' for k,v in self.engine.handles.items()}},ensure_ascii=False,indent=2))
        if self.table.rowCount():
            self.table.clearSelection()
            if self.idx<self.table.rowCount():
                self.table.selectRow(self.idx)
        if self._continuing:
            self.next.setEnabled(False); self.cont.setEnabled(False); self.prev.setEnabled(False)
            self.stop.setEnabled(True)
        else:
            self._restore_debug_controls()

    def closeEvent(self,event):
        self._continuing=False
        self._paused_at_breakpoint=False
        if self._step_in_flight:
            self._close_after_stop=True
            self.stop_debug()
            event.ignore()
            return
        try:
            if self.pm: self.pm.stop()
        except Exception: pass
        self.pm=None; self.pid=None; self.started=False
        super().closeEvent(event)

class LogCenterDialog(QDialog):
    def __init__(self,parent,history):
        super().__init__(parent); self.setWindowTitle('日志中心 / 运行报告'); self.resize(1050,650); self.history=history or []
        lay=QVBoxLayout(self); bar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('搜索账号、工作流、结果、错误信息…'); self.search.textChanged.connect(self.refresh); bar.addWidget(self.search,1); exp=QPushButton('导出报告'); exp.clicked.connect(self.export); bar.addWidget(exp); lay.addLayout(bar)
        self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(['时间','账号','工作流','结果','PID','失败步骤','信息']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); lay.addWidget(self.table); self.summary=QLabel(); lay.addWidget(self.summary); self.refresh()
    def refresh(self):
        q=self.search.text().lower().strip(); rows=[r for r in self.history if not q or q in json.dumps(r,ensure_ascii=False).lower()]; self.table.setRowCount(len(rows));
        for i,r in enumerate(rows):
            vals=[r.get('time',''),r.get('account',''),r.get('workflow',''),r.get('result',''),r.get('pid',''),r.get('step',''),r.get('message','')]
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v)))
        good=sum(1 for r in rows if r.get('result') in ('完成','成功')); bad=sum(1 for r in rows if str(r.get('result','')).startswith('失败')); self.summary.setText(f'当前记录：{len(rows)} ｜ 成功：{good} ｜ 失败：{bad}')
    def export(self):
        p,_=QFileDialog.getSaveFileName(self,'导出运行报告',f'运行报告_{datetime.now():%Y%m%d_%H%M%S}.csv','CSV (*.csv)')
        if not p:return
        with open(p,'w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['time','account','workflow','result','pid','step','message']); w.writeheader(); w.writerows(self.history)
        QMessageBox.information(self,'导出完成',f'已导出 {len(self.history)} 条记录。')

class AdvancedSchedulerDialog(QDialog):
    """高级调度：只负责“什么时候启动”和“结束后是否调用进程检测重跑”。"""
    def __init__(self,parent,current=None):
        super().__init__(parent); self.setWindowTitle('高级任务调度'); self.resize(620, 430); current=current or {}
        lay=QVBoxLayout(self)

        intro=QLabel(
            '高级调度负责自动安排“什么时候启动”。\n'
            '账号并发、启动间隔、工作流失败重试等基础运行参数仍由运行中心负责。\n'
            '本次运行结束后，可选择是否从“进程检测”结果自动发起重跑。'
        )
        intro.setWordWrap(True); lay.addWidget(intro)

        timing=QGroupBox('一、什么时候运行')
        form=QFormLayout(timing)
        self.enabled=QCheckBox('启用高级调度'); self.enabled.setChecked(bool(current.get('enabled',False))); form.addRow(self.enabled)
        self.when=QDateTimeEdit(QDateTime.currentDateTime().addSecs(60)); self.when.setDisplayFormat('yyyy-MM-dd HH:mm:ss')
        try:
            q=QDateTime.fromString(str(current.get('when','')),Qt.DateFormat.ISODate)
            if q.isValid(): self.when.setDateTime(q)
        except Exception: pass
        form.addRow('首次执行：',self.when)
        self.mode=QComboBox(); self.mode.addItems(['仅一次','每天','每小时','每N分钟']); self.mode.setCurrentText(current.get('mode','仅一次')); form.addRow('重复方式：',self.mode)
        self.interval=QSpinBox(); self.interval.setRange(1,10080); self.interval.setValue(int(current.get('repeat_interval',current.get('interval',30)))); form.addRow('N分钟：',self.interval)
        self.mode.currentTextChanged.connect(self._update_interval_state)
        self._update_interval_state(self.mode.currentText())
        lay.addWidget(timing)

        policy=QGroupBox('二、运行结束后自动从进程检测重跑')
        pf=QFormLayout(policy)
        self.auto_process_retry=QCheckBox('启用结束后自动重跑'); self.auto_process_retry.setChecked(bool(current.get('auto_process_retry',False))); pf.addRow(self.auto_process_retry)
        self.process_retry_mode=QComboBox(); self.process_retry_mode.addItems(['重跑未进行全部','重跑失败账号','重跑已退出账号'])
        self.process_retry_mode.setCurrentText(current.get('process_retry_mode','重跑未进行全部'))
        pf.addRow('重跑方式：',self.process_retry_mode)
        lay.addWidget(policy)

        note=QLabel(
            '“重跑未进行全部”=失败账号 + 已退出账号，重复账号只跑一次。\n'
            '主动排除账号不会进入任何自动重跑集合。'
        )
        note.setWordWrap(True); lay.addWidget(note)
        lay.addStretch()
        bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addWidget(bb)

    def _update_interval_state(self, text):
        self.interval.setEnabled(text == '每N分钟')

    def get_data(self):
        return {
            'enabled':self.enabled.isChecked(),
            'when':self.when.dateTime().toString(Qt.DateFormat.ISODate),
            'mode':self.mode.currentText(),
            'repeat_interval':self.interval.value(),
            'auto_process_retry':self.auto_process_retry.isChecked(),
            'process_retry_mode':self.process_retry_mode.currentText(),
        }
