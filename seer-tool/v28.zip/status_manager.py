"""运行状态分类与迁移检查；未知自定义状态保留原文，不强行改写。"""
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class StatusInfo:
    key: str
    label: str
    severity: str
    terminal: bool = False


STATUS_MAP = {
    "idle": StatusInfo("idle", "未运行", "neutral"),
    "preparing": StatusInfo("preparing", "正在准备软件", "info"),
    "waiting": StatusInfo("waiting", "等待软件启动", "info"),
    "running": StatusInfo("running", "正在执行工作流", "info"),
    "success": StatusInfo("success", "成功", "success", True),
    "failed": StatusInfo("failed", "失败", "error", True),
    "skipped": StatusInfo("skipped", "跳过", "warning", True),
    "stopped": StatusInfo("stopped", "已停止", "warning", True),
    "excluded": StatusInfo("excluded", "主动排除", "neutral", True),
    "warning": StatusInfo("warning", "警告", "warning", True),
    "error": StatusInfo("error", "异常", "error", True),
}

# 只规范化已知、明确的状态前缀；未知工作流自定义状态不会被误判为失败。
_PREFIXES = (
    ("主动排除", "excluded"),
    ("跳过", "skipped"),
    ("已停止", "stopped"),
    ("正在准备软件", "preparing"),
    ("等待软件启动", "waiting"),
    ("正在执行工作流", "running"),
    ("登录成功", "success"),
    ("成功", "success"),
    ("完成", "success"),
    ("登录失败", "failed"),
    ("失败", "failed"),
    ("异常", "error"),
    ("错误", "error"),
    ("警告", "warning"),
    ("未运行", "idle"),
)

_ALLOWED = {
    "idle": {"preparing", "waiting", "running", "skipped", "excluded", "success", "failed", "stopped", "warning", "error"},
    "preparing": {"waiting", "running", "success", "failed", "stopped", "warning", "error", "skipped"},
    "waiting": {"running", "success", "failed", "stopped", "warning", "error", "skipped"},
    "running": {"running", "success", "failed", "stopped", "warning", "error", "skipped", "excluded"},
    "success": {"preparing", "waiting", "running", "success", "idle"},
    "failed": {"preparing", "waiting", "running", "failed", "idle"},
    "skipped": {"preparing", "waiting", "running", "skipped", "idle"},
    "stopped": {"preparing", "waiting", "running", "stopped", "idle"},
    "excluded": {"preparing", "waiting", "running", "excluded", "idle"},
    "warning": {"preparing", "waiting", "running", "success", "failed", "warning", "idle"},
    "error": {"preparing", "waiting", "running", "failed", "error", "idle"},
    "unknown": {"unknown"},
}


def classify_status(value: object) -> StatusInfo:
    text = str(value or "").strip()
    if not text:
        return STATUS_MAP["idle"]
    # “完成（异常：...）”必须归入异常，而不是被“完成”前缀判为成功。
    low = text.lower()
    if "异常：" in text or "异常:" in text or "traceback" in low:
        return STATUS_MAP["error"]
    for prefix, key in _PREFIXES:
        if text.startswith(prefix):
            return STATUS_MAP[key]
    return StatusInfo("unknown", text, "neutral", False)


class StatusTracker:
    """单账号状态迁移跟踪器。非法迁移只产生诊断，不拦截旧版自定义状态。"""
    def __init__(self):
        self._current = {}
        self._history = {}

    def update(self, identity, value):
        info = classify_status(value)
        previous = self._current.get(identity, "idle")
        allowed = _ALLOWED.get(previous, _ALLOWED["unknown"])
        valid = info.key in allowed or info.key == "unknown"
        event = {"from": previous, "to": info.key, "label": info.label, "valid_transition": valid}
        self._current[identity] = info.key
        self._history.setdefault(identity, []).append(event)
        return info, event

    def current(self, identity):
        return self._current.get(identity, "idle")

    def history(self, identity):
        return list(self._history.get(identity, ()))
