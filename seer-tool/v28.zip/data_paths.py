# -*- coding: utf-8 -*-
"""统一的数据目录路由。映射配置保存在程序目录，避免更新器失去自己的状态。"""
import json, shutil
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
MAP_FILE = APP_DIR / 'config' / 'data_locations.json'
DEFAULT_CATEGORIES = ('config', 'workflows', 'logs', 'data', 'backups')
DEFAULT_CACHE_ROOT = Path(r'C:\Users\yht\Desktop\上号器缓存')
SETUP_KEY = '__cache_location_confirmed__'
ROOT_KEY = '__cache_root__'

def load_mapping():
    try:
        obj=json.loads(MAP_FILE.read_text(encoding='utf-8'))
        return obj if isinstance(obj,dict) else {}
    except Exception: return {}

def data_path(category, *parts, app_dir=None):
    app=Path(app_dir or APP_DIR).resolve()
    mapping=load_mapping()
    root=mapping.get(category, '')
    base=Path(root).expanduser() if root else app/category
    return base.joinpath(*parts)

def save_mapping(mapping):
    MAP_FILE.parent.mkdir(parents=True,exist_ok=True)
    tmp=MAP_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(MAP_FILE)

def migrate_category(category, target):
    """先复制并核验基本文件数量，再切换映射；原数据不删除。"""
    src=data_path(category); dst=Path(target).expanduser().resolve()
    if src.resolve()==dst: return 0
    if src.exists():
        if src.is_dir():
            for p in src.rglob('*'):
                rel=p.relative_to(src)
                # 更新器状态、更新缓存和路径映射始终留在程序目录，不随用户配置外迁。
                if category == 'config' and (rel.parts[0] == 'updates' or rel.as_posix() in {'data_locations.json','update_settings.json'}):
                    continue
                out=dst/rel
                if p.is_dir():
                    if category == 'config' and rel.parts[0] == 'updates': continue
                    out.mkdir(parents=True,exist_ok=True)
                elif p.is_file():
                    out.parent.mkdir(parents=True,exist_ok=True)
                    if not out.exists() or p.stat().st_size != out.stat().st_size: shutil.copy2(p,out)
        elif src.is_file():
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    dst.mkdir(parents=True,exist_ok=True)
    mapping=load_mapping(); mapping[category]=str(dst); save_mapping(mapping)
    return sum(1 for p in dst.rglob('*') if p.is_file())
