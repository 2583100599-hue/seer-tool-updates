"""Global keyboard/mouse lock for automated runs.

The lock is implemented with Windows low-level hooks so it affects the whole
Windows desktop, while F11/F12 remain available as emergency controls:
F11 = lock, F12 = unlock. The automation itself continues running.
"""
import ctypes
from ctypes import wintypes
import threading


_user32 = ctypes.WinDLL("user32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

WH_KEYBOARD_LL = 13
WH_MOUSE_LL = 14
HC_ACTION = 0
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
VK_F11 = 0x7A
VK_F12 = 0x7B
LLKHF_INJECTED = 0x10
LLMHF_INJECTED = 0x01
WM_QUIT = 0x0012

# ctypes 默认把 Win32 API 参数/返回值当成 32 位 int，64 位 Windows 下
# 会截断 HHOOK/ HMODULE 指针，导致 SetWindowsHookEx 虽被调用但钩子实际无效。
# 显式声明 64 位安全的签名。
_user32.SetWindowsHookExW.argtypes = [
    ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD
]
_user32.SetWindowsHookExW.restype = ctypes.c_void_p
_user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
_user32.UnhookWindowsHookEx.restype = wintypes.BOOL
_user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
_user32.CallNextHookEx.restype = ctypes.c_long
_user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
_user32.PostThreadMessageW.restype = wintypes.BOOL
_user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), ctypes.c_void_p, wintypes.UINT, wintypes.UINT]
_user32.GetMessageW.restype = ctypes.c_int
_user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
_user32.TranslateMessage.restype = wintypes.BOOL
_user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
_user32.DispatchMessageW.restype = wintypes.LPARAM
_kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
_kernel32.GetModuleHandleW.restype = ctypes.c_void_p
_kernel32.GetCurrentThreadId.restype = wintypes.DWORD

class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]

class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("pt_x", wintypes.LONG),
        ("pt_y", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]

LowLevelKeyboardProc = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
LowLevelMouseProc = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)


class InputLock:
    """One process-wide desktop input lock.

    F11 always locks; F12 always unlocks. The hook thread stays alive so the
    user can toggle the lock without stopping the automation thread.
    """
    def __init__(self, logger=None, state_callback=None):
        self._logger = logger
        self._state_callback = state_callback
        self._locked = False
        self._active = False
        self._state_lock = threading.Lock()
        # 串行化并发启动请求，避免多个调用同时创建钩子线程。
        self._ensure_lock = threading.Lock()
        self._thread = None
        self._ready = threading.Event()
        self._stop = threading.Event()
        self._thread_id = 0
        self._keyboard_hook = None
        self._mouse_hook = None
        # 保存钩子线程启动异常，避免安装失败时仍误报“已锁定”。
        self._last_error = None
        self._keyboard_proc = LowLevelKeyboardProc(self._keyboard_callback)
        self._mouse_proc = LowLevelMouseProc(self._mouse_callback)

    @property
    def locked(self):
        with self._state_lock:
            return self._locked

    def _set_state(self, value):
        value = bool(value)
        with self._state_lock:
            changed = self._locked != value
            self._locked = value
        if changed:
            if self._logger:
                try:
                    self._logger("键盘鼠标已锁定（F12 解锁）" if value else "键盘鼠标已解锁（F11 可重新锁定）")
                except Exception:
                    pass
            if self._state_callback:
                try:
                    self._state_callback(value)
                except Exception:
                    pass

    def begin_session(self, locked=True):
        """开始运行期间的键鼠锁定会话；会话外 F11/F12 完全无效。"""
        with self._state_lock:
            self._active = True
        try:
            self._ensure_thread()
            self._set_state(bool(locked))
            return True
        except Exception:
            with self._state_lock:
                self._active = False
            self._set_state(False)
            raise

    def end_session(self):
        """结束运行会话并卸载全局钩子。"""
        with self._state_lock:
            self._active = False
        self._set_state(False)
        self.stop()
        return True

    def lock(self):
        with self._state_lock:
            active = self._active
        if not active:
            return False
        self._ensure_thread()
        self._set_state(True)
        return True

    def unlock(self):
        with self._state_lock:
            active = self._active
        if not active:
            return False
        self._set_state(False)
        return True

    def toggle_lock(self):
        with self._state_lock:
            active = self._active
        if not active:
            return False
        self._ensure_thread()
        self._set_state(not self.locked)
        return self.locked

    def stop(self):
        self._set_state(False)
        self._stop.set()
        tid = self._thread_id
        if tid:
            try:
                _user32.PostThreadMessageW(tid, WM_QUIT, 0, 0)
            except Exception:
                pass
        t = self._thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=1.5)
        self._thread = None
        self._thread_id = 0

    def _ensure_thread(self):
        # 线程可能已启动但仍在安装钩子；必须先等待就绪事件，再检查句柄，
        # 否则并发调用会把正常的安装窗口误报为启动失败。
        with self._ensure_lock:
            thread = self._thread
            if thread and thread.is_alive():
                if not self._ready.wait(2.0):
                    raise RuntimeError("键鼠锁定模块启动失败：Windows 全局输入钩子未就绪。")
                if self._last_error is not None:
                    # 安装失败的线程会在 finally 中卸载钩子并退出；给它短暂完成清理的机会，
                    # 避免用户立即重试时被旧失败线程短暂存活的状态卡住。
                    thread.join(timeout=0.2)
                    if thread.is_alive():
                        raise RuntimeError(f"键鼠锁定模块启动失败：{self._last_error}")
                    self._thread = None
                else:
                    if not self._keyboard_hook or not self._mouse_hook:
                        raise RuntimeError("键鼠锁定模块启动失败：Windows 全局输入钩子未完整安装。")
                    return

            # 上次线程可能已经异常退出；先重置全部启动状态，再允许重试。
            self._stop.clear()
            self._ready.clear()
            self._last_error = None
            self._keyboard_hook = None
            self._mouse_hook = None
            self._thread = threading.Thread(target=self._hook_thread, name="InputLockHooks", daemon=True)
            self._thread.start()
            if not self._ready.wait(2.0):
                self._stop.set()
                raise RuntimeError("键鼠锁定模块启动失败：Windows 全局输入钩子未就绪。")
            if self._last_error is not None:
                raise RuntimeError(f"键鼠锁定模块启动失败：{self._last_error}")
            if not self._keyboard_hook or not self._mouse_hook:
                raise RuntimeError("键鼠锁定模块启动失败：Windows 全局输入钩子未完整安装。")

    def _hook_thread(self):
        self._thread_id = _kernel32.GetCurrentThreadId()
        module = _kernel32.GetModuleHandleW(None)
        try:
            if not module:
                raise ctypes.WinError(ctypes.get_last_error() or 126)

            self._keyboard_hook = _user32.SetWindowsHookExW(
                WH_KEYBOARD_LL, self._keyboard_proc, module, 0
            )
            if not self._keyboard_hook:
                raise ctypes.WinError(ctypes.get_last_error())

            self._mouse_hook = _user32.SetWindowsHookExW(
                WH_MOUSE_LL, self._mouse_proc, module, 0
            )
            if not self._mouse_hook:
                raise ctypes.WinError(ctypes.get_last_error())
            self._ready.set()

            msg = wintypes.MSG()
            while not self._stop.is_set():
                result = _user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if result <= 0:
                    break
                _user32.TranslateMessage(ctypes.byref(msg))
                _user32.DispatchMessageW(ctypes.byref(msg))
        except Exception as exc:
            # 必须先记录异常再唤醒等待方；等待方据此拒绝启用锁定状态。
            self._last_error = exc
            self._ready.set()
            if self._logger:
                try:
                    self._logger(f"键鼠锁定模块异常：{exc}")
                except Exception:
                    pass
        finally:
            if self._keyboard_hook:
                _user32.UnhookWindowsHookEx(self._keyboard_hook)
                self._keyboard_hook = None
            if self._mouse_hook:
                _user32.UnhookWindowsHookEx(self._mouse_hook)
                self._mouse_hook = None
            self._thread_id = 0

    def _keyboard_callback(self, n_code, w_param, l_param):
        if n_code == HC_ACTION:
            try:
                data = ctypes.cast(l_param, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                vk = int(data.vkCode)
                flags = int(data.flags)
                with self._state_lock:
                    active = self._active
                if not active:
                    return _user32.CallNextHookEx(None, n_code, w_param, l_param)
                if vk == VK_F12:
                    self._set_state(False)
                    return 1
                if vk == VK_F11:
                    self._set_state(True)
                    return 1
                # Allow programmatically injected keyboard input so the lock
                # does not break automation that uses SendInput.
                if self.locked and not (flags & LLKHF_INJECTED):
                    return 1
            except Exception:
                pass
        return _user32.CallNextHookEx(None, n_code, w_param, l_param)

    def _mouse_callback(self, n_code, w_param, l_param):
        if n_code == HC_ACTION and self.locked:
            with self._state_lock:
                if not self._active:
                    return _user32.CallNextHookEx(None, n_code, w_param, l_param)
            try:
                data = ctypes.cast(l_param, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                if not (int(data.flags) & LLMHF_INJECTED):
                    return 1
            except Exception:
                return 1
        return _user32.CallNextHookEx(None, n_code, w_param, l_param)
