@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0生成更新清单.py" %*
) else (
  python "%~dp0生成更新清单.py" %*
)
if errorlevel 1 echo.
pause
