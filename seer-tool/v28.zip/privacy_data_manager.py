# -*- coding: utf-8 -*-
"""外接数据管理：整套数据根目录或分类目录可外置，迁移时保留原件。"""
from pathlib import Path
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QFileDialog,
 QMessageBox,QGroupBox,QFormLayout,QLineEdit,QApplication)
from data_paths import (APP_DIR, DEFAULT_CATEGORIES, DEFAULT_CACHE_ROOT, SETUP_KEY, ROOT_KEY,
 data_path, load_mapping, migrate_category, save_mapping)

class PrivacyDataDialog(QDialog):
    LABELS={'config':'配置文件','workflows':'工作流','logs':'运行日志','data':'数据目录','backups':'备份目录'}
    def __init__(self, app_dir=None, parent=None):
        super().__init__(parent); self.app_dir=Path(app_dir or APP_DIR).resolve()
        self.setWindowTitle('隐私数据外置与缓存位置'); self.resize(820,650)
        layout=QVBoxLayout(self)
        intro=QLabel('【隐私数据外置】用于决定账号相关配置、工作流、运行日志、数据和备份保存在哪里。推荐统一放在一个总文件夹中，程序会自动按类别建立子文件夹；如果某一类想单独保存，也可以在下方独立指定。迁移采用复制方式，旧文件会保留。默认缓存位置：C:\\Users\\yht\\Desktop\\上号器缓存\\。注意：外接磁盘未连接或盘符改变时，对应数据可能无法访问。')
        intro.setWordWrap(True); layout.addWidget(intro)
        group=QGroupBox('一、统一缓存/隐私数据目录（推荐）'); row=QHBoxLayout(group)
        self.root=QLineEdit(); self.root.setText(str(load_mapping().get(ROOT_KEY) or DEFAULT_CACHE_ROOT)); self.root.setPlaceholderText('选择一个总文件夹，例如 E:\\句柄上号器数据')
        browse=QPushButton('选择…'); browse.clicked.connect(self.pick_root); apply=QPushButton('迁移全部到此目录'); apply.clicked.connect(self.apply_root)
        row.addWidget(self.root,1); row.addWidget(browse); row.addWidget(apply); layout.addWidget(group)
        group2=QGroupBox('二、单独设置某一类数据（优先级高于统一目录）'); form=QFormLayout(group2); self.edits={}
        mapping=load_mapping()
        for key in DEFAULT_CATEGORIES:
            line=QLineEdit(mapping.get(key,'') or '')
            line.setPlaceholderText('留空则使用统一目录或程序默认位置')
            btn=QPushButton('选择…'); btn.clicked.connect(lambda checked=False,k=key,e=line:self.pick_category(k,e))
            rr=QHBoxLayout(); rr.addWidget(line,1); rr.addWidget(btn)
            wrap=QWidgetProxy(rr)
            form.addRow(self.LABELS[key],wrap); self.edits[key]=line
        layout.addWidget(group2)
        buttons=QHBoxLayout(); save=QPushButton('保存单独位置'); save.clicked.connect(self.apply_categories); buttons.addWidget(save)
        reset=QPushButton('恢复默认本地位置'); reset.clicked.connect(self.reset_locations); buttons.addWidget(reset)
        close=QPushButton('关闭'); close.clicked.connect(self.accept); buttons.addWidget(close); layout.addLayout(buttons)
    def pick_root(self):
        p=QFileDialog.getExistingDirectory(self,'选择统一数据目录',self.root.text() or str(Path.home()))
        if p:self.root.setText(p)
    def pick_category(self,key,line):
        p=QFileDialog.getExistingDirectory(self,'选择'+self.LABELS[key]+'保存目录',line.text() or str(Path.home()))
        if p:line.setText(p)
    def apply_root(self):
        root=self.root.text().strip()
        if not root: QMessageBox.warning(self,'未选择目录','请先选择一个统一数据目录。'); return
        root=Path(root).expanduser().resolve()
        if root==self.app_dir or self.app_dir in root.parents:
            QMessageBox.warning(self,'目录不合适','请将外接数据目录放在程序目录之外。'); return
        if QMessageBox.question(self,'确认迁移',f'将配置、工作流、日志、数据和备份迁移到：\n{root}\n\n原文件会保留，不会删除。继续吗？') != QMessageBox.Yes:return
        try:
            root.mkdir(parents=True,exist_ok=True); mapping=load_mapping()
            for key in DEFAULT_CATEGORIES:
                target=root/key; migrate_category(key,target); mapping[key]=str(target)
            mapping[ROOT_KEY]=str(root); mapping[SETUP_KEY]=True
            save_mapping(mapping)
            for k,e in self.edits.items(): e.setText(mapping[k])
            QMessageBox.information(self,'迁移完成','已完成目录迁移并切换数据位置。原始文件仍保留在旧位置。请重启软件，使所有模块重新读取新路径。')
        except Exception as exc: QMessageBox.critical(self,'迁移失败',f'没有完成切换：{exc}\n原数据不会被主动删除。')
    def apply_categories(self):
        mapping=load_mapping()
        try:
            for key,line in self.edits.items():
                value=line.text().strip()
                if not value: mapping.pop(key,None); continue
                target=Path(value).expanduser().resolve()
                if target==self.app_dir or self.app_dir in target.parents: raise ValueError(f'{self.LABELS[key]}请设置到程序目录之外。')
                if str(data_path(key).resolve()) != str(target): migrate_category(key,target)
                mapping[key]=str(target)
            mapping[SETUP_KEY]=True
            save_mapping(mapping)
            QMessageBox.information(self,'已保存','分类位置已保存。旧数据保留；请重启软件使所有模块统一使用新位置。')
        except Exception as exc: QMessageBox.critical(self,'保存失败',str(exc))
    def reset_locations(self):
        if QMessageBox.question(self,'确认恢复','只会清除外置路径映射，不会删除外接盘上的任何文件。恢复后软件重新使用程序目录中的数据。继续？') != QMessageBox.Yes:return
        save_mapping({SETUP_KEY: True}); QMessageBox.information(self,'已恢复','路径映射已清除，软件将继续使用程序目录内的数据。请重启软件。')

# 避免为每行控件额外创建复杂的 QWidget 子类
from PySide6.QtWidgets import QWidget
class QWidgetProxy(QWidget):
    def __init__(self, layout):
        super().__init__(); self.setLayout(layout)


def ensure_cache_location(parent=None):
    """首次启动时强制确认数据缓存位置；确认前不继续进入主界面。"""
    mapping = load_mapping()
    if mapping.get(SETUP_KEY):
        return True
    dlg = QDialog(parent)
    dlg.setWindowTitle('首次启动：确认缓存保存位置')
    dlg.setMinimumWidth(650)
    layout = QVBoxLayout(dlg)
    title = QLabel('请先确认上号器的数据保存位置')
    title.setStyleSheet('font-size:16px;font-weight:700;')
    layout.addWidget(title)
    explain = QLabel('这里保存的是软件配置、工作流、运行日志、数据和备份等本地资料，不是程序安装文件。推荐使用默认缓存目录；程序会自动建立 config、workflows、logs、data、backups 子文件夹。你也可以选择其他总目录，之后仍可在“高级中心 → 隐私数据外置”里按类别单独设置。迁移会复制并保留原文件。')
    explain.setWordWrap(True); layout.addWidget(explain)
    row = QHBoxLayout(); edit = QLineEdit(str(DEFAULT_CACHE_ROOT)); row.addWidget(edit,1)
    browse = QPushButton('选择文件夹…')
    def choose():
        folder = QFileDialog.getExistingDirectory(dlg, '选择缓存总目录', edit.text() or str(Path.home()))
        if folder: edit.setText(folder)
    browse.clicked.connect(choose); row.addWidget(browse); layout.addLayout(row)
    buttons = QHBoxLayout()
    use = QPushButton('确认并使用此位置'); use.setDefault(True)
    local = QPushButton('使用程序目录内的本地数据')
    buttons.addWidget(use); buttons.addWidget(local); layout.addLayout(buttons)
    result = {'ok': False}
    def confirm():
        raw = edit.text().strip()
        if not raw:
            QMessageBox.warning(dlg, '需要选择位置', '请填写缓存目录，或选择使用程序目录内的本地数据。'); return
        root = Path(raw).expanduser().resolve()
        try:
            if root == APP_DIR or APP_DIR in root.parents:
                QMessageBox.warning(dlg, '目录不合适', '缓存目录请放在程序目录之外。'); return
            root.mkdir(parents=True, exist_ok=True)
            newmap = load_mapping()
            for key in DEFAULT_CATEGORIES:
                target = root / key
                migrate_category(key, target)
                newmap[key] = str(target)
            newmap[ROOT_KEY] = str(root); newmap[SETUP_KEY] = True
            save_mapping(newmap)
            result['ok'] = True; dlg.accept()
        except Exception as exc:
            QMessageBox.critical(dlg, '设置失败', f'无法初始化缓存目录：\n{exc}\n\n原始文件不会被主动删除。')
    def local_storage():
        newmap = load_mapping(); newmap[SETUP_KEY] = True; newmap.pop(ROOT_KEY, None)
        for key in DEFAULT_CATEGORIES: newmap.pop(key, None)
        save_mapping(newmap); result['ok'] = True; dlg.accept()
    use.clicked.connect(confirm); local.clicked.connect(local_storage)
    dlg.setModal(True); dlg.exec()
    return result['ok']
