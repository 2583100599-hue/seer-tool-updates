import csv
import io
import os
import tempfile
from pathlib import Path

FIELDS = ["account", "password", "create_time", "expire_time", "update_time", "remark", "status"]


def _normalise_header(value):
    text = str(value or "").replace("\ufeff", "").strip()
    low = text.lower()
    aliases = {"账号": "account", "帐号": "account", "用户名": "account", "user": "account",
               "密码": "password", "pass": "password"}
    return aliases.get(text, low)


def detect_dialect(path):
    """优先根据表头识别分隔符，避免单行脏数据干扰 Sniffer 的整段猜测。"""
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        sample = f.read(16384)
    if not sample.strip():
        return csv.excel_tab
    for delimiter in (",", "\t", ";"):
        try:
            reader = csv.reader(io.StringIO(sample), delimiter=delimiter)
            header = next((row for row in reader if row and any(str(x).strip() for x in row)), [])
            fields = {_normalise_header(x) for x in header}
            if "account" in fields and "password" in fields:
                class HeaderDialect(csv.excel):
                    pass
                HeaderDialect.delimiter = delimiter
                return HeaderDialect
        except Exception:
            continue
    try:
        return csv.Sniffer().sniff(sample, delimiters=",\t;")
    except csv.Error:
        return csv.excel_tab


def load_rows_with_report(path):
    """容错读取 CSV：隔离字段数异常的单行，返回可用数据及跳过统计。"""
    path = str(path)
    dialect = detect_dialect(path)
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, dialect=dialect)
        if not reader.fieldnames:
            raise ValueError("文件没有表头")
        aliases = {
            "账号": "account", "帐号": "account",
            "用户名": "account", "user": "account",
            "密码": "password", "pass": "password",
        }
        field_map = {}
        for x in reader.fieldnames:
            if not x:
                continue
            key = str(x).strip().lower()
            key = aliases.get(str(x).strip(), key)
            field_map[key] = x
        if "account" not in field_map or "password" not in field_map:
            raise ValueError("CSV 表头至少需要 account/账号、password/密码 两列；请检查首行分隔符和表头")
        rows = []
        skipped_lines = []
        for raw in reader:
            line_no = int(getattr(reader, "line_num", 0) or 0)
            if raw is None:
                continue
            # DictReader 将多出的字段放到 None 键；缺少的尾部字段会得到 None。
            extra_values = raw.get(None)
            # 任何列缺失都属于字段数不匹配；空字符串是合法的空单元格，不在此处误判。
            missing_fields = any(raw.get(name) is None for name in (reader.fieldnames or []))
            if extra_values is not None or missing_fields:
                skipped_lines.append(line_no)
                continue
            row = {}
            # 保留标准字段之外的自定义列，避免 server/nickname 等扩展字段丢失。
            for original in (reader.fieldnames or []):
                if original is not None and str(original).strip().lower() not in FIELDS:
                    row[original] = raw.get(original, "") or ""
            for field in FIELDS:
                original = field_map.get(field)
                row[field] = (raw.get(original, "") or "") if original else ""
            account_value = str(row.get("account", "") or "").strip()
            if not account_value:
                # 空白行不作为损坏账号计数；含有其它字段内容的残行则计入告警。
                if any(str(v or "").strip() for v in raw.values() if v is not None):
                    skipped_lines.append(line_no)
                continue
            rows.append(row)
        return rows, {
            "loaded_rows": len(rows),
            "skipped_rows": len(skipped_lines),
            "skipped_lines": skipped_lines,
        }


def load_rows(path, strict=True):
    """默认严格模式保护原 CSV：发现损坏行时不允许后续编辑流程无提示覆盖原文件。

    账号加载器可显式使用 load_rows_with_report()，只跳过损坏行并把统计告警给用户。
    """
    rows, report = load_rows_with_report(path)
    if strict and report.get("skipped_rows", 0):
        lines = ", ".join(map(str, report.get("skipped_lines", [])[:20]))
        if len(report.get("skipped_lines", [])) > 20:
            lines += " 等"
        raise ValueError(
            f"CSV 检测到 {report['skipped_rows']} 行字段损坏或账号字段缺失（行号：{lines}）。"
            "为防止编辑时丢失原始异常行，已拒绝严格读取；请先备份并修复文件。"
        )
    return rows


def save_rows(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    # 标准字段保持原顺序；同时收集读取过的自定义字段并原样保存。
    extra_fields = []
    seen = set(FIELDS)
    for row in rows:
        if isinstance(row, dict):
            for key in row.keys():
                if key not in seen:
                    seen.add(key)
                    extra_fields.append(key)
    fieldnames = list(FIELDS) + extra_fields
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8-sig", newline="", dir=str(path.parent),
            prefix=path.name + ".", suffix=".tmp", delete=False
        ) as f:
            tmp = Path(f.name)
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({k: ("" if row.get(k, "") is None else str(row.get(k, ""))) for k in fieldnames})
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp), str(path))
        tmp = None
    finally:
        if tmp is not None:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
