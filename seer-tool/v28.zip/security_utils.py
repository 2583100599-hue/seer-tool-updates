"""轻量级敏感信息脱敏工具。

用于减少运行日志/历史记录中意外出现账号密码的概率。它不替代 CSV 文件加密：
账号源 CSV 仍由用户管理，若文件本身是明文，文件内容仍可被有权限的用户读取。
"""
import re
from typing import Iterable


class SecretRedactor:
    """维护当前已加载账号的密码集合，并对日志文本做 best-effort 脱敏。"""

    def __init__(self, replacement="[已隐藏]"):
        self.replacement = str(replacement)
        self._pattern = None
        self._short_secrets = set()

    def update(self, secrets: Iterable[object]):
        values = {str(value) for value in (secrets or ()) if value is not None and str(value) != ""}
        # 3 字符及以上的密码直接按字面量替换；按长度降序避免短密码先截断长密码。
        long_values = sorted((value for value in values if len(value) >= 3), key=len, reverse=True)
        self._short_secrets = {value for value in values if len(value) < 3}
        alternatives = []
        for value in long_values:
            literal = re.escape(value)
            # 常规字母/数字密码加边界，避免密码 123 把 PID=1234 之类的日志误伤。
            if re.fullmatch(r"[A-Za-z0-9_]+", value):
                literal = r"(?<![A-Za-z0-9_])" + literal + r"(?![A-Za-z0-9_])"
            alternatives.append(literal)
        self._pattern = re.compile("|".join(alternatives)) if alternatives else None

    def redact(self, text: object) -> str:
        value = str(text or "")
        if self._pattern is not None:
            value = self._pattern.sub(self.replacement, value)
        # 1–2 字符密码不做全局替换，以免严重破坏日志可读性；只处理明确标注的密码字段。
        if self._short_secrets:
            value = re.sub(
                r"(?i)((?:password|passwd|pwd|密码)\s*[:=：]\s*)([^\s,;，；]+)",
                lambda match: match.group(1) + self.replacement,
                value,
            )
        return value
