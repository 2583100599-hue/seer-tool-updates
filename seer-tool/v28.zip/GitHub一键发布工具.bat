@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0GitHub一键发布工具.py"
) else (
  python "%~dp0GitHub一键发布工具.py"
)
if errorlevel 1 pause
