import os
import subprocess

class ProcessManager:
    def __init__(self):
        self.process = None
        self.pid = None

    def start(self, exe_path):
        if not os.path.isfile(exe_path):
            raise FileNotFoundError(f"找不到程序：{exe_path}")
        self.process = subprocess.Popen([exe_path], cwd=os.path.dirname(exe_path) or None)
        self.pid = self.process.pid
        return self.pid

    def is_running(self):
        return self.process is not None and self.process.poll() is None

    def stop(self, timeout=8):
        if not self.process:
            return
        if self.process.poll() is None:
            try:
                self.process.terminate()
                self.process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
        self.process = None
        self.pid = None


def terminate_process_by_pid(pid, timeout=3):
    """仅结束指定 PID，不自动触碰其它实例；Windows API，失败则返回 False。"""
    import ctypes
    if not pid:
        return False
    PROCESS_TERMINATE = 0x0001
    SYNCHRONIZE = 0x00100000
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
    kernel32.OpenProcess.restype = ctypes.c_void_p
    kernel32.TerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel32.TerminateProcess.restype = ctypes.c_int
    kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel32.WaitForSingleObject.restype = ctypes.c_uint32
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel32.CloseHandle.restype = ctypes.c_int
    handle = kernel32.OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE, 0, int(pid))
    if not handle:
        return False
    try:
        if not kernel32.TerminateProcess(handle, 1):
            return False
        kernel32.WaitForSingleObject(handle, max(0, int(timeout * 1000)))
        return True
    finally:
        kernel32.CloseHandle(handle)
