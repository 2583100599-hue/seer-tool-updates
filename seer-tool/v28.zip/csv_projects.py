import json
import os
import shutil
import tempfile
import time
from pathlib import Path
from data_paths import data_path


class CSVProjectStore:
    """CSV 快速管理项目：只保存用户自定义标题和 CSV/TSV 路径。"""
    def __init__(self, base_dir):
        self.path = data_path("config", "csv_projects.json")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.load_warning = ""
        self.data = self._load()

    def _load(self):
        if not self.path.exists():
            return []
        try:
            data = json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(data, list):
                raise ValueError("CSV 项目配置顶层必须是列表")
            out = []
            for x in data:
                if not isinstance(x, dict):
                    continue
                name = str(x.get('name', '')).strip()
                path = str(x.get('path', '')).strip()
                if name and path:
                    out.append({'name': name, 'path': path})
            return out
        except Exception as exc:
            # 保留损坏原件，避免静默回退为空列表后保存时丢掉项目清单。
            backup = None
            try:
                stamp = time.strftime("%Y%m%d-%H%M%S")
                backup = self.path.with_name(f"{self.path.name}.corrupt-{stamp}.bak")
                suffix = 1
                while backup.exists():
                    backup = self.path.with_name(f"{self.path.name}.corrupt-{stamp}-{suffix}.bak")
                    suffix += 1
                shutil.copy2(self.path, backup)
            except Exception:
                backup = None
            self.load_warning = (
                f"CSV 项目配置读取失败（{type(exc).__name__}），已暂时使用空列表；"
                + (f"原文件备份为 {backup.name}。" if backup else "原文件自动备份失败，请手动备份后再保存。")
            )
            return []

    def save(self):
        tmp = None
        try:
            with tempfile.NamedTemporaryFile(
                mode='w', encoding='utf-8', newline='', dir=str(self.path.parent),
                prefix=self.path.name + '.', suffix='.tmp', delete=False
            ) as f:
                tmp = Path(f.name)
                json.dump(self.data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(str(tmp), str(self.path))
            tmp = None
        finally:
            if tmp is not None:
                try: tmp.unlink(missing_ok=True)
                except OSError: pass

    def add_or_update(self, name, path, old_name=None):
        name = str(name).strip()
        path = str(path).strip()
        if not name:
            raise ValueError('CSV项目名称不能为空')
        if not path:
            raise ValueError('CSV文件不能为空')
        if old_name and old_name != name:
            self.delete(old_name, save=False)
        for item in self.data:
            if item['name'] == name:
                item['path'] = path
                self.save()
                return
        self.data.append({'name': name, 'path': path})
        self.save()

    def delete(self, name, save=True):
        self.data = [x for x in self.data if x.get('name') != name]
        if save:
            self.save()
