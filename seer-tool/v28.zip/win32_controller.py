import re
import ctypes
from ctypes import wintypes
import win32api
import win32con
import win32gui
import win32process


class Win32Controller:
    def _parse_class_selector(self, class_name, index=0, occurrence=None):
        """兼容 ClassName、ClassName[x]、以及新版 occurrence（从1开始）。"""
        if class_name is None:
            if occurrence is not None:
                return None, max(0, int(occurrence) - 1)
            return None, int(index)
        text = str(class_name).strip()
        m = re.fullmatch(r"(.+?)\[(\d+)\]", text)
        if m:
            base = m.group(1).strip()
            return base, max(0, int(m.group(2)) - 1)
        if occurrence is not None:
            return text, max(0, int(occurrence) - 1)
        return text, int(index)

    @staticmethod
    def _match_common(hwnd, title=None, class_name=None, exact_title=False,
                      visible_only=False, enabled_only=False):
        """匹配窗口条件；窗口可能在枚举期间销毁，单个失效句柄不得中断整次查找。"""
        try:
            hwnd = int(hwnd)
            if not hwnd or not win32gui.IsWindow(hwnd):
                return False
            if title is not None and title != "":
                actual = win32gui.GetWindowText(hwnd)
                if exact_title and actual != title:
                    return False
                if not exact_title and title not in actual:
                    return False
            if class_name is not None and str(class_name).strip():
                actual_class = str(win32gui.GetClassName(hwnd) or "").strip()
                if actual_class.lower() != str(class_name).strip().lower():
                    return False
            if visible_only and not win32gui.IsWindowVisible(hwnd):
                return False
            if enabled_only and not win32gui.IsWindowEnabled(hwnd):
                return False
            return True
        except Exception:
            # EnumWindows/控件遍历期间句柄可能被目标进程销毁；按不匹配处理。
            return False

    def find_windows(self, title=None, class_name=None, pid=None, exact_title=False,
                     index=0, occurrence=None, visible_only=False, enabled_only=False):
        result = []
        raw_class = str(class_name).strip() if class_name is not None else ""
        class_name, effective_index = self._parse_class_selector(class_name, index, occurrence)
        embedded_occurrence = bool(re.fullmatch(r"(.+?)\[(\d+)\]", raw_class))
        def cb(hwnd, _):
            try:
                if not self._match_common(hwnd, title, class_name, exact_title, visible_only, enabled_only):
                    return
                if pid is not None:
                    _, wp = win32process.GetWindowThreadProcessId(hwnd)
                    if int(wp) != int(pid):
                        return
                result.append(int(hwnd))
            except Exception:
                # 单个窗口信息读取失败时继续枚举其余窗口。
                return
        try:
            win32gui.EnumWindows(cb, None)
        except Exception:
            # 系统枚举本身失败时返回已成功收集的结果，不让瞬时 Win32 错误击穿工作流。
            pass
        if embedded_occurrence:
            return [result[effective_index]] if 0 <= effective_index < len(result) else []
        return result

    def find_child(self, parent, title=None, class_name=None, index=0, exact_title=False,
                   occurrence=None, visible_only=False, enabled_only=False,
                   recursive=True):
        """按外部抓取器同款控件树规则查找控件。

        关键规则：
        1. 同级控件顺序严格来自 GetWindow(GW_CHILD) -> GetWindow(GW_HWNDNEXT)。
        2. ClassName[x] 的 x 是“该父级下同 ClassName 的第几个”，标题只做最终过滤，
           不参与序号计算。
        3. recursive=True 时，按抓取器的深度优先控件树继续进入后代，这样顶层窗口下
           的 WTWindow -> Edit[4] 也可以直接找到；如需绝对精确，可先定位 WTWindow，
           再以它作为 parent 查 Edit[4]。
        """
        base_class, effective_index = self._parse_class_selector(class_name, index, occurrence)
        try:
            parent = int(parent)
            if not parent or not win32gui.IsWindow(parent):
                return None
        except Exception:
            return None

        # 精确的同级查找。无 ClassName 时按所有直接子控件序号。
        def find_in_direct(p):
            all_children = list(self.iter_direct_children(p))
            if base_class is None:
                if 0 <= effective_index < len(all_children):
                    h = all_children[effective_index]
                    if self._match_common(h, title, None, exact_title, visible_only, enabled_only):
                        return h
                return None
            n = 0
            for h in all_children:
                try:
                    if str(win32gui.GetClassName(h) or "").strip().lower() != str(base_class or "").strip().lower():
                        continue
                except Exception:
                    continue
                n += 1
                if n == effective_index + 1:
                    if self._match_common(h, title, None, exact_title, visible_only, enabled_only):
                        return h
                    return None
            return None

        found = find_in_direct(parent)
        if found:
            return found
        if not recursive:
            return None

        # 使用显式栈执行深度优先遍历，保持原先“先查当前子树，再查下一个兄弟”的顺序，
        # 同时避免极深控件树触发 Python 递归深度限制。
        visited = {parent}
        stack = list(reversed(list(self.iter_direct_children(parent))))
        visited_count = 0
        max_nodes = 10000
        while stack and visited_count < max_nodes:
            child = stack.pop()
            try:
                child = int(child)
            except (TypeError, ValueError):
                continue
            if child in visited:
                continue
            visited.add(child)
            visited_count += 1
            found_here = find_in_direct(child)
            if found_here:
                return found_here
            descendants = list(self.iter_direct_children(child))
            # 子控件按原枚举顺序访问，故入栈时反转。
            for nested in reversed(descendants):
                if nested not in visited:
                    stack.append(nested)
        return None


    def iter_direct_children(self, parent):
        """通过 GetWindow 枚举直接子控件；防止失效句柄、异常和异常链路导致死循环。"""
        try:
            parent = int(parent)
            if not parent or not win32gui.IsWindow(parent):
                return
            user32 = ctypes.windll.user32
            GetWindow = user32.GetWindow
            GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
            GetWindow.restype = wintypes.HWND
            GW_CHILD = 5
            GW_HWNDNEXT = 2
            current = GetWindow(wintypes.HWND(parent), GW_CHILD)
        except Exception:
            return
        seen = set()
        max_siblings = 10000
        while current and len(seen) < max_siblings:
            try:
                value = int(current)
            except (TypeError, ValueError):
                break
            if not value or value in seen:
                break
            seen.add(value)
            yield value
            try:
                current = GetWindow(wintypes.HWND(value), GW_HWNDNEXT)
            except Exception:
                break

    def desktop_hwnd(self):
        return int(ctypes.windll.user32.GetDesktopWindow())

    def iter_grabber_tree(self, root_hwnd, max_depth=30, limit=20000, include_root=True):
        """完全按用户提供的 win_grab_gui.py walk() 思路遍历：先当前节点，再递归直接子节点。"""
        count = 0
        root_hwnd = int(root_hwnd)

        def rec(h, depth, occurrence=None):
            nonlocal count
            if depth > max_depth or count >= limit:
                return
            try:
                cls = win32gui.GetClassName(h)
            except Exception:
                cls = ''
            try:
                title = win32gui.GetWindowText(h) or ''
            except Exception:
                title = ''
            try:
                text = self._grabber_get_text(h, 300) or ''
            except Exception:
                text = ''
            parent = int(win32gui.GetParent(h) or 0)
            count += 1
            occ = occurrence if occurrence is not None else 1
            yield {'hwnd': int(h), 'parent': parent,
                   'class_name': cls, 'occurrence': occ,
                   'selector': f'{cls}[{occ}]',
                   'title': title, 'text': text, 'depth': depth}
            if depth >= max_depth:
                return
            counters = {}
            for child in self.iter_direct_children(h):
                try:
                    ccls = win32gui.GetClassName(child)
                except Exception:
                    ccls = ''
                counters[ccls] = counters.get(ccls, 0) + 1
                yield from rec(child, depth + 1, counters[ccls])

        if include_root:
            yield from rec(root_hwnd, 0)
        else:
            for child in self.iter_direct_children(root_hwnd):
                yield from rec(child, 1)


    def iter_control_tree(self, root_hwnd, max_depth=30, limit=20000):
        """按抓取器同款顺序遍历控件树，并给出每个控件的直接父级序号。"""
        count = 0

        def walk(parent, depth):
            nonlocal count
            if depth > max_depth or count >= limit:
                return
            counters = {}
            for hwnd in self.iter_direct_children(parent):
                if count >= limit:
                    return
                try:
                    cls = win32gui.GetClassName(hwnd)
                except Exception:
                    cls = ''
                counters[cls] = counters.get(cls, 0) + 1
                occ = counters[cls]
                try:
                    title = win32gui.GetWindowText(hwnd) or ''
                except Exception:
                    title = ''
                count += 1
                yield {
                    'hwnd': int(hwnd),
                    'parent': int(parent),
                    'class_name': cls,
                    'occurrence': occ,
                    'selector': f'{cls}[{occ}]',
                    'title': title,
                    'depth': depth,
                }
                yield from walk(hwnd, depth + 1)

        yield from walk(int(root_hwnd), 1)

    def search_controls(self, keyword='', field='全部', include_text=False,
                        include_desktop=False, max_windows=2000, max_controls=50000):
        """混合句柄检索：同时复刻外部抓取器的 EnumWindows + GW_CHILD/GW_HWNDNEXT，
        并保留 Desktop 根树。对 HWND 精确检索时直接命中真实窗口，避免因为树根不同而漏掉。
        """
        kw_raw = str(keyword or '').strip()
        kw = kw_raw.lower()
        results, seen = [], set()
        import re

        def hwnd_from_query(q):
            q = str(q).strip().lower()
            try:
                if q.startswith('0x'):
                    return int(q, 16)
                if q.isdigit():
                    return int(q, 10)
            except Exception:
                pass
            return 0

        def root_for(hwnd):
            try:
                root = win32gui.GetAncestor(int(hwnd), win32con.GA_ROOT)
                return int(root or hwnd)
            except Exception:
                return int(hwnd)

        def make_data(hwnd, root, depth=0, occurrence=1, parent=0, is_root=False):
            hwnd = int(hwnd); root = int(root)
            try: cls = win32gui.GetClassName(hwnd) or ''
            except Exception: cls = ''
            try: title = win32gui.GetWindowText(hwnd) or ''
            except Exception: title = ''
            try: pid = int(win32process.GetWindowThreadProcessId(hwnd)[1])
            except Exception: pid = 0
            return {
                'hwnd': hwnd, 'parent': int(parent or 0), 'class_name': cls,
                'occurrence': int(occurrence), 'selector': f'{cls}[{int(occurrence)}]' if cls else '',
                'title': title, 'depth': int(depth), 'root_hwnd': root,
                'root_title': (win32gui.GetWindowText(root) or ''), 'pid': pid,
                'text': '', 'is_root': bool(is_root)
            }

        def matches(data, text=''):
            if not kw:
                return True
            vals = {
                '全部': [data.get('hwnd'), data.get('parent'), data.get('class_name'), data.get('selector'),
                         data.get('title'), data.get('root_title'), data.get('pid'), text],
                '窗口标题': [data.get('root_title'), data.get('title')],
                '类名': [data.get('class_name')],
                'HWND': [data.get('hwnd'), data.get('parent')],
                'PID': [data.get('pid')],
                '选择器': [data.get('selector')],
                '控件文本': [text],
            }.get(field, [])
            return any(kw in str(v or '').lower() for v in vals)

        # ① 精确 HWND：只要句柄真实存在，直接返回，不依赖任何父树枚举。
        q_hwnd = hwnd_from_query(kw_raw)
        if q_hwnd and win32gui.IsWindow(q_hwnd):
            root = root_for(q_hwnd)
            parent = int(win32gui.GetParent(q_hwnd) or 0)
            # 计算该父级下同 ClassName 的真实序号，和抓取器一致。
            try:
                cls = win32gui.GetClassName(q_hwnd)
            except Exception:
                cls = ''
            occ = 0
            for sib in self.iter_direct_children(parent) if parent else []:
                try:
                    if win32gui.GetClassName(sib) == cls:
                        occ += 1
                    if int(sib) == q_hwnd:
                        break
                except Exception:
                    pass
            data = make_data(q_hwnd, root, 0, occ or 1, parent, False)
            if include_text:
                try: data['text'] = self.get_text(q_hwnd, include_children=False, timeout_ms=300)
                except Exception: pass
            if field == '全部' or field == 'HWND' or matches(data, data.get('text','')):
                data['direct_hit'] = True
                results.append(data); seen.add(q_hwnd)
                return results

        # ② 顶层窗口：严格复刻抓取器 list_top_windows / EnumWindows。
        roots = []
        try:
            for hwnd in self.find_windows():
                h = int(hwnd)
                if h not in roots:
                    roots.append(h)
                    if len(roots) >= max_windows: break
        except Exception:
            pass
        # ③ Desktop 作为额外根，而不是替代 EnumWindows。
        if include_desktop:
            desktop = self.desktop_hwnd()
            if desktop not in roots:
                roots.insert(0, desktop)

        for root in roots:
            if len(results) >= max_controls:
                break
            try:
                root_title = win32gui.GetWindowText(root) or ''
                root_cls = win32gui.GetClassName(root) or ''
                root_pid = int(win32process.GetWindowThreadProcessId(root)[1])
            except Exception:
                continue
            root_data = make_data(root, root, 0, 1, 0, True)
            root_data['text'] = root_title
            if matches(root_data, root_title) and root not in seen:
                results.append(root_data); seen.add(root)

            try:
                walker = self.iter_grabber_tree(root, max_depth=30, limit=max_controls, include_root=False)
                for data in walker:
                    if len(results) >= max_controls: break
                    hwnd = int(data['hwnd'])
                    if hwnd in seen: continue
                    text = str(data.get('text') or '')
                    if include_text and not text:
                        try: text = self._grabber_get_text(hwnd, 300) or ''
                        except Exception: text = ''
                    elif not include_text:
                        text = ''
                    row = dict(data)
                    row.update({'root_hwnd': root, 'root_title': root_title,
                                'pid': root_pid, 'text': text, 'is_root': False})
                    if matches(row, text):
                        results.append(row); seen.add(hwnd)
            except Exception:
                continue
        return results

    def find_children(self, parent, title=None, class_name=None, visible_only=False, enabled_only=False):
        """返回 parent 下所有匹配后代，使用统一抓取器 DFS。

        这里不改变原有“返回所有匹配 HWND”的语义，只把底层枚举统一为
        GetWindow(GW_CHILD/GW_HWNDNEXT) + DFS。
        """
        result = []
        base_class, _ = self._parse_class_selector(class_name, 0)
        for node in self.iter_grabber_tree(int(parent), max_depth=30, limit=20000, include_root=False):
            hwnd = int(node['hwnd'])
            if self._match_common(hwnd, title, base_class, False, visible_only, enabled_only):
                result.append(hwnd)
        return result

    def is_window(self, hwnd):
        try:
            return bool(win32gui.IsWindow(int(hwnd)))
        except Exception:
            return False

    def get_class_name(self, hwnd):
        return win32gui.GetClassName(int(hwnd))

    def set_text(self, hwnd, text, timeout_ms=1800):
        """向已定位的控件发送 WM_SETTEXT，并限制等待时间，避免目标控件无响应时卡死工作线程。"""
        hwnd = int(hwnd)
        if not win32gui.IsWindow(hwnd):
            raise RuntimeError(f"输入目标 HWND 已失效：{hwnd}")
        try:
            # SendMessage 是同步调用；某些自绘/第三方密码框可能不处理或阻塞该消息。
            # SendMessageTimeout 可避免上号器线程无限等待目标窗口。
            result = win32gui.SendMessageTimeout(
                hwnd, win32con.WM_SETTEXT, 0, str(text),
                win32con.SMTO_ABORTIFHUNG, int(timeout_ms)
            )
            if isinstance(result, tuple):
                if len(result) >= 2:
                    ok, message_result = result[0], result[1]
                    if not ok:
                        raise TimeoutError(f"控件在 {timeout_ms}ms 内未响应 WM_SETTEXT")
                    return message_result
            elif result is None:
                raise TimeoutError(f"控件在 {timeout_ms}ms 内未响应 WM_SETTEXT")
            return result
        except AttributeError as exc:
            raise RuntimeError("当前 pywin32 不支持 SendMessageTimeout，请升级 pywin32") from exc

    # 独立抓取器使用的原生 user32 通道。
    # 这里必须显式声明 64 位参数类型；否则 ctypes 会把未声明的 LPARAM
    # 按默认 c_int(32 位) 转换，WM_GETTEXT 传入 Unicode buffer 地址时就会
    # 触发：ArgumentError: argument 4: OverflowError: int too long to convert。
    _grabber_user32 = ctypes.WinDLL("user32", use_last_error=True)
    _grabber_user32.SendMessageTimeoutW.argtypes = [
        ctypes.c_void_p,       # HWND
        ctypes.c_uint,         # UINT msg
        ctypes.c_size_t,       # WPARAM
        ctypes.c_ssize_t,      # LPARAM（64 位 Windows）
        ctypes.c_uint,         # fuFlags
        ctypes.c_uint,         # uTimeout
        ctypes.POINTER(ctypes.c_size_t),  # lpdwResult
    ]
    _grabber_user32.SendMessageTimeoutW.restype = ctypes.c_ssize_t
    _grabber_user32.GetWindowTextLengthW.argtypes = [ctypes.c_void_p]
    _grabber_user32.GetWindowTextLengthW.restype = ctypes.c_int
    _grabber_user32.GetWindowTextW.argtypes = [
        ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int
    ]
    _grabber_user32.GetWindowTextW.restype = ctypes.c_int

    @classmethod
    def _grabber_send_timeout(cls, hwnd, msg, wparam, lparam, timeout=300):
        """与用户提供的独立抓取器相同的 SendMessageTimeoutW 参数定义。"""
        result = ctypes.c_size_t(0)
        ok = cls._grabber_user32.SendMessageTimeoutW(
            ctypes.c_void_p(int(hwnd)),
            ctypes.c_uint(int(msg)),
            ctypes.c_size_t(int(wparam)),
            ctypes.c_ssize_t(int(lparam)),
            ctypes.c_uint(0x0002),
            ctypes.c_uint(int(timeout)),
            ctypes.byref(result),
        )
        return result.value if ok else None

    @classmethod
    def _grabber_get_text(cls, hwnd, timeout=300):
        """完整采用用户提供的抓取器 get_text()，并修正 64 位 ctypes 参数声明。"""
        hwnd = int(hwnd)
        length = cls._grabber_send_timeout(
            hwnd, 0x000E, 0, 0, timeout
        )  # WM_GETTEXTLENGTH
        if length and 0 < length < (1 << 20):
            buf = ctypes.create_unicode_buffer(int(length) + 2)
            cls._grabber_send_timeout(
                hwnd, 0x000D, int(length) + 1, ctypes.addressof(buf), timeout
            )  # WM_GETTEXT
            if buf.value:
                return buf.value

        n = cls._grabber_user32.GetWindowTextLengthW(ctypes.c_void_p(hwnd))
        buf = ctypes.create_unicode_buffer(int(n) + 2)
        cls._grabber_user32.GetWindowTextW(
            ctypes.c_void_p(hwnd), buf, ctypes.c_int(int(n) + 1)
        )
        return buf.value

    @classmethod
    def _native_send_message_timeout(cls, hwnd, msg, wparam, lparam, timeout_ms=1200):
        """兼容旧调用；底层与外部抓取器相同。"""
        return cls._grabber_send_timeout(hwnd, msg, wparam, lparam, timeout_ms)

    def get_text_details(self, hwnd, timeout_ms=1200):
        """使用与外部句柄抓取器一致的 WM_GETTEXT 路径读取文本，并返回诊断细节。

        返回：text / method / length / wm_gettext_return / class_name / parent / pid / control_id。
        这是工作流关键字检测的首选读取通道。
        """
        hwnd = int(hwnd)
        details = {
            'hwnd': f'0x{hwnd:X}',
            'text': '',
            'method': '',
            'length': 0,
            'wm_gettext_return': None,
            'class_name': '',
            'parent': '',
            'parent_class': '',
            'process_id': '',
            'control_id': '',
        }
        if not win32gui.IsWindow(hwnd):
            details['method'] = 'HWND无效'
            return details

        try:
            details['class_name'] = win32gui.GetClassName(hwnd)
        except Exception:
            pass
        try:
            parent = int(win32gui.GetParent(hwnd) or 0)
            details['parent'] = f'0x{parent:X}' if parent else ''
            if parent:
                try:
                    details['parent_class'] = win32gui.GetClassName(parent)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            details['process_id'] = str(win32process.GetWindowThreadProcessId(hwnd)[1])
        except Exception:
            pass
        try:
            details['control_id'] = str(int(win32gui.GetDlgCtrlID(hwnd)))
        except Exception:
            pass

        # 关键：完全复制外部抓取器的两步读取逻辑。
        try:
            length = self._grabber_send_timeout(
                hwnd, win32con.WM_GETTEXTLENGTH, 0, 0, timeout_ms
            )
            details['length'] = int(length or 0)
        except Exception:
            details['length'] = 0

        if details['length'] > 0 and details['length'] < (1 << 20):
            try:
                buf = ctypes.create_unicode_buffer(details['length'] + 2)
                copied = self._grabber_send_timeout(
                    hwnd, win32con.WM_GETTEXT, details['length'] + 1,
                    ctypes.addressof(buf), timeout_ms
                )
                details['wm_gettext_return'] = copied
                text = buf.value
                if text:
                    details['text'] = text
                    details['method'] = 'WM_GETTEXTLENGTH→WM_GETTEXT（原抓取器原样）'
                    return details
            except Exception:
                pass

        # 再做一次与外部抓取器完全相同的整体 get_text() 路径。
        try:
            text = self._grabber_get_text(hwnd, timeout_ms) or ''
            if text:
                details['text'] = text
                details['method'] = '原抓取器 get_text() 完整路径'
                return details
        except Exception:
            pass

        # WM_GETTEXTLENGTH 返回 0 时，再用标准 GetWindowText 兜底。
        try:
            text = win32gui.GetWindowText(hwnd) or ''
            if text:
                details['text'] = text
                details['method'] = 'GetWindowTextW（兜底）'
                return details
        except Exception:
            pass

        details['method'] = '未读取到文字'
        return details

    def get_text(self, hwnd, include_children=False, timeout_ms=1200):
        """读取 HWND 文本。

        第一优先级严格采用独立句柄抓取器验证过的实现：
        WM_GETTEXTLENGTH → 按长度创建 Unicode 缓冲区 → WM_GETTEXT。
        只有目标 HWND 本身没有文字时，才按需读取 Win32 子控件；UIA 仅作为
        明确的兼容兜底，避免把“第一个字符”与其它碎片文本拼成错误结果。
        """
        hwnd = int(hwnd)
        if not win32gui.IsWindow(hwnd):
            return ''

        # 第一通道：逐字复刻用户给出的独立抓取器 get_text()。
        try:
            direct = self._grabber_get_text(hwnd, timeout_ms) or ''
            if direct:
                return direct
        except Exception:
            pass

        details = self.get_text_details(hwnd, timeout_ms=timeout_ms)
        if details.get('text'):
            return details['text']

        if not include_children:
            return ''

        # 只有调用者明确要求 include_children 时才扫描子控件，并且每个子控件
        # 同样优先使用上面的抓取器同款 WM_GETTEXT 路径。
        texts = []
        try:
            for node in self.iter_grabber_tree(hwnd, max_depth=30, limit=20000, include_root=False):
                child_text = str(node.get('text') or '')
                if child_text:
                    texts.append(child_text)
        except Exception:
            pass

        # 保留一个轻量 UIA 兼容兜底，但只有 Win32 文本完全为空时才启用。
        if not texts:
            try:
                import win32com.client
                uia = win32com.client.Dispatch('UIAutomationClient.CUIAutomation8')
                root = uia.ElementFromHandle(hwnd)
                if root is not None:
                    for prop_id in (30005,):  # Name
                        try:
                            value = root.GetCurrentPropertyValue(prop_id)
                            if value and str(value) not in ('true', 'false'):
                                texts.append(str(value))
                        except Exception:
                            pass
            except Exception:
                pass

        # 完全相同的文本去重，不拼接“碎片字符”。
        out=[]; seen=set()
        for value in texts:
            value=str(value).replace('\x00','')
            if value and value.strip() not in seen:
                seen.add(value.strip())
                out.append(value)
        return '\n'.join(out)

    def get_text_diagnostics(self, hwnd):
        """返回精简、可复现的文本读取诊断。

        诊断不再主动修改 Edit 的选择区、不再复制到剪贴板，也不再堆叠大量
        猜测性读取。核心结果就是外部抓取器同款 WM_GETTEXTLENGTH/WM_GETTEXT，
        另外列出子控件，便于确认“找到的 Edit 是否就是抓取器看到的那个 HWND”。
        """
        hwnd = int(hwnd)
        result = {
            'hwnd': f'0x{hwnd:X}',
            'class_name': '',
            'get_window_text': '',
            'wm_gettext': '',
            'wm_gettext_length': '0',
            'wm_gettext_return': '',
            'wm_gettext_method': '',
            'final_text': '',
            'final_text_length': '0',
            'parent': '',
            'parent_class': '',
            'title': '',
            'style': '',
            'ex_style': '',
            'process_id': '',
            'control_id': '',
            'parent_chain': [],
            'win32_children': [],
            # 保留旧字段，避免旧 GUI/工作流读取时报错；不再执行这些有副作用的探测。
            'edit_getline': '',
            'edit_limit': '',
            'edit_clipboard': '',
            'edit_text_length': '',
            'edit_gettext': '',
            'edit_keyboard_clipboard': '',
            'uia': [],
        }
        try:
            info = self.get_text_details(hwnd, timeout_ms=1200)
            result['class_name'] = info.get('class_name', '')
            result['parent'] = info.get('parent', '')
            result['parent_class'] = info.get('parent_class', '')
            result['process_id'] = info.get('process_id', '')
            result['control_id'] = info.get('control_id', '')
            result['wm_gettext_length'] = str(info.get('length', 0))
            result['wm_gettext_return'] = str(info.get('wm_gettext_return', '') or '')
            result['wm_gettext_method'] = str(info.get('method', '') or '')
            result['final_text'] = str(info.get('text', '') or '')
            result['final_text_length'] = str(len(result['final_text']))
            result['wm_gettext'] = result['final_text']
            result['title'] = win32gui.GetWindowText(hwnd) or ''
            result['get_window_text'] = result['title']
            try:
                result['style'] = f'0x{int(win32gui.GetWindowLong(hwnd, win32con.GWL_STYLE)):X}'
                result['ex_style'] = f'0x{int(win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)):X}'
            except Exception:
                pass
            cur = hwnd
            for _ in range(12):
                par = int(win32gui.GetParent(cur) or 0)
                if not par:
                    break
                try:
                    result['parent_chain'].append(f'0x{par:X}({win32gui.GetClassName(par)})')
                except Exception:
                    result['parent_chain'].append(f'0x{par:X}')
                cur = par
        except Exception as exc:
            result['wm_gettext_method'] = f'诊断失败：{exc}'

        # 列出直接子控件 + 后代，主要用于核对抓取器与本程序是否落在同一个 HWND。
        try:
            for node in self.iter_grabber_tree(hwnd, max_depth=30, limit=500, include_root=False):
                ch = int(node['hwnd'])
                try:
                    result['win32_children'].append({
                        'hwnd': f'0x{ch:X}',
                        'class_name': node.get('class_name') or '',
                        'text': node.get('text') or '',
                    })
                except Exception:
                    pass
        except Exception:
            pass
        return result

    def click(self, hwnd):
        """通过 HWND 执行控件级点击。优先 BM_CLICK；失败时再使用同一 HWND 的同步鼠标消息。"""
        hwnd = int(hwnd)
        if not win32gui.IsWindow(hwnd):
            raise RuntimeError(f"点击目标 HWND 已失效：{hwnd}")
        if not win32gui.IsWindowEnabled(hwnd):
            raise RuntimeError(f"点击目标控件当前不可用：HWND={hwnd}")

        cls = win32gui.GetClassName(hwnd)
        parent = win32gui.GetParent(hwnd)
        title = win32gui.GetWindowText(hwnd)
        try:
            # 激活顶层窗口，而不是把子控件 HWND 直接交给 SetForegroundWindow。
            root = win32gui.GetAncestor(hwnd, win32con.GA_ROOT)
            if root:
                win32gui.SetForegroundWindow(root)
        except Exception:
            pass
        try:
            win32gui.SetFocus(hwnd)
        except Exception:
            pass

        lower_cls = cls.lower()
        if lower_cls == "button" or lower_cls.endswith("button"):
            # 标准 Win32 Button：使用异步 BM_CLICK，避免目标软件在处理按钮事件
            # 时阻塞上号器线程，从而出现 1460 SendMessageTimeout 超时。
            # BM_CLICK 仍然由目标 Button 自己产生正常的点击通知。
            try:
                win32api.PostMessage(hwnd, win32con.BM_CLICK, 0, 0)
                return
            except Exception:
                # 极少数异常情况下，退回到同一 HWND 的同步鼠标消息。
                self._send_handle_mouse_click(hwnd)
                return

        # 第三方/自绘控件通常没有 BM_CLICK，只能对该 HWND 的客户区发送鼠标消息。
        self._send_handle_mouse_click(hwnd)

    def _send_handle_mouse_click(self, hwnd):
        left, top, right, bottom = win32gui.GetClientRect(int(hwnd))
        width = max(1, right - left)
        height = max(1, bottom - top)
        x = max(1, width // 2)
        y = max(1, height // 2)
        lp = win32api.MAKELONG(x, y)
        for msg, wparam in (
            (win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON),
            (win32con.WM_LBUTTONUP, 0),
        ):
            result = win32gui.SendMessageTimeout(
                int(hwnd), msg, wparam, lp,
                win32con.SMTO_ABORTIFHUNG, 1200
            )
            if isinstance(result, tuple) and len(result) >= 1 and not result[0]:
                raise TimeoutError(f"控件没有响应鼠标消息：{win32gui.GetClassName(int(hwnd))}")


    def click_at(self, hwnd, x=None, y=None, button="left"):
        """在指定控件客户区内精确点击。x/y 为客户区坐标；未提供时点击中心。"""
        hwnd=int(hwnd)
        left, top, right, bottom = win32gui.GetClientRect(hwnd)
        if x is None:
            x=(right-left)//2
        if y is None:
            y=(bottom-top)//2
        x=max(0,min(int(x),max(0,right-left-1)))
        y=max(0,min(int(y),max(0,bottom-top-1)))
        lparam=win32api.MAKELONG(x,y)
        if button.lower() == "right":
            win32api.PostMessage(hwnd, win32con.WM_RBUTTONDOWN, win32con.MK_RBUTTON, lparam)
            win32api.PostMessage(hwnd, win32con.WM_RBUTTONUP, 0, lparam)
        else:
            win32api.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lparam)
            win32api.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lparam)

    def client_rect_screen(self, hwnd):
        left, top, right, bottom = win32gui.GetClientRect(int(hwnd))
        p1=win32gui.ClientToScreen(int(hwnd),(left,top))
        p2=win32gui.ClientToScreen(int(hwnd),(right,bottom))
        return p1[0],p1[1],p2[0],p2[1]

    def send_key(self, hwnd, vk):
        win32api.PostMessage(int(hwnd), win32con.WM_KEYDOWN, int(vk), 0)
        win32api.PostMessage(int(hwnd), win32con.WM_KEYUP, int(vk), 0)

    def close(self, hwnd):
        win32gui.PostMessage(int(hwnd), win32con.WM_CLOSE, 0, 0)

    def tree(self, hwnd):
        """返回与句柄查看器相同的统一 HWND 树。"""
        hwnd = int(hwnd)
        try:
            root_cls = win32gui.GetClassName(hwnd)
            root_title = win32gui.GetWindowText(hwnd) or ''
        except Exception:
            root_cls, root_title = '', ''
        lines = [f'ROOT HWND={hwnd} | CLASS="{root_cls}" | TITLE="{root_title}"']
        for node in self.iter_grabber_tree(hwnd, max_depth=30, limit=20000, include_root=False):
            depth = int(node.get('depth', 1))
            lines.append(
                f'{"  " * depth}HWND={node["hwnd"]} | CLASS="{node["selector"]}" | '
                f'TITLE="{node.get("title") or ""}" | TEXT="{node.get("text") or ""}"'
            )
        return "\n".join(lines)
