import csv
from csv_manager import load_rows, load_rows_with_report
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Account:
    account: str
    password: str
    create_time: str = ""
    expire_time: str = ""
    update_time: str = ""
    remark: str = ""
    status: str = "待处理"

    @property
    def username(self):
        return self.account

    def variable(self, name):
        return {
            "account": self.account,
            "username": self.account,
            "password": self.password,
            "create_time": self.create_time,
            "expire_time": self.expire_time,
            "update_time": self.update_time,
            "remark": self.remark,
        }.get(name, "")

def _detect_dialect(sample):
    try:
        return csv.Sniffer().sniff(sample, delimiters=",\t;")
    except csv.Error:
        return csv.excel_tab

def load_accounts(path, with_report=False):
    if with_report:
        rows, report = load_rows_with_report(path)
    else:
        rows = load_rows(path)
        report = {"loaded_rows": len(rows), "skipped_rows": 0, "skipped_lines": []}
    accounts = [Account(
        account=row["account"],
        password=row["password"],
        create_time=row["create_time"],
        expire_time=row["expire_time"],
        update_time=row["update_time"],
        remark=row["remark"],
    ) for row in rows]
    return (accounts, report) if with_report else accounts

def is_expired(account):
    if not account.expire_time:
        return False
    text = account.expire_time.strip()
    formats = ["%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d",
               "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"]
    for fmt in formats:
        try:
            dt = datetime.strptime(text, fmt)
            # 日期型到期日按当天 23:59:59 处理
            if len(text) <= 10:
                from datetime import time as dtime
                dt = datetime.combine(dt.date(), dtime.max)
            return dt < datetime.now()
        except ValueError:
            pass
    return False
