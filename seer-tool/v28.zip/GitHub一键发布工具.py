# -*- coding: utf-8 -*-
"""句柄上号器 GitHub 一键发布工具（独立工具，不嵌入主程序）。
使用 GitHub Personal Access Token，权限至少包含该仓库 Contents: Read and write。
"""
import base64
import hashlib
import json
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
from pathlib import Path
import getpass

OWNER = "2583100599-hue"
REPO = "seer-tool-updates"
BRANCH = "main"
ASSET_NAME = "seer-tool-update.zip"
MANIFEST_PATH = "manifest.json"
PACKAGE_URL = f"https://github.com/{OWNER}/{REPO}/releases/latest/download/{ASSET_NAME}"
MANIFEST_URL = f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{BRANCH}/{MANIFEST_PATH}"


def api(token, method, endpoint, body=None, accept="application/vnd.github+json"):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = Request("https://api.github.com" + endpoint, data=data, method=method, headers={
        "Authorization": "Bearer " + token,
        "Accept": accept,
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "SeerTool-OneClickPublisher/1.0",
        **({"Content-Type": "application/json; charset=utf-8"} if data is not None else {}),
    })
    with urlopen(req, timeout=60) as res:
        payload = res.read()
        return json.loads(payload.decode("utf-8")) if payload else None


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class Publisher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("句柄上号器 · GitHub 一键发布工具")
        self.geometry("760x610")
        self.minsize(700, 560)
        self.package = tk.StringVar()
        self.version = tk.StringVar(value="3.0.28")
        self.tag = tk.StringVar(value="V28")
        self.min_version = tk.StringVar(value="3.0.27")
        self.name = tk.StringVar(value="句柄上号器 3.0.28")
        self.notes = tk.StringVar(value="主页与项目运行方案双向同步修复。")
        self.token = tk.StringVar()
        self._build()

    def _build(self):
        root = ttk.Frame(self, padding=16); root.pack(fill="both", expand=True)
        ttk.Label(root, text="GitHub 一键发布更新", font=("Microsoft YaHei UI", 16, "bold")).pack(anchor="w")
        ttk.Label(root, text=f"仓库：{OWNER}/{REPO}  ·  分支：{BRANCH}").pack(anchor="w", pady=(4, 12))
        form = ttk.Frame(root); form.pack(fill="x")
        def row(label, var, r, browse=False):
            ttk.Label(form, text=label, width=16).grid(row=r, column=0, sticky="w", pady=5)
            ttk.Entry(form, textvariable=var).grid(row=r, column=1, sticky="ew", pady=5)
            if browse:
                ttk.Button(form, text="选择…", command=self.choose).grid(row=r, column=2, padx=(6,0))
        form.columnconfigure(1, weight=1)
        row("更新 ZIP 文件", self.package, 0, True)
        row("应用版本号", self.version, 1)
        row("Release 标签", self.tag, 2)
        row("最低兼容版本", self.min_version, 3)
        row("Release 标题", self.name, 4)
        row("更新说明", self.notes, 5)
        ttk.Label(form, text="GitHub Token", width=16).grid(row=6, column=0, sticky="w", pady=5)
        ttk.Entry(form, textvariable=self.token, show="•").grid(row=6, column=1, sticky="ew", pady=5)
        ttk.Label(root, text="Token 仅用于本次运行，不写入文件。请使用仅有该仓库写入权限的 Fine-grained PAT。", wraplength=700).pack(anchor="w", pady=(8,4))
        ttk.Label(root, text="清单固定地址：" + MANIFEST_URL, wraplength=700).pack(anchor="w", pady=3)
        ttk.Label(root, text="Release 固定资产名：" + ASSET_NAME, wraplength=700).pack(anchor="w", pady=3)
        self.progress = ttk.Progressbar(root, mode="indeterminate"); self.progress.pack(fill="x", pady=(12,6))
        self.log = tk.Text(root, height=10, wrap="word", state="disabled"); self.log.pack(fill="both", expand=True)
        self.publish_btn = ttk.Button(root, text="生成清单并发布 Release", command=self.publish); self.publish_btn.pack(anchor="e", pady=(10,0))

    def choose(self):
        p = filedialog.askopenfilename(title="选择更新 ZIP", filetypes=[("ZIP 文件", "*.zip")])
        if p: self.package.set(p)

    def say(self, msg):
        def append():
            self.log.configure(state="normal"); self.log.insert("end", msg + "\n"); self.log.see("end"); self.log.configure(state="disabled")
        self.after(0, append)

    def publish(self):
        path = Path(self.package.get().strip().strip('"')).expanduser()
        version = self.version.get().strip(); tag = self.tag.get().strip()
        min_version = self.min_version.get().strip(); notes = self.notes.get().strip()
        title = self.name.get().strip(); token = self.token.get().strip()
        if not path.is_file() or path.suffix.lower() != ".zip":
            messagebox.showerror("参数错误", "请选择存在的更新 ZIP 文件。"); return
        if not version or not tag or not title or not token:
            messagebox.showerror("参数错误", "版本号、Release 标签、标题和 GitHub Token 都不能为空。"); return
        if path.stat().st_size > 2 * 1024 * 1024 * 1024:
            messagebox.showerror("参数错误", "更新 ZIP 大于 2GB，超出本工具的简单上传限制。"); return
        self.publish_btn.configure(state="disabled"); self.progress.start(10)
        threading.Thread(target=self._publish_worker, args=(path, version, tag, min_version, notes, title, token), daemon=True).start()

    def _publish_worker(self, path, version, tag, min_version, notes, title, token):
        try:
            self.say("1/5 正在计算 SHA-256…")
            digest = sha256(path)
            manifest = {"version": version, "package_url": PACKAGE_URL, "sha256": digest, "min_version": min_version, "notes": notes}
            self.say("SHA-256：" + digest)
            # 先检查标签是否已存在，避免意外覆盖既有 Release。
            self.say("2/5 检查 Release 标签…")
            endpoint = f"/repos/{OWNER}/{REPO}/releases/tags/{quote(tag, safe='')}"
            try:
                api(token, "GET", endpoint)
                raise RuntimeError(f"Release 标签 {tag} 已存在。为避免覆盖旧发布，请使用新的标签；若要重发请先手动处理旧 Release。")
            except HTTPError as e:
                if e.code != 404: raise
            self.say("3/5 创建 GitHub Release…")
            rel = api(token, "POST", f"/repos/{OWNER}/{REPO}/releases", {
                "tag_name": tag, "name": title, "body": notes,
                "draft": False, "prerelease": False,
                "target_commitish": BRANCH,
            })
            upload_url = rel.get("upload_url", "").split("{", 1)[0]
            if not upload_url: raise RuntimeError("GitHub 未返回 Release 资产上传地址。")
            self.say("4/5 上传固定名称更新包…")
            req = Request(upload_url + "?name=" + quote(ASSET_NAME), data=path.read_bytes(), method="POST", headers={
                "Authorization": "Bearer " + token,
                "Accept": "application/vnd.github+json",
                "Content-Type": "application/zip",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "SeerTool-OneClickPublisher/1.0",
            })
            with urlopen(req, timeout=180) as response:
                uploaded = json.loads(response.read().decode("utf-8"))
            if uploaded.get("name") != ASSET_NAME:
                raise RuntimeError("上传资产名称与要求不符，已停止更新 manifest.json。")
            # Release 资产上传成功后，再更新 main/manifest.json。
            self.say("5/5 更新 main 分支 manifest.json…")
            content_endpoint = f"/repos/{OWNER}/{REPO}/contents/{MANIFEST_PATH}"
            old = api(token, "GET", content_endpoint + "?ref=" + quote(BRANCH, safe=""))
            content = base64.b64encode((json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")).decode("ascii")
            api(token, "PUT", content_endpoint, {
                "message": f"Publish update manifest {version}",
                "content": content,
                "sha": old["sha"],
                "branch": BRANCH,
            })
            self.say("发布成功！")
            self.say("Release：" + rel.get("html_url", ""))
            self.say("更新 ZIP：" + uploaded.get("browser_download_url", ""))
            self.say("manifest.json：" + MANIFEST_URL)
            self.say("版本：" + version + "；SHA-256：" + digest)
            self.after(0, lambda: messagebox.showinfo("发布成功", "Release 资产与 manifest.json 已更新。\n\n请等待 GitHub CDN/Raw 缓存刷新后，再用另一台设备检查更新。"))
        except HTTPError as e:
            details = e.read().decode("utf-8", "replace")[:1200]
            self.say(f"GitHub API 错误 HTTP {e.code}：{details}")
            self.after(0, lambda: messagebox.showerror("发布失败", f"GitHub API 返回 HTTP {e.code}。请检查 Token 权限、仓库权限和网络。详情已写入日志。"))
        except Exception as e:
            self.say("发布失败：" + str(e))
            self.after(0, lambda: messagebox.showerror("发布失败", str(e)))
        finally:
            self.after(0, self.progress.stop)
            self.after(0, lambda: self.publish_btn.configure(state="normal"))


if __name__ == "__main__":
    Publisher().mainloop()
