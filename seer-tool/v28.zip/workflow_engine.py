import json
import math
import time
import threading
import win32con
from win32_controller import Win32Controller
from process_manager import terminate_process_by_pid

class WorkflowExit(Exception):
    """控制当前账号工作流结束。terminate_process=True 表示已按“结束该次循环”结束目标进程。"""
    def __init__(self, reason="workflow_exit", terminate_process=False):
        super().__init__(reason)
        self.reason = reason
        self.terminate_process = bool(terminate_process)


class WorkflowEngine:
    def __init__(self, logger=None):
        self.ctrl = Win32Controller()
        self.logger = logger or (lambda x: None)
        self.handles = {}
        self.handle_specs = {}
        self.stop_event = threading.Event()
        self.pause_event = threading.Event()
        self.pause_event.set()
        self.runtime_context = {}
        self.status_callback = None
        self.variables = {}

    def stop(self):
        self.stop_event.set()

    def pause(self):
        self.pause_event.clear()

    def resume(self):
        self.pause_event.set()

    def check(self):
        if self.stop_event.is_set():
            raise InterruptedError("工作流已停止")
        self.pause_event.wait()
        if self.stop_event.is_set():
            raise InterruptedError("工作流已停止")

    def wait(self, seconds):
        # 使用 monotonic 避免系统时间调整影响等待；暂停/恢复后剩余时间可能已为负，绝不向 sleep 传负数。
        end = time.monotonic() + max(0.0, float(seconds))
        while True:
            self.check()
            remaining = end - time.monotonic()
            if remaining <= 0:
                return
            time.sleep(min(0.1, max(0.0, remaining)))

    def substitute(self, value, account, pid):
        if not isinstance(value, str):
            return value
        now = time.localtime()
        # 先保护密码本身，避免密码内容恰好包含 {pid}/{date}/{变量} 时被二次替换。
        password_token = "__SEER_LITERAL_PASSWORD_9f2d__"
        value = value.replace("{password}", password_token)
        vals = {
            "{account}": account.account,
            "{username}": account.account,
            "{password}": password_token,
            "{create_time}": account.create_time,
            "{expire_time}": account.expire_time,
            "{update_time}": account.update_time,
            "{remark}": account.remark,
            "{pid}": str(pid),
            "{run_no}": str(self.runtime_context.get("run_no", "")),
            "{total}": str(self.runtime_context.get("total", "")),
            "{step}": str(self.runtime_context.get("step", "")),
            "{step_count}": str(self.runtime_context.get("step_count", "")),
            "{last_text}": str(self.runtime_context.get("last_text", "")),
            "{status}": str(self.runtime_context.get("status", "")),
            "{now}": time.strftime("%Y-%m-%d %H:%M:%S", now),
            "{date}": time.strftime("%Y-%m-%d", now),
            "{time}": time.strftime("%H:%M:%S", now),
        }
        for k, v in vals.items():
            value = value.replace(k, str(v))
        # 工作流自定义变量：支持 {变量名} 替换。
        for k, v in self.variables.items():
            value = value.replace("{" + str(k) + "}", str(v))
        return value.replace(password_token, str(account.password))

    def _set_variable(self, name, value, account, pid):
        name = str(name or "").strip()
        if not name:
            raise ValueError("变量名不能为空")
        self.variables[name] = self.substitute(value, account, pid)
        return self.variables[name]

    def _evaluate_condition_node(self, node, account, pid):
        if not isinstance(node, dict):
            raise ValueError("条件节点必须是对象")
        op = str(node.get("op", "condition") or "condition").lower()
        if op in ("and", "or"):
            items = node.get("items", [])
            if not isinstance(items, list) or not items:
                raise ValueError(f"{op.upper()} 条件必须包含 items")
            vals = [self._evaluate_condition_node(x, account, pid)[0] for x in items]
            ok = all(vals) if op == "and" else any(vals)
            return ok, f"{op.upper()}={'满足' if ok else '不满足'}（{len(items)} 项）"
        if op == "not":
            child = node.get("item") or node.get("condition")
            ok, desc = self._evaluate_condition_node(child, account, pid)
            return (not ok), f"NOT（{desc}）"
        step = dict(node)
        if "condition" not in step and "type" in step:
            step["condition"] = step["type"]
        return self._evaluate_condition(step, account, pid)

    def load(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _retry_count(self, step, default=0):
        """返回失败重试次数。retry_count 表示“额外重试几次”，不包含首次执行。"""
        raw = step.get("retry_count", default)
        try:
            return max(0, int(raw or 0))
        except (TypeError, ValueError):
            return max(0, int(default))

    def _retry_interval(self, step, default=0.5):
        try:
            return max(0.05, float(step.get("retry_interval", default) or default))
        except (TypeError, ValueError):
            return max(0.05, float(default))

    def _detection_retry_count(self, step):
        # 检测类动作对旧工作流也自动启用失败重试；显式 retry_count=0 仍表示关闭重试。
        return self._retry_count(step, default=2)

    def _detection_retry_interval(self, step):
        return self._retry_interval(step, default=0.5)

    def _remember_handle(self, name, kind, step):
        if name:
            self.handle_specs[name] = {"kind": kind, "step": json.loads(json.dumps(step, ensure_ascii=False))}

    def _resolve_handle(self, name, account, pid, refresh=True):
        name = str(name or "").strip()
        if not name or name not in self.handles:
            raise RuntimeError(f"句柄不存在：{name}")
        hwnd = int(self.handles[name])
        if self.ctrl_is_window(hwnd):
            return hwnd
        if not refresh or name not in self.handle_specs:
            raise RuntimeError(f"句柄已失效：{name}=0x{hwnd:X}")
        spec = self.handle_specs[name]
        step = spec["step"]
        self.logger(f"句柄失效：{name}=0x{hwnd:X}，尝试按原定位规则重新查找")
        if spec["kind"] == "window":
            hs = self.ctrl.find_windows(
                title=self.substitute(step.get("title"), account, pid) if step.get("title") is not None else None,
                class_name=step.get("class_name"), pid=pid if step.get("pid_current", True) else None,
                exact_title=step.get("exact_title", False), occurrence=step.get("occurrence"),
                visible_only=step.get("visible_only", False), enabled_only=step.get("enabled_only", False))
            pick = max(0, int(step.get("occurrence", 1)) - 1) if step.get("occurrence") is not None else int(step.get("index", 0))
            if pick < len(hs):
                self.handles[name] = hs[pick]
        else:
            parent_name = step.get("parent")
            parent = self._resolve_handle(parent_name, account, pid, refresh=True)
            h = self.ctrl.find_child(parent, title=step.get("title"), class_name=step.get("class_name"),
                                     index=step.get("index", 0), exact_title=step.get("exact_title", False),
                                     occurrence=step.get("occurrence"), visible_only=step.get("visible_only", False),
                                     enabled_only=step.get("enabled_only", False),
                                     recursive=step.get("recursive", True))
            if h:
                self.handles[name] = h
        hwnd = int(self.handles[name])
        if not self.ctrl_is_window(hwnd):
            raise RuntimeError(f"句柄失效且无法重新定位：{name}")
        self.logger(f"句柄已重新定位：{name}=0x{hwnd:X} ClassName={self.ctrl.get_class_name(hwnd)}")
        return hwnd

    def _handle_retry_exhausted(self, step, pid, label):
        """重试失败后的统一处理。返回 True 表示进入下一步；结束当前循环则抛出 WorkflowExit。"""
        action = str(step.get("retry_fail_action", "进入下一步") or "进入下一步").strip()
        if action in ("结束该次循环", "结束该进程", "terminate_process", "kill_process"):
            # 与“按设置进入下一步”有意采用不同严重度：此分支会终止目标进程并结束当前账号循环，属于账号级执行失败。
            try:
                ok = terminate_process_by_pid(int(pid)) if pid else False
                self.logger(f"{label}：重试失败，{'已结束' if ok else '尝试结束'}当前目标进程 PID={pid}")
            except Exception as exc:
                self.logger(f"{label}：结束当前目标进程失败：{exc}")
            raise WorkflowExit("retry_exhausted_end_loop", terminate_process=True)
        self.logger(f"{label}：重试失败，按设置进入下一步")
        return True

    def _run_find_with_retry(self, finder, label, step):
        attempts = self._retry_count(step) + 1
        last = None
        for attempt in range(1, attempts + 1):
            self.check()
            try:
                result = finder()
                if result:
                    if attempt > 1:
                        self.logger(f"{label}：第 {attempt} 次重试成功")
                    return result
                last = f"未找到匹配对象"
            except Exception as e:
                last = str(e)
            if attempt < attempts:
                self.logger(f"{label}：第 {attempt} 次未成功，{self._retry_interval(step):g} 秒后重试")
                self.wait(self._retry_interval(step))
        self._handle_retry_exhausted(step, self.runtime_context.get("pid", 0), label)
        return None

    def _condition_target_text(self, step, account, pid):
        target_name = str(step.get("target", "") or "").strip()
        if not target_name:
            return "", ""
        target = self._resolve_handle(target_name, account, pid)
        return target_name, str(self.ctrl.get_text(target, include_children=True) or "")

    def _evaluate_condition(self, step, account, pid):
        """统一条件判断。返回 (是否满足, 说明)。支持 AND/OR/NOT。"""
        if step.get("logic") or step.get("conditions") or step.get("op") in ("and", "or", "not"):
            root = step.get("logic") or step.get("conditions") or step
            if isinstance(root, list):
                root = {"op": "and", "items": root}
            return self._evaluate_condition_node(root, account, pid)
        ctype = str(step.get("condition", "keyword_contains") or "keyword_contains").strip()

        if ctype in ("keyword_contains", "keyword_not_contains", "text_equals", "text_not_equals", "text_not_empty"):
            target_name, actual = self._condition_target_text(step, account, pid)
            if not target_name:
                return False, "未指定目标句柄"
            expected = self.substitute(step.get("keyword", step.get("expected", "")), account, pid)
            if ctype == "keyword_contains":
                ok = str(expected) in actual
                return ok, f"目标={target_name}，文本{'包含' if ok else '不包含'}“{expected}”"
            if ctype == "keyword_not_contains":
                ok = str(expected) not in actual
                return ok, f"目标={target_name}，文本{'不包含' if ok else '包含'}“{expected}”"
            if ctype == "text_equals":
                ok = actual == str(expected)
                return ok, f"目标={target_name}，文本{'等于' if ok else '不等于'}“{expected}”"
            if ctype == "text_not_equals":
                ok = actual != str(expected)
                return ok, f"目标={target_name}，文本{'不等于' if ok else '等于'}“{expected}”"
            ok = bool(actual.strip())
            return ok, f"目标={target_name}，文本{'非空' if ok else '为空'}"

        if ctype == "handle_exists":
            name = str(step.get("target", "") or "").strip()
            if not name:
                return False, "未指定目标句柄"
            hwnd = self.handles.get(name)
            ok = bool(hwnd and self.ctrl_is_window(hwnd))
            return ok, f"句柄 {name} {'存在' if ok else '不存在'}"

        if ctype in ("handle_visible", "handle_enabled"):
            import win32gui
            name = str(step.get("target", "") or "").strip()
            if not name:
                return False, "未指定目标句柄"
            try:
                hwnd = self._resolve_handle(name, account, pid)
            except Exception:
                return False, f"句柄 {name} 不存在或已失效"
            if ctype == "handle_visible":
                ok = bool(win32gui.IsWindowVisible(hwnd))
                return ok, f"句柄 {name} {'可见' if ok else '不可见'}"
            ok = bool(win32gui.IsWindowEnabled(hwnd))
            return ok, f"句柄 {name} {'已启用' if ok else '未启用'}"

        if ctype in ("window_exists", "window_not_exists"):
            title = self.substitute(step.get("title", ""), account, pid)
            class_name = str(step.get("class_name", "") or "").strip() or None
            hs = self.ctrl.find_windows(
                title=title,
                class_name=class_name,
                pid=pid if step.get("pid_current", True) else None,
                exact_title=step.get("exact_title", False),
                visible_only=step.get("visible_only", False),
                enabled_only=step.get("enabled_only", False),
            )
            exists = bool(hs)
            ok = exists if ctype == "window_exists" else not exists
            return ok, f"窗口“{title or class_name or '未指定'}”{'存在' if exists else '不存在'}"

        raise ValueError(f"未知条件类型：{ctype}")

    def _run_nested_steps(self, steps, account, pid, branch_name="分支"):
        if not isinstance(steps, list):
            raise ValueError(f"{branch_name}步骤必须是 JSON 数组")
        parent_path = str(self.runtime_context.get("step_path", self.runtime_context.get("step", "")))
        for idx, nested in enumerate(steps, 1):
            if not isinstance(nested, dict):
                self.runtime_context["step_path"] = f"{parent_path} → {branch_name}第 {idx} 步"
                raise ValueError(f"{branch_name}第 {idx} 个步骤不是对象")
            self.runtime_context["step_path"] = f"{parent_path} → {branch_name}第 {idx} 步"
            if nested.get("enabled", True) is False:
                self.logger(f"{branch_name}第 {idx} 步已禁用，跳过")
                continue
            self.run_step(nested, account, pid)

    def validate_workflow(self, workflow):
        """递归运行前静态检查；错误路径会标明具体分支，不操作目标软件。"""
        errors, warnings = [], []
        if not isinstance(workflow, dict):
            return {"errors": ["工作流根数据不是对象"], "warnings": []}
        steps = workflow.get("steps")
        if not isinstance(steps, list):
            return {"errors": ["工作流缺少 steps 数组"], "warnings": []}
        if not steps:
            return {"errors": ["工作流没有可执行步骤"], "warnings": []}
        if not any(isinstance(x, dict) and x.get("enabled", True) is not False for x in steps):
            errors.append("工作流所有步骤都已禁用")
            return {"errors": errors, "warnings": warnings}

        known = {"wait", "check_keyword", "wait_keyword", "wait_condition", "find_window", "find_child",
                 "set_text", "click", "send_key", "close_window", "if_window_exists", "if_condition",
                 "set_variable", "set_status", "log"}

        def validate_steps(step_list, prefix, saved_before=None):
            if not isinstance(step_list, list):
                errors.append(f"{prefix}必须是 JSON 数组")
                return
            saved = set(saved_before or ())
            for i, step in enumerate(step_list, 1):
                path = f"{prefix}第 {i} 步"
                if not isinstance(step, dict):
                    errors.append(f"{path}不是有效对象")
                    continue
                if step.get("enabled", True) is False:
                    continue
                action = str(step.get("action", "")).strip()
                if action not in known:
                    errors.append(f"{path}：未知操作 {action or '空'}")
                    continue

                # 在运行前拦截常见的数值配置错误，避免启动后才在转换或等待阶段失败。
                numeric_rules = {
                    "seconds": (0.0, None, "等待秒数"),
                    "timeout_seconds": (0.0, None, "超时秒数"),
                    "interval_seconds": (0.0, None, "检测间隔"),
                    "retry_interval": (0.0, None, "重试间隔"),
                    "retry_count": (0, None, "重试次数"),
                    "index": (0, None, "控件序号 index"),
                    "occurrence": (1, None, "出现序号 occurrence"),
                }
                for field, (minimum, maximum, label) in numeric_rules.items():
                    if field not in step or step.get(field) in (None, ""):
                        continue
                    raw = step.get(field)
                    try:
                        number = float(raw)
                        if not math.isfinite(number):
                            raise ValueError("不是有限数值")
                        if number < minimum:
                            errors.append(f"{path}：{label}不能小于 {minimum}")
                        if field in ("retry_count", "index", "occurrence") and not number.is_integer():
                            errors.append(f"{path}：{label}必须是整数")
                    except (TypeError, ValueError, OverflowError):
                        errors.append(f"{path}：{label}不是有效数值")

                if action in ("find_window", "find_child"):
                    selector_title = str(step.get("title", "") or "").strip()
                    selector_class = str(step.get("class_name", "") or "").strip()
                    if not selector_title and not selector_class:
                        warnings.append(f"{path}：没有填写窗口标题或类名，查找将依赖默认序号，可能匹配不到目标")
                    name = str(step.get("save_as", "") or "").strip()
                    if not name:
                        errors.append(f"{path}：没有填写保存句柄名称")
                    else:
                        saved.add(name)
                    if action == "find_child":
                        parent = str(step.get("parent", "") or "").strip()
                        if parent and parent not in saved:
                            warnings.append(f"{path}：父句柄“{parent}”在此前步骤中未保存；若由分支产生可忽略")
                if action in ("set_text", "click", "send_key", "close_window", "check_keyword", "wait_keyword"):
                    target = str(step.get("target", "") or "").strip()
                    if not target:
                        errors.append(f"{path}：未指定目标句柄")
                    elif target not in saved:
                        warnings.append(f"{path}：目标句柄“{target}”在此前步骤中未保存；若由分支产生可忽略")
                if action in ("check_keyword", "wait_keyword") and not str(step.get("keyword", "") or "").strip():
                    errors.append(f"{path}：关键字不能为空")
                if action in ("if_condition", "wait_condition"):
                    ctype = str(step.get("condition", "keyword_contains") or "keyword_contains")
                    if ctype in ("keyword_contains", "keyword_not_contains", "text_equals", "text_not_equals",
                                 "text_not_empty", "handle_exists", "handle_visible", "handle_enabled"):
                        if not str(step.get("target", "") or "").strip():
                            errors.append(f"{path}：条件未指定目标句柄")
                    if ctype in ("keyword_contains", "keyword_not_contains") and not str(step.get("keyword", "") or "").strip():
                        errors.append(f"{path}：条件关键字不能为空")
                if action == "if_condition":
                    for key, label in (("then", "满足条件分支"), ("else", "否则分支")):
                        branch = step.get(key, [])
                        branch_path = f"{path} → {label}"
                        if not isinstance(branch, list):
                            errors.append(f"{branch_path}必须是 JSON 数组")
                        else:
                            validate_steps(branch, branch_path + " → ", saved)
                elif action == "if_window_exists":
                    if not str(step.get("title", "") or "").strip() and not str(step.get("class_name", "") or "").strip():
                        errors.append(f"{path}：窗口存在判断至少需要填写标题或类名")
                    branch = step.get("then", [])
                    branch_path = f"{path} → 窗口存在分支"
                    if not isinstance(branch, list):
                        errors.append(f"{branch_path}必须是 JSON 数组")
                    else:
                        validate_steps(branch, branch_path + " → ", saved)
        validate_steps(steps, "")
        return {"errors": errors, "warnings": warnings}

    def run(self, workflow, account, pid, run_no=None, total=None):
        self.handles = {}
        self.handle_specs = {}
        self.variables = {}
        self.runtime_context.update({
            "run_no": run_no if run_no is not None else self.runtime_context.get("run_no", ""),
            "total": total if total is not None else self.runtime_context.get("total", ""),
            "pid": str(pid),
            "step": 0,
            "step_count": len(workflow.get("steps", [])),
            "last_text": "",
            "status": "",
            "last_error": "",
            "last_error_step": "",
            "last_error_action": "",
            "last_error_type": "",
            "step_path": "",
        })
        steps = workflow.get("steps", [])
        step_total = len(steps)
        for i, step in enumerate(steps, 1):
            self.check()
            action_name = step.get("action", "")
            self.runtime_context["step"] = i
            self.runtime_context["step_path"] = str(i)
            if step.get("enabled", True) is False:
                self.logger(f"跳过步骤 {i}/{step_total}：{action_name}（已禁用）")
                continue
            self.logger(f"开始步骤 {i}/{step_total}：{action_name}")
            try:
                self.run_step(step, account, pid)
            except WorkflowExit as exc:
                self.logger(f"步骤 {i}/{step_total}：按工作流条件结束当前账号流程")
                # 不在这里吞掉 WorkflowExit。上层运行器必须知道这是“结束循环”还是正常完成，
                # 尤其是检测失败后主动结束目标进程时，不能再被误判为“登录成功”。
                raise
            except Exception as e:
                error_path = str(self.runtime_context.get("step_path") or i)
                self.runtime_context["last_error"] = str(e)
                self.runtime_context["last_error_step"] = error_path
                self.runtime_context["last_error_action"] = str(action_name or "未知操作")
                self.runtime_context["last_error_type"] = type(e).__name__
                self.logger(f"步骤定位：{error_path}（顶层 {i}/{step_total}，操作={action_name or '未知操作'}）")
                self.logger(f"步骤 {i}/{step_total} 失败：{type(e).__name__}: {e}")
                raise
            self.logger(f"步骤 {i}/{step_total} 完成")

    def ctrl_is_window(self, hwnd):
        try:
            import win32gui
            return bool(win32gui.IsWindow(int(hwnd)))
        except Exception:
            return False

    def run_step(self, step, account, pid):
        action = step.get("action", "").lower()
        if action == "wait":
            self.wait(step.get("seconds", 1))
        elif action in ("check_keyword", "wait_keyword"):
            target_name = str(step.get("target", "")).strip()
            if not target_name:
                raise RuntimeError("关键字检测未指定目标句柄。")
            if target_name not in self.handles:
                root = self.handles.get("主窗口") or self.handles.get("main_window")
                if root and any(ch in target_name for ch in "[]"):
                    h = self.ctrl.find_child(root, class_name=target_name, index=0)
                    if h:
                        self.handles[target_name] = h
                        self.handle_specs[target_name] = {"kind":"child", "step":{"parent":"主窗口","class_name":target_name}}
            keyword = self.substitute(step.get("keyword", ""), account, pid)
            if not keyword:
                raise RuntimeError("关键字不能为空。")
            delay = max(0.05, float(step.get("delay_seconds", 1) or 1))
            retry_count = self._detection_retry_count(step)
            retry_interval = self._detection_retry_interval(step)
            attempts = retry_count + 1

            if action == "check_keyword":
                for attempt in range(1, attempts + 1):
                    self.check()
                    try:
                        target = self._resolve_handle(target_name, account, pid)
                        exact = self.ctrl.get_text_details(target, timeout_ms=1200)
                        actual = str(exact.get("text") or "")
                        self.runtime_context["last_text"] = actual
                        read_method = str(exact.get("method") or "")
                        if not actual:
                            actual = str(self.ctrl.get_text(target, include_children=True, timeout_ms=1200) or "")
                        if actual and read_method:
                            self.logger(
                                f"文本读取：HWND={exact.get('hwnd')} ClassName={exact.get('class_name') or '空'} "
                                f"WM_GETTEXTLENGTH={exact.get('length', 0)} 读取长度={len(actual)} 方式={read_method}"
                            )
                        # 关键字检测如果完全读不到文字，继续输出诊断，便于定位 HWND / 控件文本来源。
                        if not actual:
                            try:
                                diag = self.ctrl.get_text_diagnostics(target)
                                cls = str(diag.get("class_name", ""))
                                basic = str(diag.get("get_window_text", ""))
                                wm = str(diag.get("wm_gettext", ""))
                                children = diag.get("win32_children", []) or []
                                uia = diag.get("uia", []) or []
                                child_preview = []
                                for item in children[:12]:
                                    txt = str(item.get("text", "") or "").replace("\n", " | ").strip()
                                    if txt:
                                        child_preview.append(f'{item.get("hwnd", "")}/{item.get("class", "") }={txt[:80]}')
                                uia_preview = []
                                for item in uia[:12]:
                                    vals = []
                                    for k in ("name", "value", "text"):
                                        v = str(item.get(k, "") or "").replace("\n", " | ").strip()
                                        if v:
                                            vals.append(f"{k}={v[:80]}")
                                    if vals:
                                        uia_preview.append("{" + ", ".join(vals) + "}")
                                self.logger(
                                    f"文本读取诊断：HWND={diag.get('hwnd','')}，ClassName={cls or '空'}；"
                                    f"父HWND={diag.get('parent','') or '空'}；"
                                    f"WM_GETTEXTLENGTH={diag.get('wm_gettext_length','') or '0'}；"
                                    f"WM_GETTEXT返回={diag.get('wm_gettext_return','') or '空'}；"
                                    f"读取方式={diag.get('wm_gettext_method','') or '空'}；"
                                    f"GetWindowText={basic[:120] or '空'}；WM_GETTEXT={wm[:120] or '空'}；"
                                    f"Win32子控件={len(children)}个"
                                )
                                if "edit" in cls.lower():
                                    self.logger(
                                        f"Edit专用诊断：EM_GETTEXT={str(diag.get('edit_gettext','') or '')[:160] or '空'}；"
                                        f"EM_GETTEXTLENGTH={diag.get('edit_text_length','') or '空'}；"
                                        f"EM_GETLINE={str(diag.get('edit_getline','') or '')[:160] or '空'}；"
                                        f"EM_GETLIMITTEXT={diag.get('edit_limit','') or '空'}；"
                                        f"复制读取={str(diag.get('edit_clipboard','') or '')[:160] or '空'}；"
                                        f"Ctrl+C读取={str(diag.get('edit_keyboard_clipboard','') or '')[:160] or '空'}；"
                                        f"Style={diag.get('style','') or '空'}"
                                    )
                                    self.logger(
                                        f"控件身份诊断：PID={diag.get('process_id','') or '空'}；控件ID={diag.get('control_id','') or '空'}；"
                                        f"父链={' -> '.join(diag.get('parent_chain',[])[:8]) or '空'}"
                                    )
                                if child_preview:
                                    self.logger("文本读取诊断：子控件文本：" + " || ".join(child_preview))
                                if uia_preview:
                                    self.logger("文本读取诊断：UIA文本：" + " || ".join(uia_preview))
                            except Exception as diag_err:
                                self.logger(f"文本读取诊断失败：{diag_err}")
                    except (WorkflowExit, InterruptedError):
                        raise
                    except Exception as exc:
                        actual = ""
                        self.runtime_context["last_text"] = ""
                        self.logger(f"关键字检测本次尝试异常：{exc}")

                    if keyword in actual:
                        self.logger(f"关键字检测：目标={target_name}，找到关键字“{keyword}”，立即执行下一步" + (f"（第 {attempt} 次尝试）" if attempt > 1 else ""))
                        return

                    preview = actual.replace("\n", " | ").strip()
                    if len(preview) > 220:
                        preview = preview[:220] + "…"
                    if attempt < attempts:
                        if preview:
                            self.logger(f"关键字检测：目标={target_name}，第 {attempt} 次未找到“{keyword}”；当前读取到：{preview}")
                        else:
                            self.logger(f"关键字检测：目标={target_name}，第 {attempt} 次未读取到文字；未找到“{keyword}”")
                        self.logger(f"关键字检测失败重试：{retry_interval:g} 秒后进行第 {attempt + 1} 次尝试（共 {attempts} 次）")
                        self.wait(retry_interval)
                        continue

                    if preview:
                        self.logger(f"关键字检测：目标={target_name}，未找到“{keyword}”；当前读取到：{preview}")
                    else:
                        self.logger(f"关键字检测：目标={target_name}，未读取到文字；未找到“{keyword}”")
                    self.logger(f"关键字检测：目标={target_name}，达到最大重试次数后判定当前步骤失败")
                    self._handle_retry_exhausted(step, pid, f"关键字检测目标={target_name}")
                    return
                return

            # 等待直到关键字出现：一个“等待周期”算一次失败；超时/异常后按 retry_count 重新开启完整等待周期。
            timeout = max(0.0, float(step.get("timeout_seconds", 30) or 30))
            attempts = retry_count + 1
            for attempt in range(1, attempts + 1):
                deadline = time.time() + timeout
                first = True
                try:
                    while True:
                        self.check()
                        target = self._resolve_handle(target_name, account, pid)
                        exact = self.ctrl.get_text_details(target, timeout_ms=1200)
                        actual = str(exact.get("text") or "")
                        self.runtime_context["last_text"] = actual
                        read_method = str(exact.get("method") or "")
                        if not actual:
                            actual = str(self.ctrl.get_text(target, include_children=True, timeout_ms=1200) or "")
                        if actual and read_method:
                            self.logger(
                                f"文本读取：HWND={exact.get('hwnd')} ClassName={exact.get('class_name') or '空'} "
                                f"WM_GETTEXTLENGTH={exact.get('length', 0)} 读取长度={len(actual)} 方式={read_method}"
                            )
                        if keyword in actual:
                            self.logger(f"关键字检测：目标={target_name}，找到关键字“{keyword}”，立即执行下一步" + (f"（第 {attempt} 个等待周期）" if attempt > 1 else ""))
                            return
                        if first:
                            self.logger(f"等待关键字：目标={target_name}，等待“{keyword}”，最长 {timeout:g} 秒" + (f"（第 {attempt}/{attempts} 个周期）" if attempts > 1 else ""))
                            first = False
                        if time.time() >= deadline:
                            raise TimeoutError(f"等待关键字超时：{keyword}，已等待 {timeout:g} 秒")
                        self.wait(delay)
                except (WorkflowExit, InterruptedError):
                    raise
                except Exception as exc:
                    if attempt < attempts:
                        self.logger(f"等待关键字失败：{exc}；{retry_interval:g} 秒后进行第 {attempt + 1} 次失败重试（共 {attempts} 次尝试）")
                        self.wait(retry_interval)
                        continue
                    self._handle_retry_exhausted(step, pid, f"等待关键字目标={target_name}")
                    return

        elif action == "wait_condition":
            timeout = max(0.0, float(step.get("timeout_seconds", 30) or 30))
            interval = max(0.05, float(step.get("delay_seconds", 1) or 1))
            retry_count = self._detection_retry_count(step)
            retry_interval = self._detection_retry_interval(step)
            attempts = retry_count + 1
            last_desc = ""
            for attempt in range(1, attempts + 1):
                deadline = time.time() + timeout
                self.logger(f"等待条件：最长 {timeout:g} 秒，检测间隔 {interval:g} 秒" + (f"（第 {attempt}/{attempts} 个等待周期）" if attempts > 1 else ""))
                try:
                    while True:
                        self.check()
                        ok, last_desc = self._evaluate_condition(step, account, pid)
                        self.runtime_context["last_text"] = last_desc
                        if ok:
                            self.logger(f"等待条件满足：{last_desc}")
                            return
                        if time.time() >= deadline:
                            mode = str(step.get("timeout_action", "流程失败") or "流程失败")
                            self.logger(f"等待条件超时：{last_desc}")
                            if mode in ("继续下一步", "continue"):
                                return
                            if mode in ("退出当前账号流程", "exit_workflow"):
                                raise WorkflowExit()
                            raise TimeoutError(f"等待条件超时：{last_desc}，已等待 {timeout:g} 秒")
                        self.wait(interval)
                except WorkflowExit:
                    raise
                except InterruptedError:
                    raise
                except Exception as exc:
                    if attempt < attempts:
                        self.logger(f"等待条件检测失败：{exc}；{retry_interval:g} 秒后进行第 {attempt + 1} 次失败重试（共 {attempts} 次尝试）")
                        self.wait(retry_interval)
                        continue
                    self._handle_retry_exhausted(step, pid, "等待条件")
                    return

        elif action == "if_condition":
            retry_count = self._detection_retry_count(step)
            retry_interval = self._detection_retry_interval(step)
            attempts = retry_count + 1
            ok = False
            desc = ""
            for attempt in range(1, attempts + 1):
                self.check()
                try:
                    ok, desc = self._evaluate_condition(step, account, pid)
                except (WorkflowExit, InterruptedError):
                    raise
                except Exception as exc:
                    if attempt < attempts:
                        self.logger(f"条件判断第 {attempt} 次检测异常：{exc}；{retry_interval:g} 秒后重试")
                        self.wait(retry_interval)
                        continue
                    self._handle_retry_exhausted(step, pid, "条件判断")
                    return
                if ok:
                    if attempt > 1:
                        self.logger(f"条件判断：第 {attempt} 次重试后满足条件；{desc}")
                    break
                if attempt < attempts:
                    self.logger(f"条件判断：第 {attempt} 次不满足；{desc}；{retry_interval:g} 秒后进行第 {attempt + 1} 次失败重试")
                    self.wait(retry_interval)
            branch = step.get("then", []) if ok else step.get("else", [])
            branch_name = "满足条件分支" if ok else "否则分支"
            self.logger(f"条件判断：{'满足' if ok else '不满足'}；{desc}；执行{branch_name}")
            self._run_nested_steps(branch, account, pid, branch_name)

        elif action == "set_variable":
            name = self.substitute(step.get("name", ""), account, pid).strip()
            value = self._set_variable(name, step.get("value", ""), account, pid)
            self.runtime_context["last_text"] = str(value)
            self.logger(f"变量更新：{name}={value}")
        elif action == "set_status":
            status = self.substitute(step.get("status", ""), account, pid).strip()
            if not status:
                raise RuntimeError("账号状态不能为空。")
            self.runtime_context["status"] = status
            if callable(self.status_callback):
                self.status_callback(status)
            self.logger(f"账号状态更新：{status}")
        elif action == "log":
            self.logger(self.substitute(step.get("message",""), account, pid))
        elif action == "find_window":
            def finder():
                hs = self.ctrl.find_windows(
                    title=self.substitute(step.get("title"), account, pid) if step.get("title") is not None else None,
                    class_name=step.get("class_name"), pid=pid if step.get("pid_current", True) else None,
                    exact_title=step.get("exact_title", False), occurrence=step.get("occurrence"),
                    visible_only=step.get("visible_only", False), enabled_only=step.get("enabled_only", False))
                if not hs:
                    return None
                pick = max(0, int(step.get("occurrence", 1)) - 1) if step.get("occurrence") is not None else int(step.get("index", 0))
                return hs[pick] if pick < len(hs) else None
            h = self._run_find_with_retry(finder, f"查找窗口“{step.get('title') or step.get('class_name') or '未指定'}”", step)
            if h is None:
                self.runtime_context["last_error"] = f"查找窗口失败：{step.get('title') or step.get('class_name') or '未指定'}"
                self.logger(f'⚠ {self.runtime_context["last_error"]}')
                return
            name = step.get("save_as", "window")
            self.handles[name] = h
            self._remember_handle(name, "window", step)
            try:
                info = self.ctrl.get_text_details(h)
                self.logger(
                    f"定位成功：{name}=HWND={info.get('hwnd')} ClassName={info.get('class_name') or '空'} "
                    f"Parent={info.get('parent') or '空'} PID={info.get('process_id') or '空'}"
                )
            except Exception:
                pass
        elif action == "find_child":
            parent_name = step["parent"]
            parent = self._resolve_handle(parent_name, account, pid)
            def finder():
                return self.ctrl.find_child(parent, title=self.substitute(step.get("title"), account, pid) if step.get("title") is not None else None,
                    class_name=step.get("class_name"), index=step.get("index", 0),
                    exact_title=step.get("exact_title", False), occurrence=step.get("occurrence"),
                    visible_only=step.get("visible_only", False), enabled_only=step.get("enabled_only", False),
                    recursive=step.get("recursive", True))
            h = self._run_find_with_retry(finder, f"查找子控件“{step.get('class_name') or step.get('title') or '未指定'}”", step)
            if h is None:
                self.runtime_context["last_error"] = f"查找子控件失败：{step.get('title') or step.get('class_name') or '未指定'}"
                self.logger(f'⚠ {self.runtime_context["last_error"]}')
                return
            name = step.get("save_as", "control")
            self.handles[name] = h
            self._remember_handle(name, "child", step)
            try:
                info = self.ctrl.get_text_details(h)
                selector = step.get("class_name") or step.get("title") or "未指定"
                occurrence = step.get("occurrence", int(step.get("index", 0)) + 1)
                self.logger(
                    f"定位成功：{name}={selector}[{occurrence}] → HWND={info.get('hwnd')} "
                    f"ClassName={info.get('class_name') or '空'} Parent={info.get('parent') or '空'} "
                    f"PID={info.get('process_id') or '空'} 控件ID={info.get('control_id') or '空'}"
                )
                self.logger(
                    f"初始文本读取：WM_GETTEXTLENGTH={info.get('length', 0)} "
                    f"读取结果长度={len(str(info.get('text') or ''))} "
                    f"方式={info.get('method') or '未读取'}"
                )
            except Exception:
                pass
        elif action == "set_text":
            target_name = str(step.get("target", "")).strip()
            if not target_name:
                raise RuntimeError("输入文字步骤未选择目标句柄，请先使用查找步骤保存 HWND。")
            if target_name not in self.handles:
                raise RuntimeError(f"输入目标句柄不存在：{target_name}。请检查前面的 find 步骤及 save_as。")
            target = self._resolve_handle(target_name, account, pid)
            value = self.substitute(step.get("value", ""), account, pid)
            try:
                self.logger(f"输入文字：目标={target_name} HWND=0x{target:X} ClassName={self.ctrl.get_class_name(target)}")
                self.logger("开始发送 WM_SETTEXT（最多等待 1.8 秒）")
                self.ctrl.set_text(target, value)
                self.logger("WM_SETTEXT 已返回；注意自绘控件可能不支持此消息")
            except Exception as e:
                self.logger(f"输入文字失败：目标={target_name} HWND=0x{target:X}，原因={e}")
                raise
        elif action == "click":
            # 点击步骤只负责点击“查找步骤”保存的句柄。
            # 控件的精确定位统一交给前面的 find_window / find_child。
            target_name = str(step.get("target", "")).strip()
            if not target_name:
                raise RuntimeError("点击步骤未选择目标句柄，请先使用“查找窗口内的控件”保存句柄。")
            if target_name not in self.handles:
                raise RuntimeError(f"点击目标句柄不存在：{target_name}。请确认前面已有 find 步骤保存该句柄。")

            retry_count = self._retry_count(step, default=0)
            retry_interval = self._retry_interval(step, default=0.5)
            attempts = retry_count + 1
            last_error = None
            for attempt in range(1, attempts + 1):
                self.check()
                try:
                    # 每次尝试都重新解析句柄；如果目标程序重建了控件，可恢复到最新 HWND。
                    target = self._resolve_handle(target_name, account, pid, refresh=True)
                    expected_class = str(step.get("class_name", "") or "").strip()
                    if expected_class:
                        actual_class = self.ctrl.get_class_name(target)
                        expected_base, _ = self.ctrl._parse_class_selector(expected_class, 0, None)
                        if expected_base and actual_class != expected_base:
                            raise RuntimeError(f"点击控件 ClassName 不匹配：需要 {expected_base}，实际 {actual_class}")
                    x = step.get("x", "")
                    y = step.get("y", "")
                    if x == "" or y == "" or x is None or y is None:
                        self.logger(f"开始句柄点击：目标={target_name} HWND=0x{int(target):X} ClassName={self.ctrl.get_class_name(target)}" + (f"（第 {attempt} 次尝试）" if attempts > 1 else ""))
                        self.ctrl.click(target)
                    else:
                        self.logger(f"开始句柄坐标点击：目标={target_name} HWND=0x{int(target):X} x={x} y={y}" + (f"（第 {attempt} 次尝试）" if attempts > 1 else ""))
                        self.ctrl.click_at(target, int(x), int(y), step.get("button", "left"))
                    self.logger("点击消息已完成")
                    self.wait(float(step.get("after_wait", 0.25)))
                    if attempt > 1:
                        self.logger(f"点击目标={target_name}：第 {attempt} 次重试成功")
                    last_error = None
                    break
                except (WorkflowExit, InterruptedError):
                    raise
                except Exception as exc:
                    last_error = exc
                    if attempt < attempts:
                        self.logger(f"点击目标={target_name}失败：{exc}；{retry_interval:g} 秒后进行第 {attempt + 1} 次重试（共 {attempts} 次尝试）")
                        self.wait(retry_interval)
                    else:
                        self.logger(f"点击目标={target_name}：达到最大重试次数，仍未成功：{exc}")
            if last_error is not None:
                self._handle_retry_exhausted(step, pid, f"点击目标={target_name}")
        elif action == "send_key":
            keys = {"ENTER":win32con.VK_RETURN,"TAB":win32con.VK_TAB,"ESC":win32con.VK_ESCAPE,
                    "SPACE":win32con.VK_SPACE,"BACKSPACE":win32con.VK_BACK,
                    "UP":win32con.VK_UP,"DOWN":win32con.VK_DOWN,"LEFT":win32con.VK_LEFT,
                    "RIGHT":win32con.VK_RIGHT,
                    "回车":win32con.VK_RETURN,"Tab":win32con.VK_TAB,"Esc":win32con.VK_ESCAPE,
                    "空格":win32con.VK_SPACE,"退格":win32con.VK_BACK,
                    "上方向键":win32con.VK_UP,"下方向键":win32con.VK_DOWN,
                    "左方向键":win32con.VK_LEFT,"右方向键":win32con.VK_RIGHT}
            key = str(step.get("key","ENTER")).upper()
            if key not in keys:
                raise ValueError(f"暂不支持按键：{key}")
            target_name = step.get("target")
            if not target_name:
                raise RuntimeError("发送按键步骤未指定目标句柄。")
            target = self._resolve_handle(target_name, account, pid)
            self.ctrl.send_key(target, keys[key])
        elif action == "close_window":
            self.ctrl.close(self._resolve_handle(step["target"], account, pid))
        elif action == "if_window_exists":
            retry_count = self._detection_retry_count(step)
            retry_interval = self._detection_retry_interval(step)
            attempts = retry_count + 1
            for attempt in range(1, attempts + 1):
                self.check()
                try:
                    hs = self.ctrl.find_windows(
                        title=self.substitute(step.get("title", ""), account, pid),
                        class_name=step.get("class_name"),
                        pid=pid if step.get("pid_current", True) else None,
                        visible_only=step.get("visible_only", False),
                        enabled_only=step.get("enabled_only", False))
                except (WorkflowExit, InterruptedError):
                    raise
                except Exception as exc:
                    if attempt >= attempts:
                        self._handle_retry_exhausted(step, pid, "窗口存在检测")
                        return
                    self.logger(f"窗口存在检测异常：{exc}；{retry_interval:g} 秒后进行第 {attempt + 1} 次失败重试")
                    self.wait(retry_interval)
                    continue
                if hs:
                    if attempt > 1:
                        self.logger(f"窗口存在检测：第 {attempt} 次重试后找到目标窗口")
                    # 分支内部的异常必须按普通工作流错误向上抛出，不能被窗口检测重试吞掉。
                    self._run_nested_steps(step.get("then", []), account, pid, "窗口存在分支")
                    return
                if attempt >= attempts:
                    self._handle_retry_exhausted(step, pid, "窗口存在检测")
                    return
                if attempt < attempts:
                    self.logger(f"窗口存在检测：第 {attempt} 次未找到目标窗口；{retry_interval:g} 秒后进行第 {attempt + 1} 次失败重试")
                    self.wait(retry_interval)
                    continue
                else:
                    self._handle_retry_exhausted(step, pid, "窗口存在检测")
                    return
            return
        else:
            raise ValueError(f"未知操作：{action}")
