import json
import os
from pathlib import Path
from data_paths import data_path
import shutil
import zipfile
import tempfile
import time

class WorkflowStore:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.order_path = data_path("config", "workflow_order.json")
        self.order_path.parent.mkdir(parents=True, exist_ok=True)
        self.recovery_warnings = []

    def _load_order(self):
        if not self.order_path.exists():
            return []
        try:
            with open(self.order_path, "r", encoding="utf-8") as f:
                value = json.load(f)
            return [str(x) for x in value] if isinstance(value, list) else []
        except Exception as exc:
            # 顺序配置损坏时先保留原件，再允许列表按默认顺序恢复。
            backup = None
            try:
                stamp = time.strftime("%Y%m%d-%H%M%S")
                backup = self.order_path.with_name(f"{self.order_path.name}.corrupt-{stamp}.bak")
                suffix = 1
                while backup.exists():
                    backup = self.order_path.with_name(f"{self.order_path.name}.corrupt-{stamp}-{suffix}.bak")
                    suffix += 1
                shutil.copy2(self.order_path, backup)
            except Exception:
                backup = None
            self.recovery_warnings.append(
                f"工作流顺序配置读取失败（{type(exc).__name__}），将按默认顺序恢复；"
                + (f"原文件备份为 {backup.name}。" if backup else "原文件自动备份失败，请手动备份。")
            )
            return []

    @staticmethod
    def _atomic_json_write(path, value):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", newline="", dir=str(path.parent),
                prefix=path.name + ".", suffix=".tmp", delete=False
            ) as f:
                tmp = Path(f.name)
                json.dump(value, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(str(tmp), str(path))
            tmp = None
        finally:
            if tmp is not None:
                try: tmp.unlink(missing_ok=True)
                except OSError: pass

    def _save_order(self, paths):
        names = [Path(p).name for p in paths if Path(p).exists()]
        self._atomic_json_write(self.order_path, names)

    def set_order(self, paths):
        """保存工作流在列表中的显示/运行顺序。"""
        self._save_order(paths)

    @staticmethod
    def safe_name(name):
        safe = "".join(c for c in str(name).strip() if c not in r'\/:*?"<>|')
        return safe or "未命名工作流"

    def list(self):
        files = list(self.folder.glob("*.json"))
        by_name = {p.name: p for p in files}
        order = self._load_order()
        result = [by_name[name] for name in order if name in by_name]
        result.extend(sorted((p for p in files if p.name not in set(order)), key=lambda x: x.name.lower()))
        if [p.name for p in result] != order or len(result) != len(order):
            try:
                self._save_order(result)
            except Exception:
                pass
        return result

    def load(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def backup(self, path):
        path = Path(path)
        if not path.exists():
            return None
        backup_dir = self.folder / ".history" / path.stem
        backup_dir.mkdir(parents=True, exist_ok=True)
        from datetime import datetime
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        dest = backup_dir / f"{stamp}.json"
        shutil.copy2(path, dest)
        # 历史快照只保留最近 100 份，避免长期编辑后压缩包和目录无限增长。
        versions = sorted(backup_dir.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)
        for old_version in versions[100:]:
            try: old_version.unlink()
            except Exception: pass
        return dest

    def list_versions(self, path):
        d = self.folder / ".history" / Path(path).stem
        return sorted(d.glob("*.json"), reverse=True) if d.exists() else []

    def restore_version(self, path, version):
        path, version = Path(path), Path(version)
        self.backup(path)
        tmp = None
        try:
            with tempfile.NamedTemporaryFile(mode="wb", dir=str(path.parent), prefix=path.name + ".", suffix=".tmp", delete=False) as f:
                tmp = Path(f.name)
                with open(version, "rb") as src:
                    shutil.copyfileobj(src, f)
                f.flush()
                os.fsync(f.fileno())
            os.replace(str(tmp), str(path))
            tmp = None
        finally:
            if tmp is not None:
                try: tmp.unlink(missing_ok=True)
                except OSError: pass
        return path

    def save(self, name, data, overwrite=False):
        safe = self.safe_name(name)
        path = self.folder / f"{safe}.json"
        if path.exists() and not overwrite:
            base = safe
            n = 2
            while (self.folder / f"{base} ({n}).json").exists():
                n += 1
            path = self.folder / f"{base} ({n}).json"
            safe = path.stem
        data = json.loads(json.dumps(data, ensure_ascii=False))
        data["name"] = safe
        self._atomic_json_write(path, data)
        order = self._load_order()
        name = path.name
        if name not in order:
            order.append(name)
            self._save_order([self.folder / x for x in order])
        return path

    def copy(self, path, new_name):
        data = self.load(path)
        return self.save(new_name, data, overwrite=False)

    def delete(self, path):
        path = Path(path)
        path.unlink(missing_ok=True)
        order = [x for x in self._load_order() if x != path.name]
        self._save_order([self.folder / x for x in order])

    def export_zip(self, paths, output_path):
        paths = [Path(p) for p in paths]
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in paths:
                if p.exists() and p.suffix.lower() == ".json":
                    zf.write(p, arcname=p.name)
        return Path(output_path)

    def import_zip(self, zip_path):
        imported = []
        with zipfile.ZipFile(zip_path, "r") as zf:
            with tempfile.TemporaryDirectory() as td:
                root = Path(td).resolve()
                for info in zf.infolist():
                    name = Path(info.filename)
                    if name.is_absolute() or ".." in name.parts or name.suffix.lower() != ".json":
                        continue
                    target = (root / name.name).resolve()
                    target.write_bytes(zf.read(info))
                    imported.extend(self.import_files([target]))
        return imported

    def import_files(self, files):
        imported = []
        for src in files:
            src = Path(src)
            if not src.exists() or src.suffix.lower() != ".json":
                continue
            data = self.load(src)
            name = data.get("name") or src.stem
            dest = self.save(name, data, overwrite=False)
            imported.append(dest)
        return imported
