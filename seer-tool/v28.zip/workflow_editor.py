import json
from PySide6.QtCore import Signal, Qt, QTimer
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QListWidget, QListWidgetItem,
    QLineEdit, QComboBox, QSpinBox, QPushButton, QGroupBox, QMessageBox,
    QSplitter, QTextEdit, QCheckBox, QLabel, QInputDialog, QDialog, QMessageBox, QGridLayout, QSizePolicy,
    QStyledItemDelegate, QStyleOptionViewItem, QStyle
)


ACTIONS = [
    ("等待几秒", "wait"),
    ("检测句柄内是否有关键字", "check_keyword"),
    ("等待直到关键字出现", "wait_keyword"),
    ("等待直到条件满足", "wait_condition"),
    ("条件判断 IF / ELSE", "if_condition"),
    ("查找主窗口", "find_window"),
    ("查找窗口内的控件", "find_child"),
    ("输入文字", "set_text"),
    ("点击按钮/控件", "click"),
    ("发送键盘按键", "send_key"),
    ("关闭窗口", "close_window"),
    ("如果窗口存在则执行", "if_window_exists"),
    ("设置工作流变量", "set_variable"),
    ("更新账号状态", "set_status"),
    ("写入运行日志", "log"),
]

# 工作流内部始终使用英文 action key；界面永远使用中文名称。
STEP_ALIASES = {
    "sleep": "wait", "delay": "wait", "wait_seconds": "wait",
    "findwindow": "find_window", "findWindow": "find_window",
    "findchild": "find_child", "findChild": "find_child",
    "settext": "set_text", "setText": "set_text",
    "sendkey": "send_key", "sendKey": "send_key",
    "closewindow": "close_window", "closeWindow": "close_window",
    "checkkeyword": "check_keyword", "checkKeyword": "check_keyword",
    "waitkeyword": "wait_keyword", "waitKeyword": "wait_keyword",
    "waitcondition": "wait_condition", "waitCondition": "wait_condition",
    "ifcondition": "if_condition", "ifCondition": "if_condition",
    "ifwindowexists": "if_window_exists", "ifWindowExists": "if_window_exists",
    "setstatus": "set_status", "setStatus": "set_status",
    "setvariable": "set_variable", "setVariable": "set_variable",
    "write_log": "log", "writeLog": "log",
}
STEP_LABELS = {value: text for text, value in ACTIONS}

# 中文名称 -> 内部 action key 的兼容映射
for _label, _value in ACTIONS:
    STEP_ALIASES.setdefault(_label, _value)

def normalize_action(action):
    raw = str(action or "").strip()
    if raw in STEP_LABELS:
        return raw
    return STEP_ALIASES.get(raw, STEP_ALIASES.get(raw.lower(), raw))

def action_label(action):
    """把任何兼容的内部 action/旧别名统一转换成中文显示名。"""
    original = str(action or "").strip()
    key = normalize_action(original)
    return STEP_LABELS.get(key, original or "未知操作")

KEYS = ["回车", "Tab", "Esc", "空格", "退格", "上方向键", "下方向键", "左方向键", "右方向键"]
KEY_MAP = {
    "回车": "ENTER", "Tab": "TAB", "Esc": "ESC", "空格": "SPACE",
    "退格": "BACKSPACE", "上方向键": "UP", "下方向键": "DOWN",
    "左方向键": "LEFT", "右方向键": "RIGHT"
}

class GroupedStepDelegate(QStyledItemDelegate):
    """只把分组子步骤的内容区域（包括复选框）整体向右缩进，不改变 QListWidgetItem 的几何尺寸。

    通过同时调整 paint/editorEvent 的 option.rect，复选框点击区域和绘制区域保持一致，
    避免点击复选框后出现视觉位移。
    """
    INDENT = 18

    def _adjusted_option(self, option, index):
        opt = QStyleOptionViewItem(option)
        value = index.data(Qt.ItemDataRole.UserRole + 1)
        is_step = False
        try:
            is_step = int(index.data(Qt.ItemDataRole.UserRole)) >= 0
        except (TypeError, ValueError):
            is_step = False
        if is_step and str(value or "").strip():
            opt.rect = opt.rect.adjusted(self.INDENT, 0, 0, 0)
        return opt

    def paint(self, painter, option, index):
        super().paint(painter, self._adjusted_option(option, index), index)

    def editorEvent(self, event, model, option, index):
        return super().editorEvent(event, model, self._adjusted_option(option, index), index)



class GroupedStepList(QListWidget):
    """工作流步骤列表。

    分组只允许通过分组标题双击进行折叠/展开；右键在列表区域不执行任何分组操作，
    也不再弹出步骤右键菜单，避免鼠标组合操作影响折叠状态。
    """
    groupDoubleClicked = Signal(str)
    deletePressed = Signal()
    toggleEnabledPressed = Signal()
    duplicatePressed = Signal()
    movePressed = Signal(int)

    _GROUP_ROLE = Qt.ItemDataRole.UserRole + 1
    _ROW_ROLE = Qt.ItemDataRole.UserRole

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)

    def _group_at(self, pos):
        item = self.itemAt(pos)
        if item is None:
            return ""
        try:
            row = int(item.data(self._ROW_ROLE))
        except (TypeError, ValueError):
            row = -1
        # 真正的分组标题只有 row == -1 且存在 group 值。
        if row >= 0:
            return ""
        return str(item.data(self._GROUP_ROLE) or "").strip()

    def mousePressEvent(self, event):
        # 列表区域彻底取消右键交互：不选中、不菜单、不改变分组状态。
        if event.button() == Qt.MouseButton.RightButton:
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        # 只有左键双击真正的分组标题才执行折叠/展开。
        if event.button() == Qt.MouseButton.LeftButton:
            group = self._group_at(event.position().toPoint())
            if group:
                self.groupDoubleClicked.emit(group)
                event.accept()
                return
        super().mouseDoubleClickEvent(event)

    def keyPressEvent(self, event):
        key = event.key()
        mods = event.modifiers()
        if key == Qt.Key.Key_Delete:
            self.deletePressed.emit()
            event.accept()
            return
        if key == Qt.Key.Key_Space:
            self.toggleEnabledPressed.emit()
            event.accept()
            return
        if mods & Qt.KeyboardModifier.ControlModifier:
            if key == Qt.Key.Key_D:
                self.duplicatePressed.emit()
                event.accept()
                return
            if key == Qt.Key.Key_Up:
                self.movePressed.emit(-1)
                event.accept()
                return
            if key == Qt.Key.Key_Down:
                self.movePressed.emit(1)
                event.accept()
                return
        super().keyPressEvent(event)

class WorkflowEditor(QWidget):
    workflowChanged = Signal()

    def __init__(self, workflow=None):
        super().__init__()
        self.data = workflow or {"name":"新工作流","steps":[]}
        self._ui_refreshing = False
        self._last_current_row = -1
        self._collapsed_groups = {}
        self.build()
        self.refresh()

    def build(self):
        # 编辑器内部变更信号也做轻量防抖，避免连续输入时反复刷新上层和磁盘草稿。
        self._change_timer = QTimer(self)
        self._change_timer.setSingleShot(True)
        self._change_timer.setInterval(250)
        self._change_timer.timeout.connect(self._emit_workflow_changed)
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("例如：软件A登录流程")
        self.name_edit.textChanged.connect(self.on_name)
        top.addWidget(QLabel("工作流名称："))
        top.addWidget(self.name_edit)
        root.addLayout(top)

        split = QSplitter()
        search_row = QHBoxLayout()
        search_row.addWidget(QLabel("步骤搜索："))
        self.step_search = QLineEdit(); self.step_search.setPlaceholderText("搜索步骤名称、ClassName、Selector、关键字…"); self.step_search.textChanged.connect(self.filter_steps)
        search_row.addWidget(self.step_search, 1); rv_dummy = search_row
        root.addLayout(search_row)
        self.list = GroupedStepList()
        self.list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self.list.groupDoubleClicked.connect(self._toggle_group)
        self.list.deletePressed.connect(self.delete)
        self.list.toggleEnabledPressed.connect(self.toggle_enabled)
        self.list.duplicatePressed.connect(self.duplicate)
        self.list.movePressed.connect(self.move)
        self.list.setUniformItemSizes(True)
        self.list.setItemDelegate(GroupedStepDelegate(self.list))
        self.list.currentRowChanged.connect(self.load_selected)
        self.list.itemChanged.connect(self._on_item_check_changed)
        split.addWidget(self.list)

        right = QWidget()
        rv = QVBoxLayout(right)
        self.form_box = QGroupBox("当前步骤设置")
        self.form = QFormLayout(self.form_box)
        rv.addWidget(self.form_box)

        self.help_label = QLabel()
        self.help_label.setWordWrap(True)
        rv.addWidget(self.help_label)

        self.preview = QTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setPlaceholderText("这里显示当前步骤对应的配置")
        rv.addWidget(self.preview)
        split.addWidget(right)
        split.setSizes([330, 650])
        root.addWidget(split)

        # 步骤操作区：统一高度、两列布局；启用/禁用直接使用左侧复选框。
        action_box = QGroupBox("步骤操作")
        action_layout = QGridLayout(action_box)
        action_layout.setHorizontalSpacing(8)
        action_layout.setVerticalSpacing(8)
        action_layout.setContentsMargins(10, 8, 10, 8)
        action_box.setFixedHeight(104)

        self.action_combo = QComboBox()
        for text, value in ACTIONS:
            self.action_combo.addItem(text, value)
        add = QPushButton("＋ 添加步骤")
        up = QPushButton("↑ 上移")
        down = QPushButton("↓ 下移")
        duplicate = QPushButton("复制步骤")
        group = QPushButton("设置分组")
        toggle_all_groups = QPushButton("展开/折叠全部分组")
        rename_group = QPushButton("重命名分组")
        ungroup = QPushButton("取消分组")
        cond = QPushButton("可视化条件")
        delete = QPushButton("删除步骤")

        add.setToolTip("在当前步骤后添加；没有选中步骤时添加到末尾")
        group.setToolTip("将当前选中步骤加入指定分组")
        toggle_all_groups.setToolTip("所有分组在展开与折叠之间切换")
        rename_group.setToolTip("重命名当前步骤所属分组，组内步骤会一起更新")
        ungroup.setToolTip("取消当前步骤所属的整个分组，无需选中组内全部步骤")
        cond.setToolTip("编辑当前‘条件判断 IF / ELSE’步骤的 AND / OR / NOT 条件")
        delete.setToolTip("删除当前选中步骤")

        add.clicked.connect(self.add_step)
        up.clicked.connect(lambda: self.move(-1))
        down.clicked.connect(lambda: self.move(1))
        duplicate.clicked.connect(self.duplicate)
        group.clicked.connect(self.set_group)
        toggle_all_groups.clicked.connect(self.toggle_all_groups)
        rename_group.clicked.connect(self.rename_group)
        ungroup.clicked.connect(self.clear_group)
        cond.clicked.connect(self.visual_condition)
        delete.clicked.connect(self.delete)

        # 两行横向排列：恢复之前紧凑的工具栏风格，避免“两列五行”造成步骤操作区过高。
        # 第一行：动作/添加/移动/复制；第二行：分组/条件/删除。
        controls = [self.action_combo, add, up, down, duplicate, group, toggle_all_groups, rename_group, ungroup, cond, delete]
        for w in controls:
            w.setMinimumHeight(30)
            w.setFixedHeight(30)

        self.action_combo.setMinimumWidth(300)
        self.action_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        action_layout.addWidget(self.action_combo, 0, 0)
        action_layout.addWidget(add, 0, 1)
        action_layout.addWidget(up, 0, 2)
        action_layout.addWidget(down, 0, 3)
        action_layout.addWidget(duplicate, 0, 4)

        # “设置分组”原来的整格拆成左右两半，新按钮与其并排。
        group_tools = QWidget()
        group_tools_layout = QHBoxLayout(group_tools)
        group_tools_layout.setContentsMargins(0, 0, 0, 0)
        group_tools_layout.setSpacing(6)
        group_tools_layout.addWidget(group)
        group_tools_layout.addWidget(toggle_all_groups)
        group_tools_layout.setStretch(0, 1)
        group_tools_layout.setStretch(1, 1)
        action_layout.addWidget(group_tools, 1, 0)
        action_layout.addWidget(rename_group, 1, 1)
        action_layout.addWidget(ungroup, 1, 2)
        action_layout.addWidget(cond, 1, 3)
        action_layout.addWidget(delete, 1, 4)
        for col in range(5):
            action_layout.setColumnStretch(col, 1)
        root.addWidget(action_box)


    def _emit_workflow_changed(self):
        if not self._ui_refreshing:
            self.workflowChanged.emit()

    def _schedule_workflow_changed(self):
        if not self._ui_refreshing:
            self._change_timer.start()

    def on_name(self, text):
        if self._ui_refreshing:
            return
        self.data["name"] = text
        self._schedule_workflow_changed()

    def clear_form(self):
        while self.form.rowCount():
            self.form.removeRow(0)

    def save_form(self):
        if self._ui_refreshing:
            return
        row = self.current_data_row()
        if row < 0 or row >= len(self.data["steps"]):
            return
        s = self.data["steps"][row]
        for _, widget in getattr(self, "widgets", []):
            key = widget.property("wf_key")
            if key is None:
                continue
            if isinstance(widget, QSpinBox):
                s[key] = widget.value()
                if key == "occurrence":
                    s["index"] = max(0, widget.value() - 1)
            elif isinstance(widget, QCheckBox):
                s[key] = widget.isChecked()
            elif isinstance(widget, QComboBox):
                if widget.property("wf_use_data"):
                    s[key] = widget.currentData()
                else:
                    s[key] = KEY_MAP.get(widget.currentText(), widget.currentText())
            elif isinstance(widget, QTextEdit):
                raw = widget.toPlainText().strip()
                if widget.property("wf_json"):
                    try:
                        s[key] = json.loads(raw or "[]")
                        widget.setStyleSheet("")
                    except Exception:
                        # 保留原值，红框提示；避免用户输入一半 JSON 时破坏工作流数据。
                        widget.setStyleSheet("QTextEdit { border: 1px solid #d9534f; }")
                else:
                    s[key] = raw
            else:
                s[key] = widget.text()
        # 不在每个字符输入时重绘右侧 JSON 预览；数据已即时写入内存，
        # 工作流变更信号通过 250ms 防抖后再通知上层。
        self._schedule_workflow_changed()

    def add_form_field(self, label, key, value="", spin=False, check=False, choices=None, occurrence=False, json_field=False):
        if json_field:
            w = QTextEdit()
            if isinstance(value, (list, dict)):
                w.setPlainText(json.dumps(value, ensure_ascii=False, indent=2))
            else:
                w.setPlainText(str(value or ""))
            w.setMaximumHeight(130)
            w.setProperty("wf_json", True)
            w.textChanged.connect(self.save_form)
        elif choices:
            w = QComboBox()
            use_data = any(isinstance(c, (tuple, list)) and len(c) >= 2 for c in choices)
            for c in choices:
                if isinstance(c, (tuple, list)) and len(c) >= 2:
                    w.addItem(str(c[0]), c[1])
                else:
                    w.addItem(str(c), c)
            w.setProperty("wf_use_data", use_data)
            reverse = {v:k for k,v in KEY_MAP.items()}
            target = reverse.get(str(value), str(value))
            if use_data:
                for i in range(w.count()):
                    if str(w.itemData(i)) == str(value):
                        w.setCurrentIndex(i)
                        break
            else:
                w.setCurrentText(target)
            w.currentTextChanged.connect(self.save_form)
        elif spin:
            w = QSpinBox()
            w.setRange(0 if not occurrence else 1, 999999)
            w.setValue(int(value or (1 if occurrence else 0)))
            w.valueChanged.connect(self.save_form)
        elif check:
            w = QCheckBox()
            w.setChecked(bool(value))
            w.stateChanged.connect(self.save_form)
        else:
            w = QLineEdit(str(value))
            w.textChanged.connect(self.save_form)
        w.setProperty("wf_key", key)
        self.form.addRow(label, w)
        self.widgets.append((label, w))
        return w

    def load_selected(self, row):
        item = self.list.item(row) if row >= 0 else None
        data_row = self._item_data_row(item)
        self._last_current_row = data_row
        self.clear_form()
        row = data_row
        self.widgets = []
        if row < 0 or row >= len(self.data["steps"]):
            self.preview.clear()
            self.help_label.clear()
            return

        s = self.data["steps"][row]
        # 迁移旧版本的失败处理名称，避免老工作流在升级后显示为空或保存回旧值。
        legacy_retry_action = str(s.get("retry_fail_action", "") or "").strip()
        if legacy_retry_action in ("流程失败", "continue", "continue_next", "进入下一步"):
            s["retry_fail_action"] = "进入下一步"
        elif legacy_retry_action in ("结束该进程", "terminate_process", "kill_process", "结束该次循环"):
            s["retry_fail_action"] = "结束该次循环"
        action = normalize_action(s.get("action", ""))
        if action != s.get("action"):
            s["action"] = action
        # 每个步骤都允许填写备注；备注只用于编辑器展示，不参与执行。
        self.add_form_field("步骤备注：", "remark", s.get("remark", ""))
        descriptions = {
            "wait": "让程序暂停指定秒数。适合等待目标软件加载完成、页面出现等情况。",
            "check_keyword": "读取已保存句柄的文字内容，检查是否包含关键字。未找到时自动重试；重试失败后可进入下一步或结束本次循环。",
            "wait_keyword": "持续检测句柄文字，直到出现指定关键字。支持最长等待时间、检测间隔，以及失败后的自动重试。",
            "wait_condition": "持续检测窗口、句柄或文字条件，直到条件满足。超时可选择失败、继续或退出当前账号流程；失败时可重新开启完整检测周期。",
            "if_condition": "通用 IF / ELSE 条件判断。检测不满足时可自动重试；最终仍不满足才执行 else 分支。",
            "find_window": "按照窗口标题、ClassName、出现序号和可见/启用状态查找主窗口。ClassName 支持 Edit[5]。",
            "find_child": "在父窗口中查找控件。相同 ClassName 可以用‘匹配第几个（从1开始）’或 Edit[5] 区分，并可限制仅可见、仅启用。",
            "set_text": "向已经找到的控件输入文字。可以使用 {account}、{password} 等账号变量。",
            "click": "点击按钮/控件。只选择前面查找步骤保存的句柄；控件的标题、ClassName 和第几个由前面的查找步骤负责。",
            "send_key": "向指定控件发送键盘按键，例如回车、Tab、Esc。",
            "close_window": "关闭已经找到的窗口。",
            "if_window_exists": "检查指定窗口是否存在；未找到时可自动重试，最终找到后才执行后续操作。",
            "set_variable": "创建/修改工作流运行时变量，后续步骤可以使用 {变量名}。变量只在当前账号本次运行中有效。",
            "set_status": "修改运行中心当前账号的状态。可用于在关键字判断成功后写入“登录成功”“密码错误”“封禁”等自定义状态。",
            "log": "把文字写入运行日志，方便查看流程运行到了哪一步。"
        }
        self.help_label.setText(descriptions.get(action, ""))

        if action == "wait":
            self.add_form_field("等待秒数：", "seconds", s.get("seconds",1), spin=True)

        elif action == "check_keyword":
            self.add_form_field("检测目标句柄：", "target", s.get("target", "控件"))
            self.add_form_field("关键字：", "keyword", s.get("keyword", ""))
            self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 2), spin=True)
            self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
            self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "进入下一步"), choices=["进入下一步", "结束该次循环"])
            self.help_label.setText(self.help_label.text() + "\n\n未找到关键字时按设置自动重试；达到最大重试次数后，可选择结束当前账号本次循环。")

        elif action == "wait_keyword":
            self.add_form_field("检测目标句柄：", "target", s.get("target", "控件"))
            self.add_form_field("等待关键字：", "keyword", s.get("keyword", ""))
            self.add_form_field("最长等待秒数：", "timeout_seconds", s.get("timeout_seconds", 30), spin=True)
            self.add_form_field("检测间隔秒数：", "delay_seconds", s.get("delay_seconds", 1), spin=True)
            self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 2), spin=True)
            self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
            self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "进入下一步"), choices=["进入下一步", "结束该次循环"])

        elif action in ("wait_condition", "if_condition"):
            condition_choices = [
                ("文字包含关键字", "keyword_contains"),
                ("文字不包含关键字", "keyword_not_contains"),
                ("文字完全等于", "text_equals"),
                ("文字不等于", "text_not_equals"),
                ("文字非空", "text_not_empty"),
                ("已保存句柄存在", "handle_exists"),
                ("已保存句柄可见", "handle_visible"),
                ("已保存句柄已启用", "handle_enabled"),
                ("窗口存在", "window_exists"),
                ("窗口不存在", "window_not_exists"),
            ]
            self.add_form_field("条件类型：", "condition", s.get("condition", "keyword_contains"), choices=condition_choices)
            self.add_form_field("目标句柄名称：", "target", s.get("target", "控件"))
            self.add_form_field("关键字/期望文字：", "keyword", s.get("keyword", s.get("expected", "")))
            self.add_form_field("窗口标题包含：", "title", s.get("title", ""))
            self.add_form_field("窗口 ClassName：", "class_name", s.get("class_name", ""))
            self.add_form_field("只查找本次启动的软件：", "pid_current", s.get("pid_current", True), check=True)
            if action == "wait_condition":
                self.add_form_field("最长等待秒数：", "timeout_seconds", s.get("timeout_seconds", 30), spin=True)
                self.add_form_field("检测间隔秒数：", "delay_seconds", s.get("delay_seconds", 1), spin=True)
                self.add_form_field("超时后的处理：", "timeout_action", s.get("timeout_action", "流程失败"), choices=["流程失败", "继续下一步", "退出当前账号流程"])
                self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 2), spin=True)
                self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
                self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "进入下一步"), choices=["进入下一步", "结束该次循环"])
            else:
                self.add_form_field("复合条件 JSON（可选）：", "logic", s.get("logic", ""), json_field=True)
                self.add_form_field("满足条件时执行 then：", "then", s.get("then", []), json_field=True)
                self.add_form_field("否则执行 else：", "else", s.get("else", []), json_field=True)
                self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 2), spin=True)
                self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
                self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "进入下一步"), choices=["进入下一步", "结束该次循环"])
                self.help_label.setText(self.help_label.text() + "\n\n高级条件示例：{\"op\":\"and\",\"items\":[{\"condition\":\"keyword_contains\",\"target\":\"控件\",\"keyword\":\"成功\"},{\"condition\":\"handle_exists\",\"target\":\"登录按钮\"}]}\n支持 AND / OR / NOT，可与原有单条件兼容。")
                self.help_label.setText(self.help_label.text() + "\n\nthen / else 都是步骤 JSON 数组，例如 [{\"action\":\"log\",\"message\":\"登录成功\"}]。")
                self.help_label.setText(self.help_label.text() + "\n失败重试只针对条件检测本身；最终不满足条件时，才进入 else 分支。")

        elif action == "find_window":
            self.add_form_field("窗口标题包含：", "title", s.get("title",""))
            self.add_form_field("窗口 ClassName：", "class_name", s.get("class_name",""))
            self.add_form_field("保存句柄名称：", "save_as", s.get("save_as","主窗口"))
            self.add_form_field("匹配第几个（从1开始）：", "occurrence", s.get("occurrence", int(s.get("index",0))+1), spin=True, occurrence=True)
            self.add_form_field("必须完全相同标题：", "exact_title", s.get("exact_title",False), check=True)
            self.add_form_field("仅查找可见窗口：", "visible_only", s.get("visible_only",False), check=True)
            self.add_form_field("仅查找启用窗口：", "enabled_only", s.get("enabled_only",False), check=True)
            self.add_form_field("只查找本次启动的软件：", "pid_current", s.get("pid_current",True), check=True)
            self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 0), spin=True)
            self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
            self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "进入下一步"), choices=["进入下一步", "结束该次循环"])

        elif action == "find_child":
            self.add_form_field("父窗口句柄名称：", "parent", s.get("parent","主窗口"))
            self.add_form_field("控件标题包含：", "title", s.get("title",""))
            self.add_form_field("控件 ClassName：", "class_name", s.get("class_name","Button"))
            self.add_form_field("匹配第几个（从1开始）：", "occurrence", s.get("occurrence", int(s.get("index",0))+1), spin=True, occurrence=True)
            self.add_form_field("保存句柄名称：", "save_as", s.get("save_as","控件"))
            self.add_form_field("必须完全相同标题：", "exact_title", s.get("exact_title",False), check=True)
            self.add_form_field("仅查找可见控件：", "visible_only", s.get("visible_only",False), check=True)
            self.add_form_field("仅查找启用控件：", "enabled_only", s.get("enabled_only",False), check=True)
            self.add_form_field("递归查找所有后代控件：", "recursive", s.get("recursive", True), check=True)
            self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 0), spin=True)
            self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
            self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "进入下一步"), choices=["进入下一步", "结束该次循环"])

        elif action == "set_text":
            self.add_form_field("目标控件句柄名称：", "target", s.get("target",""))
            self.add_form_field("输入内容：", "value", s.get("value","{account}"))

        elif action == "click":
            # 点击只选择前面 find 步骤保存的句柄；精确定位统一在 find 步骤完成。
            names = []
            for prev in self.data.get("steps", []):
                saved = str(prev.get("save_as", "")).strip()
                if saved and saved not in names:
                    names.append(saved)
            current = str(s.get("target", "")).strip()
            if current and current not in names:
                names.insert(0, current)
            if not names:
                names = ["主窗口"]
            self.add_form_field("选择要点击的句柄：", "target", current or names[0], choices=names)
            self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 0), spin=True)
            self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
            self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "进入下一步"), choices=["进入下一步", "结束该次循环"])
            self.help_label.setText(self.help_label.text() + "\n\n点击失败时自动重试；句柄失效时会重新按前面的查找规则定位目标控件。")
            self.help_label.setText(
                self.help_label.text()
                + "\n\n点击步骤现在只负责点击已保存句柄。"
                  "请先用“查找窗口内的控件”精确找到控件，再在这里选择它。"
            )

        elif action == "send_key":
            self.add_form_field("目标控件句柄名称：", "target", s.get("target",""))
            self.add_form_field("要发送的按键：", "key", s.get("key","ENTER"), choices=KEYS)

        elif action == "close_window":
            self.add_form_field("目标窗口句柄名称：", "target", s.get("target","主窗口"))

        elif action == "set_variable":
            self.add_form_field("变量名称：", "name", s.get("name", "login_result"))
            self.add_form_field("变量值：", "value", s.get("value", "成功"))
            self.help_label.setText(self.help_label.text() + "\n\n后续步骤可以使用 {变量名称}。")

        elif action == "set_status":
            self.add_form_field("账号状态：", "status", s.get("status", "登录成功"))
            self.help_label.setText(self.help_label.text() + "\n\n建议在登录成功、密码错误、封禁、超时等分支中使用。")

        elif action == "log":
            self.add_form_field("日志内容：", "message", s.get("message","当前账号：{account}"))

        elif action == "if_window_exists":
            self.add_form_field("窗口标题包含：", "title", s.get("title",""))
            self.add_form_field("ClassName：", "class_name", s.get("class_name",""))
            self.add_form_field("只查找本次启动的软件：", "pid_current", s.get("pid_current",True), check=True)
            self.add_form_field("失败重试次数：", "retry_count", s.get("retry_count", 2), spin=True)
            self.add_form_field("重试间隔秒数：", "retry_interval", s.get("retry_interval", 0.5))
            self.add_form_field("重试失败后：", "retry_fail_action", s.get("retry_fail_action", "结束该次循环"), choices=["进入下一步", "结束该次循环"])
            self.add_form_field("满足条件后执行的步骤(JSON)：", "then", s.get("then", []), json_field=True)

        self.update_preview()

    def update_preview(self):
        row = self.current_data_row()
        if row >= 0:
            self.preview.setPlainText(json.dumps(self.data["steps"][row], ensure_ascii=False, indent=2))

    def _item_data_row(self, item):
        if item is None:
            return -1
        value = item.data(Qt.ItemDataRole.UserRole)
        try:
            value = int(value)
        except (TypeError, ValueError):
            return -1
        return value if value >= 0 else -1

    def current_data_row(self):
        row = self._item_data_row(self.list.currentItem())
        if row >= 0:
            return row
        return self._last_current_row if 0 <= self._last_current_row < len(self.data.get("steps", [])) else -1

    def set_current_data_row(self, data_row, select=True):
        if data_row is None or data_row < 0:
            return
        for i in range(self.list.count()):
            item = self.list.item(i)
            if self._item_data_row(item) == data_row:
                self.list.setCurrentRow(i)
                if select:
                    item.setSelected(True)
                return

    def select_data_rows(self, rows):
        self.list.clearSelection()
        wanted = set(rows)
        first_item = None
        for i in range(self.list.count()):
            item = self.list.item(i)
            data_row = self._item_data_row(item)
            if data_row in wanted:
                item.setSelected(True)
                if first_item is None:
                    first_item = item
        if first_item is not None:
            self.list.setCurrentItem(first_item)

    def _group_from_item(self, item):
        if item is None:
            return ""
        group = item.data(Qt.ItemDataRole.UserRole + 1)
        return str(group or "").strip()

    def _update_group_header_texts(self):
        for i in range(self.list.count()):
            item = self.list.item(i)
            if self._item_data_row(item) >= 0:
                continue
            group = self._group_from_item(item)
            if not group:
                continue
            collapsed = bool(self._collapsed_groups.get(group, True))
            item.setText(("▸" if collapsed else "▾") + f"  分组：{group}")

    def _toggle_group(self, group):
        group = str(group or "").strip()
        if not group:
            return
        self._collapsed_groups[group] = not self._collapsed_groups.get(group, True)
        self._update_group_header_texts()
        self._apply_group_visibility()

    def _set_all_groups_collapsed(self, collapsed):
        groups = {
            str(step.get("group", "") or "").strip()
            for step in self.data.get("steps", [])
            if str(step.get("group", "") or "").strip()
        }
        for group in groups:
            self._collapsed_groups[group] = bool(collapsed)
        self._update_group_header_texts()
        self._apply_group_visibility()

    def toggle_all_groups(self):
        """所有分组在“全部展开”和“全部折叠”两种状态之间切换。"""
        groups = {
            str(step.get("group", "") or "").strip()
            for step in self.data.get("steps", [])
            if str(step.get("group", "") or "").strip()
        }
        if not groups:
            return
        # 只要还有任何一个分组处于折叠状态，本次就全部展开；
        # 当所有分组都展开时，再点击则全部折叠。
        should_expand = any(bool(self._collapsed_groups.get(group, True)) for group in groups)
        self._set_all_groups_collapsed(not should_expand)

    def _apply_group_visibility(self):
        query = self.step_search.text().strip().casefold() if hasattr(self, "step_search") else ""
        group_items = {}
        group_headers = {}

        for i in range(self.list.count()):
            item = self.list.item(i)
            data_row = self._item_data_row(item)
            group = self._group_from_item(item)
            if data_row < 0:
                if group:
                    group_headers[group] = item
                    group_items.setdefault(group, [])
                item.setHidden(False)
            elif group:
                group_items.setdefault(group, []).append(item)

        if query:
            # 搜索时自动展开有命中的分组，并隐藏无命中的组。
            for i in range(self.list.count()):
                item = self.list.item(i)
                data_row = self._item_data_row(item)
                if data_row < 0:
                    continue
                step = self.data.get("steps", [])[data_row] if 0 <= data_row < len(self.data.get("steps", [])) else {}
                hay = (item.text() + " " + json.dumps(step, ensure_ascii=False)).casefold()
                item.setHidden(query not in hay)

            for group, items in group_items.items():
                visible = any(not item.isHidden() for item in items)
                if visible:
                    self._collapsed_groups[group] = False
                header = group_headers.get(group)
                if header is not None:
                    header.setHidden(not visible)
                if visible:
                    for item in items:
                        # 搜索结果必须可见，即使该组原本处于折叠状态。
                        pass
        else:
            # 无搜索时严格遵守分组折叠状态；同时恢复所有普通步骤可见。
            for i in range(self.list.count()):
                item = self.list.item(i)
                data_row = self._item_data_row(item)
                if data_row < 0:
                    item.setHidden(False)
                    continue
                group = self._group_from_item(item)
                if group:
                    item.setHidden(bool(self._collapsed_groups.get(group, True)))
                else:
                    item.setHidden(False)

        self._update_group_header_texts()

    def refresh(self):
        # 纯 UI 重绘，不触发 workflowChanged；避免每次刷新都写磁盘导致编辑卡顿。
        target_row = self.current_data_row()
        selected_rows = self.selected_rows() if hasattr(self, "list") and self.list.count() else []
        self._ui_refreshing = True
        try:
            self.name_edit.blockSignals(True)
            self.list.blockSignals(True)
            self.name_edit.setText(self.data.get("name", "新工作流"))
            self.list.clear()
            seen_groups = set()
            for i, s in enumerate(self.data.get("steps", []), 1):
                action = normalize_action(s.get("action", ""))
                if action != s.get("action"):
                    s["action"] = action
                group = str(s.get("group", "") or "").strip()
                if group and group not in seen_groups:
                    seen_groups.add(group)
                    # 首次看到一个分组时默认折叠；用户手动展开后，refresh 不会重置状态。
                    if group not in self._collapsed_groups:
                        self._collapsed_groups[group] = True
                    collapsed = self._collapsed_groups.get(group, True)
                    header = QListWidgetItem(("▸" if collapsed else "▾") + f"  分组：{group}")
                    header.setData(Qt.ItemDataRole.UserRole, -1)
                    header.setData(Qt.ItemDataRole.UserRole + 1, group)
                    header.setFlags(Qt.ItemFlag.ItemIsEnabled)
                    header.setToolTip(f"分组：{group}\n双击此分组标题折叠/展开")
                    f = header.font(); f.setBold(True); header.setFont(f)
                    self.list.addItem(header)
                label = action_label(action)
                remark = str(s.get("remark", "") or "").strip()
                suffix = f"  ｜备注：{remark}" if remark else ""
                # 分组子步骤不再添加字符箭头；实际缩进由 GroupedStepDelegate 统一作用到复选框和文字。
                item = QListWidgetItem(f"第 {i} 步：{label}{suffix}")
                item.setData(Qt.ItemDataRole.UserRole, i - 1)
                item.setData(Qt.ItemDataRole.UserRole + 1, group)
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled)
                item.setCheckState(Qt.CheckState.Checked if s.get("enabled", True) is not False else Qt.CheckState.Unchecked)
                item.setToolTip(("已启用" if s.get("enabled", True) is not False else "已禁用") + (f"\n备注：{remark}" if remark else ""))
                self.list.addItem(item)
            self._apply_group_visibility()
            self.set_current_data_row(target_row if target_row >= 0 else (0 if self.data.get("steps") else -1), select=False)
            if selected_rows:
                self.select_data_rows([r for r in selected_rows if 0 <= r < len(self.data.get("steps", []))])
        finally:
            self.list.blockSignals(False)
            self.name_edit.blockSignals(False)
            self._ui_refreshing = False

    def _on_item_check_changed(self, item):
        row = self._item_data_row(item)
        if row < 0 or row >= len(self.data.get("steps", [])):
            return
        step = self.data["steps"][row]
        step["enabled"] = item.checkState() == Qt.CheckState.Checked
        label = action_label(step.get("action"))
        item.setToolTip("此步骤已启用" if step["enabled"] else "此步骤已禁用，运行时会直接跳过")
        self.workflowChanged.emit()
        self.update_preview()

    def add_step(self):
        action = normalize_action(self.action_combo.currentData())
        defaults = {
            "wait":{"action":"wait","seconds":1},
            "check_keyword":{"action":"check_keyword","target":"控件","keyword":"","retry_count":2,"retry_interval":0.5,"retry_fail_action":"结束该次循环"},
            "wait_keyword":{"action":"wait_keyword","target":"控件","keyword":"","timeout_seconds":30,"delay_seconds":1,"retry_count":2,"retry_interval":0.5,"retry_fail_action":"结束该次循环"},
            "wait_condition":{"action":"wait_condition","condition":"keyword_contains","target":"控件","keyword":"","title":"","class_name":"","pid_current":True,"timeout_seconds":30,"delay_seconds":1,"timeout_action":"流程失败","retry_count":2,"retry_interval":0.5,"retry_fail_action":"结束该次循环"},
            "if_condition":{"action":"if_condition","condition":"keyword_contains","target":"控件","keyword":"","title":"","class_name":"","pid_current":True,"then":[],"else":[],"retry_count":2,"retry_interval":0.5,"retry_fail_action":"结束该次循环"},
            "find_window":{"action":"find_window","title":"","class_name":"","save_as":"主窗口","index":0,"occurrence":1,"exact_title":False,"visible_only":False,"enabled_only":False,"pid_current":True,"retry_count":0,"retry_interval":0.5,"retry_fail_action":"结束该次循环"},
            "find_child":{"action":"find_child","parent":"主窗口","title":"","class_name":"Edit","index":0,"occurrence":1,"save_as":"控件","exact_title":False,"visible_only":False,"enabled_only":False,"recursive":True,"retry_count":0,"retry_interval":0.5,"retry_fail_action":"结束该次循环"},
            "set_text":{"action":"set_text","target":"","value":"{account}"},
            "click":{"action":"click","target":"","after_wait":0.25},
            "send_key":{"action":"send_key","target":"","key":"ENTER"},
            "close_window":{"action":"close_window","target":"主窗口"},
            "if_window_exists":{"action":"if_window_exists","title":"","class_name":"","pid_current":True,"retry_count":2,"retry_interval":0.5,"retry_fail_action":"结束该次循环","then":[]},
            "set_variable":{"action":"set_variable","name":"login_result","value":"成功"},
            "set_status":{"action":"set_status","status":"登录成功"},
            "log":{"action":"log","message":"当前账号：{account}"},
        }
        default_step = defaults.get(action)
        if default_step is None:
            QMessageBox.warning(self, "添加步骤失败", f"当前操作没有默认配置：{action}")
            return
        self.data["steps"].append(json.loads(json.dumps(default_step, ensure_ascii=False)))
        self.refresh()
        self.set_current_data_row(len(self.data["steps"])-1)

    def toggle_enabled(self):
        rows = self.selected_rows()
        if not rows:
            return
        all_enabled = all(bool(self.data["steps"][r].get("enabled", True)) for r in rows)
        for r in rows:
            self.data["steps"][r]["enabled"] = not all_enabled
        self.refresh()
        self.select_data_rows(rows)
        self.workflowChanged.emit()

    def validate_current_workflow(self):
        errors = []
        warnings = []
        steps = self.data.get("steps", [])
        if not steps:
            errors.append("工作流没有步骤")
        known = {value for _, value in ACTIONS}
        saved = set()
        for i, step in enumerate(steps, 1):
            if not isinstance(step, dict):
                errors.append(f"第 {i} 步不是有效对象")
                continue
            if step.get("enabled", True) is False:
                continue
            action = step.get("action", "")
            if action not in known:
                errors.append(f"第 {i} 步：未知操作 {action}")
            if action in ("find_window", "find_child"):
                name = str(step.get("save_as", "") or "").strip()
                if not name:
                    errors.append(f"第 {i} 步：未填写保存句柄名称")
                else:
                    saved.add(name)
            if action in ("set_text", "click", "send_key", "close_window", "check_keyword", "wait_keyword"):
                target = str(step.get("target", "") or "").strip()
                if not target:
                    errors.append(f"第 {i} 步：未指定目标句柄")
                elif target not in saved:
                    warnings.append(f"第 {i} 步：目标句柄“{target}”此前未保存")
            if action in ("if_condition", "wait_condition"):
                c = str(step.get("condition", ""))
                if c.startswith("keyword_") and not str(step.get("keyword", "") or "").strip():
                    errors.append(f"第 {i} 步：条件关键字不能为空")
        if errors:
            text = "发现以下问题：\n\n" + "\n".join(f"• {x}" for x in errors)
            if warnings:
                text += "\n\n提醒：\n" + "\n".join(f"• {x}" for x in warnings)
            QMessageBox.warning(self, "工作流检查", text)
        elif warnings:
            QMessageBox.information(self, "工作流检查", "没有阻止运行的错误。\n\n提醒：\n" + "\n".join(f"• {x}" for x in warnings))
        else:
            QMessageBox.information(self, "工作流检查", "检查通过：未发现明显配置错误。")

    def selected_rows(self):
        rows = sorted({self._item_data_row(item) for item in self.list.selectedItems()})
        rows = [r for r in rows if r >= 0]
        current = self.current_data_row()
        if not rows and current >= 0:
            rows = [current]
        return rows


    def delete(self):
        rows = self.selected_rows()
        if not rows:
            return
        actions = [action_label(self.data["steps"][r].get("action")) for r in rows]
        if len(rows) == 1:
            msg = f"确定删除第 {rows[0] + 1} 步“{actions[0]}”吗？"
        else:
            msg = f"确定删除选中的 {len(rows)} 个步骤吗？\n\n" + "\n".join(f"第 {r+1} 步：{a}" for r, a in zip(rows, actions))
        reply = QMessageBox.question(self, "删除步骤", msg, QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        first = rows[0]
        for r in reversed(rows):
            self.data["steps"].pop(r)
        self.refresh()
        if self.data.get("steps"):
            self.set_current_data_row(min(first, len(self.data["steps"]) - 1))
        self.workflowChanged.emit()

    def duplicate(self):
        rows = self.selected_rows()
        if not rows:
            return
        copies = [json.loads(json.dumps(self.data["steps"][r])) for r in rows]
        insert_at = rows[-1] + 1
        self.data["steps"][insert_at:insert_at] = copies
        self.refresh()
        self.select_data_rows(list(range(insert_at, insert_at + len(copies))))
        self.workflowChanged.emit()

    def move(self, delta):
        rows = self.selected_rows()
        if not rows:
            return
        if delta < 0:
            if rows[0] <= 0:
                return
            target = rows[0] - 1
            block = [self.data["steps"][r] for r in rows]
            remaining = [s for i, s in enumerate(self.data["steps"]) if i not in rows]
            remaining[target:target] = block
            self.data["steps"] = remaining
            new_rows = [r - 1 for r in rows]
        else:
            if rows[-1] >= len(self.data["steps"]) - 1:
                return
            target = rows[-1] + 2
            block = [self.data["steps"][r] for r in rows]
            remaining = [s for i, s in enumerate(self.data["steps"]) if i not in rows]
            target = min(target - len(rows), len(remaining))
            remaining[target:target] = block
            self.data["steps"] = remaining
            new_rows = [r + 1 for r in rows]
        self.refresh()
        self.select_data_rows(new_rows)
        self.workflowChanged.emit()

    def filter_steps(self, text):
        self._apply_group_visibility()

    def set_group(self):
        rows=self.selected_rows()
        if not rows:
            QMessageBox.information(self, "设置步骤分组", "请先选择一个或多个步骤。")
            return
        current = str(self.data["steps"][rows[0]].get("group", "") or "")
        name,ok=QInputDialog.getText(self,"设置步骤分组","分组名称（留空=取消分组）：", text=current)
        if not ok:return
        name=name.strip()
        for r in rows: self.data["steps"][r]["group"]=name
        self.refresh(); self.select_data_rows(rows); self.workflowChanged.emit()

    def clear_group(self):
        # 取消分组只需要定位到组内任意一个步骤；自动解除该组全部成员，
        # 不再要求用户手动多选整个分组。
        row = self.current_data_row()
        if row < 0 or row >= len(self.data.get("steps", [])):
            QMessageBox.information(self, "取消分组", "请先选中一个分组内的步骤。")
            return
        group = str(self.data["steps"][row].get("group", "") or "").strip()
        if not group:
            QMessageBox.information(self, "取消分组", "当前步骤没有所属分组。")
            return
        affected = [i for i, step in enumerate(self.data.get("steps", [])) if str(step.get("group", "") or "").strip() == group]
        for i in affected:
            self.data["steps"][i]["group"] = ""
        self._collapsed_groups.pop(group, None)
        self.refresh(); self.set_current_data_row(row); self.workflowChanged.emit()

    def rename_group(self):
        row = self.current_data_row()
        if row < 0 or row >= len(self.data.get("steps", [])):
            QMessageBox.information(self, "重命名分组", "请先选中一个分组内的步骤。")
            return
        old = str(self.data["steps"][row].get("group", "") or "").strip()
        if not old:
            QMessageBox.information(self, "重命名分组", "当前步骤没有所属分组。请先设置分组。")
            return
        new, ok = QInputDialog.getText(self, "重命名分组", "新的分组名称：", text=old)
        if not ok:
            return
        new = new.strip()
        if not new:
            QMessageBox.information(self, "重命名分组", "分组名称不能为空；如需取消分组，请使用“取消分组”。")
            return
        if new == old:
            return
        for step in self.data.get("steps", []):
            if str(step.get("group", "") or "").strip() == old:
                step["group"] = new
        collapsed = self._collapsed_groups.pop(old, False)
        self._collapsed_groups[new] = collapsed
        self.refresh(); self.set_current_data_row(row); self.workflowChanged.emit()

    def visual_condition(self):
        rows=self.selected_rows()
        row=rows[0] if rows else self.current_data_row()
        if row<0 or row>=len(self.data.get("steps", [])):
            QMessageBox.information(self, "可视化条件", "请先选择一个“条件判断 IF / ELSE”步骤。")
            return
        s=self.data["steps"][row]
        action = normalize_action(s.get("action", ""))
        if action!="if_condition":
            QMessageBox.information(self, "可视化条件", "当前步骤不是“条件判断 IF / ELSE”。请先选中一个条件判断步骤。")
            return
        try:
            from advanced_center import ConditionBuilderDialog
            logic=s.get("logic") or s.get("conditions")
            if not logic:
                logic={"op":"and","items":[{"condition":s.get("condition","keyword_contains"),"target":s.get("target",""),"keyword":s.get("keyword",s.get("expected",""))}]}
            dlg=ConditionBuilderDialog(self,logic)
            if dlg.exec()==QDialog.Accepted:
                s["logic"]=dlg.get_logic(); self.refresh(); self.set_current_data_row(row); self.workflowChanged.emit()
        except Exception as e: QMessageBox.warning(self,"条件编辑器",f"打开条件编辑器失败：{type(e).__name__}: {e}")

    def get_data(self):
        self.save_form()
        return self.data
