# -*- coding: utf-8 -*-
"""句柄上号器发布辅助工具：根据更新 ZIP 自动生成 manifest.json 与 SHA-256。

用法：双击同目录的“生成更新清单.bat”，按提示填写；也可将 ZIP 拖到 BAT 上。
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

VERSION_RE = re.compile(r"^(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))+(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ask(label, default=""):
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or default


def main():
    parser = argparse.ArgumentParser(description="自动计算更新 ZIP 的 SHA-256 并生成 JSON 更新清单")
    parser.add_argument("--package", help="更新 ZIP 本地路径；也可拖动 ZIP 到 BAT 启动")
    parser.add_argument("--version", help="发布版本，如 3.0.22")
    parser.add_argument("--package-url", help="上传后可直接下载 ZIP 的 HTTPS URL，或相对 manifest 的文件名")
    parser.add_argument("--min-version", help="最低兼容版本，例如 3.0.21")
    parser.add_argument("--notes", help="更新说明")
    parser.add_argument("--output", help="输出 manifest.json 的路径")
    args = parser.parse_args()

    try:
        package_text = args.package or ask("更新 ZIP 本地路径（可拖入文件）")
        package = Path(package_text.strip('"')).expanduser().resolve()
        if not package.is_file() or package.suffix.lower() != ".zip":
            raise ValueError(f"找不到 ZIP 文件，或文件不是 .zip：{package}")

        version = args.version or ask("本次发布版本", "3.0.22")
        version = version.strip()
        if not VERSION_RE.fullmatch(version):
            raise ValueError("版本号必须是完整数字版本，例如 3.0.22；不要填写 v22")

        package_url = args.package_url or ask("上传后的 ZIP 直链（HTTPS；若同目录可填写 ZIP 文件名）")
        if not package_url:
            raise ValueError("package_url 不能为空")
        parsed = urlparse(package_url)
        if parsed.scheme and parsed.scheme != "https":
            raise ValueError("在线下载地址必须使用 HTTPS；不能填写普通网页或 HTTP 地址")

        min_version = args.min_version or ask("最低兼容版本", "3.0.21")
        if min_version and not VERSION_RE.fullmatch(min_version):
            raise ValueError("最低兼容版本格式无效，请填写完整版本号，例如 3.0.21")
        notes = args.notes if args.notes is not None else ask("更新说明", "v22：版本号严格校验、更新清单字段校验与发布流程自动化")
        output_text = args.output or ask("清单输出路径", str(package.parent / "manifest.json"))
        output = Path(output_text).expanduser().resolve()

        manifest = {
            "version": version,
            "package_url": package_url,
            "sha256": sha256_file(package),
            "min_version": min_version,
            "notes": notes,
        }
        output.parent.mkdir(parents=True, exist_ok=True)
        temp = output.with_name(output.name + ".tmp")
        temp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temp.replace(output)
        print("\n生成成功！")
        print(f"更新 ZIP：{package}")
        print(f"SHA-256：{manifest['sha256']}")
        print(f"清单文件：{output}")
        print("下一步：把 ZIP 和 manifest.json 上传到网站；确认 package_url 是可直接下载 ZIP 的地址。")
        print("提醒：如果你在上传前又修改了 ZIP，必须重新运行本工具生成 SHA-256。")
    except (OSError, ValueError) as exc:
        print(f"生成失败：{exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
