"""安全更新核心：manifest 校验、SHA-256、ZIP 路径检查、事务备份与回滚。

在线 manifest 仅允许 HTTPS。应用更新由独立 helper 在主程序退出后执行。
为保护用户数据，更新只覆盖程序代码/静态资源；JSON、CSV、config/、workflows/ 永不覆盖。
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import tempfile
from datetime import datetime
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

APP_VERSION = "3.0.22"
MAX_PACKAGE_BYTES = 500 * 1024 * 1024
MAX_MEMBERS = 5000
MAX_UNPACKED_BYTES = 2 * 1024 * 1024 * 1024
ALLOWED_SUFFIXES = {".py", ".ico", ".png", ".jpg", ".jpeg", ".webp", ".txt", ".md", ".bat"}
PROTECTED_TOP_DIRS = {"config", "workflows", "logs", "data", "backups", "updates"}


class UpdateError(RuntimeError):
    pass


def _read_source(source, timeout=15):
    source = str(source or "").strip()
    if not source:
        raise UpdateError("尚未设置更新清单地址或本地路径")
    parsed = urllib.parse.urlparse(source)
    if parsed.scheme in ("http", "https"):
        if parsed.scheme != "https":
            raise UpdateError("在线更新清单必须使用 HTTPS")
        req = urllib.request.Request(source, headers={"User-Agent": "SeerToolManager-Updater/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as response:
            data = response.read(2 * 1024 * 1024 + 1)
        if len(data) > 2 * 1024 * 1024:
            raise UpdateError("更新清单超过 2 MB 限制")
        return data, source
    path = Path(source).expanduser().resolve()
    if not path.is_file():
        raise UpdateError(f"更新清单不存在：{path}")
    if path.stat().st_size > 2 * 1024 * 1024:
        raise UpdateError("更新清单超过 2 MB 限制")
    return path.read_bytes(), str(path)


_VERSION_RE = re.compile(
    r"^[vV]?(?P<core>(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))+)(?:-(?P<pre>[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)


def _parse_version(value):
    """严格解析完整数字版本；拒绝 v22 这类有歧义的单段版本号。"""
    if not isinstance(value, str):
        return None
    text = value.strip()
    match = _VERSION_RE.fullmatch(text)
    if not match:
        return None
    core_text = match.group("core")
    core = tuple(int(part) for part in core_text.split("."))
    pre_text = match.group("pre")
    prerelease = None
    if pre_text is not None:
        identifiers = pre_text.split(".")
        # SemVer numeric prerelease identifiers may not contain leading zeroes.
        if any(part.isdigit() and len(part) > 1 and part.startswith("0") for part in identifiers):
            return None
        prerelease = tuple(identifiers)
    return core, prerelease


def version_key(value):
    """把 3.0.22 等完整版本转成数字元组；拒绝 v22 这种歧义写法。"""
    parsed = _parse_version(value)
    return parsed[0] if parsed else ()


def _compare_versions(left, right):
    """返回 -1、0、1；数字位数不同按缺失位补零，预发布版低于正式版。"""
    a, b = _parse_version(left), _parse_version(right)
    if a is None or b is None:
        raise UpdateError("版本号格式无效；请使用 3.0.22 或 3.0.22-beta.1 这类完整版本格式")
    ac, ap = a
    bc, bp = b
    length = max(len(ac), len(bc))
    ac += (0,) * (length - len(ac))
    bc += (0,) * (length - len(bc))
    if ac != bc:
        return 1 if ac > bc else -1
    if ap is None and bp is None:
        return 0
    if ap is None:
        return 1
    if bp is None:
        return -1
    for x, y in zip(ap, bp):
        if x == y:
            continue
        xn, yn = x.isdigit(), y.isdigit()
        if xn and yn:
            return 1 if int(x) > int(y) else -1
        if xn != yn:
            return -1 if xn else 1
        return 1 if x > y else -1
    if len(ap) == len(bp):
        return 0
    return 1 if len(ap) > len(bp) else -1


def is_newer_version(candidate, current):
    """仅将格式有效且严格高于当前版本的版本判定为新版本。"""
    try:
        return _compare_versions(candidate, current) > 0
    except UpdateError:
        return False


def validate_min_version(min_version, current=APP_VERSION):
    """校验清单最低兼容版本；空字段兼容旧清单，非空字段必须有效且当前版达标。"""
    if min_version is None or min_version == "":
        return True
    if not isinstance(min_version, str):
        raise UpdateError("更新清单 min_version 必须是版本字符串")
    minimum = min_version.strip()
    if not minimum:
        return True
    if _parse_version(minimum) is None:
        raise UpdateError(f"更新清单 min_version 格式无效：{minimum!r}")
    if _parse_version(current) is None:
        raise UpdateError(f"当前程序版本号格式无效：{current!r}")
    if _compare_versions(current, minimum) < 0:
        raise UpdateError(
            f"当前程序版本 {current} 低于此更新要求的最低兼容版本 {minimum}；"
            "请先安装兼容的中间版本，或联系发布者调整更新清单。"
        )
    return True


def load_manifest(source):
    raw, origin = _read_source(source)
    try:
        data = json.loads(raw.decode("utf-8-sig"))
    except Exception as exc:
        raise UpdateError(f"更新清单不是有效 JSON：{exc}") from exc
    if not isinstance(data, dict):
        raise UpdateError("更新清单根节点必须是 JSON 对象")
    version_value = data.get("version")
    package_url_value = data.get("package_url")
    sha256_value = data.get("sha256")
    if not isinstance(version_value, str):
        raise UpdateError("更新清单 version 必须是字符串，例如 3.0.22")
    if not isinstance(package_url_value, str):
        raise UpdateError("更新清单 package_url 必须是 URL 或本地文件路径字符串")
    if not isinstance(sha256_value, str):
        raise UpdateError("更新清单 sha256 必须是 64 位十六进制字符串")
    version = version_value.strip()
    package_url = package_url_value.strip()
    sha256 = sha256_value.strip().lower()
    min_version_value = data.get("min_version", "")
    if min_version_value is not None and not isinstance(min_version_value, str):
        raise UpdateError("更新清单 min_version 必须是版本字符串")
    min_version = str(min_version_value or "").strip()
    if not version:
        raise UpdateError("更新清单缺少 version")
    if _parse_version(version) is None:
        raise UpdateError(f"更新清单 version 格式无效：{version!r}；请使用完整版本号，例如 3.0.22")
    validate_min_version(min_version, APP_VERSION)
    if not package_url:
        raise UpdateError("更新清单缺少 package_url")
    if len(sha256) != 64 or any(c not in "0123456789abcdef" for c in sha256):
        raise UpdateError("更新清单 sha256 必须是 64 位十六进制摘要")
    notes_value = data.get("notes", "")
    if notes_value is not None and not isinstance(notes_value, str):
        raise UpdateError("更新清单 notes 必须是字符串")
    parsed_origin = urllib.parse.urlparse(origin)
    if parsed_origin.scheme in ("http", "https"):
        package_url = urllib.parse.urljoin(origin, package_url)
        if urllib.parse.urlparse(package_url).scheme != "https":
            raise UpdateError("在线更新包必须使用 HTTPS")
    else:
        package_path = Path(package_url)
        if not package_path.is_absolute():
            package_path = Path(origin).parent / package_path
        package_url = str(package_path.resolve())
    return {"version": version, "package_url": package_url, "sha256": sha256,
            "notes": str(notes_value or ""), "min_version": min_version,
            "origin": origin}


def _copy_limited(source, destination):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    parsed = urllib.parse.urlparse(str(source))
    if parsed.scheme in ("http", "https"):
        if parsed.scheme != "https":
            raise UpdateError("在线更新包必须使用 HTTPS")
        req = urllib.request.Request(str(source), headers={"User-Agent": "SeerToolManager-Updater/1.0"})
        digest = hashlib.sha256()
        total = 0
        with urllib.request.urlopen(req, timeout=30) as response, destination.open("wb") as out:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_PACKAGE_BYTES:
                    raise UpdateError("更新包超过 500 MB 限制")
                digest.update(chunk)
                out.write(chunk)
        return digest.hexdigest(), total
    source_path = Path(source)
    if not source_path.is_file():
        raise UpdateError(f"更新包不存在：{source_path}")
    if source_path.stat().st_size > MAX_PACKAGE_BYTES:
        raise UpdateError("更新包超过 500 MB 限制")
    digest = hashlib.sha256()
    total = 0
    with source_path.open("rb") as inp, destination.open("wb") as out:
        while True:
            chunk = inp.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            digest.update(chunk)
            out.write(chunk)
    return digest.hexdigest(), total


def download_and_verify(manifest, destination):
    destination = Path(destination)
    temp = destination.with_suffix(destination.suffix + ".part")
    try:
        digest, size = _copy_limited(manifest["package_url"], temp)
        if digest.lower() != manifest["sha256"].lower():
            raise UpdateError(f"SHA-256 校验失败：期望 {manifest['sha256']}，实际 {digest}")
        validate_update_zip(temp)
        destination.parent.mkdir(parents=True, exist_ok=True)
        os.replace(temp, destination)
        return {"path": str(destination), "sha256": digest, "size": size}
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def _normalized_member(name, root_name=None):
    # ZIP 规范以 / 分隔，但恶意/手工构造的包可能含反斜杠；先统一分隔符再做路径校验。
    raw_name = str(name or "")
    if "\x00" in raw_name:
        raise UpdateError(f"ZIP 中存在不安全路径：{name}")
    normalized_name = raw_name.replace("\\", "/")
    path = PurePosixPath(normalized_name)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise UpdateError(f"ZIP 中存在不安全路径：{name}")
    parts = list(path.parts)
    if parts and parts[0].endswith(":"):
        raise UpdateError(f"ZIP 中存在绝对路径：{name}")
    if root_name and parts and parts[0] == root_name:
        parts = parts[1:]
    elif len(parts) > 1 and parts[0].lower() in {"上号器", "seer_tool_manager", "seer-tool-manager"}:
        parts = parts[1:]
    if not parts:
        return None
    rel = PurePosixPath(*parts)
    if rel.parts[0].lower() in PROTECTED_TOP_DIRS:
        return None
    suffix = Path(rel.name).suffix.lower()
    if suffix not in ALLOWED_SUFFIXES:
        return None
    if suffix == ".json" or rel.name.lower().endswith((".csv", ".jsonl", ".log")):
        return None
    return Path(*rel.parts)


def validate_update_zip(zip_path):
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            infos = zf.infolist()
            if len(infos) > MAX_MEMBERS:
                raise UpdateError(f"更新包文件数超过 {MAX_MEMBERS}")
            total = 0
            names = [i.filename for i in infos if not i.is_dir()]
            parsed_names = [PurePosixPath(str(n).replace("\\", "/")).parts for n in names if PurePosixPath(str(n).replace("\\", "/")).parts]
            roots = {parts[0] for parts in parsed_names}
            single_root = next(iter(roots)) if len(roots) == 1 and parsed_names and all(len(parts) > 1 for parts in parsed_names) else None
            seen_targets = set()
            for info in infos:
                if info.is_dir():
                    continue
                rel = _normalized_member(info.filename, single_root)
                if rel is not None:
                    target_key = "/".join(rel.parts).casefold()
                    if target_key in seen_targets:
                        raise UpdateError(f"更新包存在重复目标路径：{info.filename}")
                    seen_targets.add(target_key)
                total += info.file_size
                if total > MAX_UNPACKED_BYTES:
                    raise UpdateError("更新包解压总量超过 2 GB 限制")
                if info.file_size > 0 and info.compress_size == 0:
                    raise UpdateError(f"ZIP 条目压缩信息异常：{info.filename}")
            bad = zf.testzip()
            if bad:
                raise UpdateError(f"ZIP CRC 检查失败：{bad}")
    except zipfile.BadZipFile as exc:
        raise UpdateError(f"更新包不是有效 ZIP：{exc}") from exc
    return True


def _update_files(zip_path, target_root):
    target_root = Path(target_root).resolve()
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = [i.filename for i in zf.infolist() if not i.is_dir()]
        # 若所有文件均处于同一个顶层目录，则只剥离该目录；否则按常见包根名剥离。
        roots = {PurePosixPath(n).parts[0] for n in names if PurePosixPath(n).parts}
        single_root = next(iter(roots)) if len(roots) == 1 else None
        for info in zf.infolist():
            if info.is_dir():
                continue
            rel = _normalized_member(info.filename, single_root)
            if rel is None:
                continue
            dest = (target_root / rel).resolve()
            if target_root != dest and target_root not in dest.parents:
                raise UpdateError(f"更新文件超出安装目录：{info.filename}")
            yield zf, info, rel, dest


def apply_update_archive(zip_path, target_root):
    """事务式应用：先完整解压到暂存目录，备份覆盖文件，失败自动恢复。"""
    zip_path = Path(zip_path).resolve()
    target_root = Path(target_root).resolve()
    validate_update_zip(zip_path)
    updates_dir = target_root / "config" / "updates"
    updates_dir.mkdir(parents=True, exist_ok=True)
    # 毫秒/微秒级唯一标记，避免同一秒内连续更新发生目录冲突。
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_root = updates_dir / "backups" / stamp
    stage_root = updates_dir / "stage" / stamp
    backup_root.mkdir(parents=True, exist_ok=False)
    try:
        stage_root.mkdir(parents=True, exist_ok=False)
    except Exception:
        shutil.rmtree(backup_root, ignore_errors=True)
        raise
    entries = []
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            names = [i.filename for i in zf.infolist() if not i.is_dir()]
            parsed_names = [PurePosixPath(n).parts for n in names if PurePosixPath(n).parts]
            roots = {parts[0] for parts in parsed_names}
            single_root = next(iter(roots)) if len(roots) == 1 and parsed_names and all(len(parts) > 1 for parts in parsed_names) else None
            for info in zf.infolist():
                if info.is_dir():
                    continue
                rel = _normalized_member(info.filename, single_root)
                if rel is None:
                    continue
                dest = (target_root / rel).resolve()
                if target_root != dest and target_root not in dest.parents:
                    raise UpdateError(f"更新文件超出安装目录：{info.filename}")
                staged = stage_root / rel
                staged.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, staged.open("wb") as out:
                    shutil.copyfileobj(src, out)
                entries.append({"relative": rel.as_posix(), "existed": dest.exists(), "source": str(staged)})
        if not entries:
            raise UpdateError("更新包中没有可安全更新的程序文件（JSON/CSV/配置/工作流不会覆盖）")
        for entry in entries:
            rel = Path(entry["relative"])
            dest = (target_root / rel).resolve()
            if entry["existed"]:
                backup = backup_root / rel
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, backup)
                entry["backup"] = rel.as_posix()
            else:
                entry["backup"] = None
        record = {"created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "target_root": str(target_root),
                  "backup_root": str(backup_root), "entries": [{k: v for k, v in e.items() if k != "source"} for e in entries]}
        latest = updates_dir / "last_update.json"
        latest_tmp = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", newline="", dir=str(updates_dir),
                prefix="last_update.", suffix=".tmp", delete=False
            ) as f:
                latest_tmp = Path(f.name)
                json.dump(record, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(str(latest_tmp), str(latest))
            latest_tmp = None
        finally:
            if latest_tmp is not None:
                latest_tmp.unlink(missing_ok=True)
        for entry in entries:
            dest = (target_root / Path(entry["relative"])).resolve()
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(entry["source"], dest)
        return {"updated": len(entries), "backup": str(backup_root), "manifest": str(latest)}
    except Exception:
        # 根据备份清单尽最大努力回滚本次已写入的文件。
        for entry in reversed(entries):
            dest = (target_root / Path(entry["relative"])).resolve()
            try:
                if entry.get("existed") and entry.get("backup"):
                    backup = backup_root / Path(entry["backup"])
                    if backup.is_file():
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(backup, dest)
                elif not entry.get("existed"):
                    dest.unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:
        shutil.rmtree(stage_root, ignore_errors=True)


def rollback_last_update(target_root):
    target_root = Path(target_root).resolve()
    latest = target_root / "config" / "updates" / "last_update.json"
    if not latest.is_file():
        raise UpdateError("没有找到可回滚的更新记录")
    try:
        record = json.loads(latest.read_text(encoding="utf-8"))
        backup_root = Path(record["backup_root"]).resolve()
        recorded_root = Path(record["target_root"]).resolve()
        if recorded_root != target_root or target_root not in backup_root.parents:
            raise UpdateError("回滚记录路径校验失败，已拒绝操作")
        entries = record.get("entries", [])
        if not isinstance(entries, list) or not entries:
            raise UpdateError("回滚记录为空或格式错误")
        for entry in reversed(entries):
            rel = Path(str(entry.get("relative", "")))
            if rel.is_absolute() or ".." in rel.parts:
                raise UpdateError("回滚记录包含不安全路径")
            dest = (target_root / rel).resolve()
            if target_root != dest and target_root not in dest.parents:
                raise UpdateError("回滚目标超出安装目录")
            if entry.get("existed"):
                backup_rel = Path(str(entry.get("backup") or ""))
                backup = (backup_root / backup_rel).resolve()
                if backup_root != backup and backup_root not in backup.parents:
                    raise UpdateError("备份路径校验失败")
                if not backup.is_file():
                    raise UpdateError(f"缺少回滚备份：{backup}")
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(backup, dest)
            else:
                dest.unlink(missing_ok=True)
        rolled_name = latest.with_name("last_update_rolled_back_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".json")
        latest.rename(rolled_name)
        return {"restored": len(entries), "backup": str(backup_root)}
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError(f"回滚失败：{exc}") from exc


def _wait_pid(pid, timeout=180):
    if not pid:
        return
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            # Windows 优先用 OpenProcess；其他环境用 os.kill(pid, 0) 轮询。
            if os.name == "nt":
                import ctypes
                handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))
                if not handle:
                    return
                ctypes.windll.kernel32.CloseHandle(handle)
            else:
                os.kill(int(pid), 0)
        except Exception:
            return
        time.sleep(0.5)
    raise UpdateError("等待主程序退出超时；未应用更新")


def _helper_main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", help="更新 ZIP 路径")
    parser.add_argument("--rollback", action="store_true", help="回滚最近一次更新")
    parser.add_argument("--target", required=True, help="程序目录")
    parser.add_argument("--wait-pid", type=int, default=0)
    parser.add_argument("--restart", default="", help="操作后重新启动的脚本路径")
    args = parser.parse_args(argv)
    target = Path(args.target).resolve()
    try:
        _wait_pid(args.wait_pid)
        if args.rollback:
            result = rollback_last_update(target)
        elif args.apply:
            result = apply_update_archive(args.apply, target)
        else:
            raise UpdateError("必须指定 --apply 或 --rollback")
        if args.restart:
            restart = Path(args.restart).resolve()
            if restart.is_file() and not getattr(sys, "frozen", False):
                subprocess.Popen([sys.executable, str(restart)], cwd=str(target), close_fds=True)
        print(json.dumps({"ok": True, **result}, ensure_ascii=False))
        return 0
    except Exception as exc:
        try:
            (target / "config" / "updates" / "update_error.txt").write_text(str(exc), encoding="utf-8")
        except Exception:
            pass
        print(f"更新失败：{exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(_helper_main())
