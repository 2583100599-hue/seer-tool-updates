import json
import hashlib
import os
import shutil
import tempfile
import threading
import time
from pathlib import Path


class MemoryStore:
    """保存程序设置、项目设置和运行断点，不修改原始 CSV。"""

    def __init__(self, base_dir):
        self.base_dir = Path(base_dir)
        self.config_dir = self.base_dir / "config"
        self.config_dir.mkdir(parents=True, exist_ok=True)

        self.settings_file = self.config_dir / "settings.json"
        self.projects_file = self.config_dir / "projects.json"
        self.runtime_file = self.config_dir / "runtime_state.json"

        self._lock = threading.RLock()
        self.recovery_warnings = []
        self.settings = self._load(self.settings_file, {})
        self.projects = self._load(self.projects_file, {})
        self.runtime = self._load(self.runtime_file, {})

    def _load(self, path, default):
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, type(default)):
                raise ValueError(f"JSON 顶层类型不匹配，期望 {type(default).__name__}")
            return data
        except Exception as exc:
            # 原文件先保留，并尽力复制一份备份；后续即使保存默认值也不至于彻底丢掉损坏文件。
            backup = None
            try:
                # 若原文件自上次备份后未变化，复用已有备份，避免每次启动都复制一份。
                for candidate in path.parent.glob(path.name + ".corrupt-*.bak"):
                    try:
                        if candidate.stat().st_size == path.stat().st_size and candidate.stat().st_mtime == path.stat().st_mtime:
                            backup = candidate
                            break
                    except OSError:
                        continue
                if backup is None:
                    stamp = time.strftime("%Y%m%d-%H%M%S")
                    backup = path.with_name(f"{path.name}.corrupt-{stamp}.bak")
                    suffix = 1
                    while backup.exists():
                        backup = path.with_name(f"{path.name}.corrupt-{stamp}-{suffix}.bak")
                        suffix += 1
                    shutil.copy2(path, backup)
                self.recovery_warnings.append(
                    f"{path.name} 读取失败（{type(exc).__name__}），原文件已备份为 {backup.name}；程序暂以默认值继续。"
                )
            except Exception as backup_exc:
                self.recovery_warnings.append(
                    f"{path.name} 读取失败（{type(exc).__name__}），自动备份也失败（{type(backup_exc).__name__}）；请先手动备份该文件。"
                )
            return default

    def _save(self, path, data):
        with self._lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = None
            try:
                # 临时文件与目标文件放在同一目录，使用唯一文件名并 fsync 后再原子替换。
                with tempfile.NamedTemporaryFile(
                    mode="w", encoding="utf-8", newline="", dir=str(path.parent),
                    prefix=path.name + ".", suffix=".tmp", delete=False
                ) as f:
                    tmp_path = Path(f.name)
                    json.dump(data, f, ensure_ascii=False, indent=2)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(str(tmp_path), str(path))
                tmp_path = None
            finally:
                if tmp_path is not None:
                    try:
                        tmp_path.unlink(missing_ok=True)
                    except Exception:
                        pass

    def save_settings(self, **kwargs):
        with self._lock:
            self.settings.update(kwargs)
            self._save(self.settings_file, self.settings)

    @staticmethod
    def project_key(exe_path, csv_path):
        raw = f"{Path(exe_path).resolve()}|{Path(csv_path).resolve()}".lower()
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]

    def get_project(self, exe_path, csv_path):
        if not exe_path or not csv_path:
            return {}
        with self._lock:
            return dict(self.projects.get(self.project_key(exe_path, csv_path), {}))

    def save_project(self, exe_path, csv_path, **kwargs):
        if not exe_path or not csv_path:
            return
        key = self.project_key(exe_path, csv_path)
        with self._lock:
            project = dict(self.projects.get(key, {}))
            project.update({
                "exe": str(Path(exe_path).resolve()),
                "csv": str(Path(csv_path).resolve()),
            })
            project.update(kwargs)
            self.projects[key] = project
            self._save(self.projects_file, self.projects)

    def get_runtime(self, exe_path, csv_path):
        if not exe_path or not csv_path:
            return {}
        with self._lock:
            return dict(self.runtime.get(self.project_key(exe_path, csv_path), {}))

    def save_runtime(self, exe_path, csv_path, **kwargs):
        if not exe_path or not csv_path:
            return
        key = self.project_key(exe_path, csv_path)
        with self._lock:
            state = dict(self.runtime.get(key, {}))
            state.update(kwargs)
            self.runtime[key] = state
            self._save(self.runtime_file, self.runtime)

    def save_all(self):
        with self._lock:
            self._save(self.settings_file, self.settings)
            self._save(self.projects_file, self.projects)
            self._save(self.runtime_file, self.runtime)
