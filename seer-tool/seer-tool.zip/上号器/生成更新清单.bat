@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    if "%~1"=="" (
        py "生成更新清单.py"
    ) else (
        py "生成更新清单.py" --package "%~1"
    )
) else (
    if "%~1"=="" (
        python "生成更新清单.py"
    ) else (
        python "生成更新清单.py" --package "%~1"
    )
)
echo.
pause
