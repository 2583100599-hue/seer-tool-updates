import os
import re
import sys
import json
import threading
import time
import tempfile
from collections import deque
from datetime import datetime, timedelta
from pathlib import Path

from PySide6.QtCore import Signal, QObject, Qt, QTimer, QDateTime, QTime, QDate, QEvent
from PySide6.QtGui import QBrush, QColor, QPalette, QIcon, QPainter, QPolygon, QPen
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QLineEdit, QPushButton, QFileDialog, QTableWidget, QTableWidgetItem,
    QTextEdit, QMessageBox, QSpinBox, QHeaderView, QCheckBox, QComboBox,
    QTabWidget, QListWidget, QInputDialog, QAbstractItemView, QGroupBox, QFormLayout, QDateTimeEdit, QTimeEdit, QProgressBar,
    QDialog, QDialogButtonBox, QToolButton, QTreeWidget, QTreeWidgetItem, QSpinBox, QSplitter, QMenu, QStyledItemDelegate, QStyle, QStyleOptionViewItem
)

from account_manager import load_accounts, is_expired
from process_manager import ProcessManager
from workflow_engine import WorkflowEngine, WorkflowExit
from workflow_store import WorkflowStore
from win32_controller import Win32Controller
from workflow_editor import WorkflowEditor
from memory_store import MemoryStore
from csv_manager import load_rows, save_rows
from software_profiles import SoftwareProfileStore
from csv_projects import CSVProjectStore
from advanced_center import ConditionBuilderDialog, DebuggerDialog, LogCenterDialog, AdvancedSchedulerDialog
from input_lock import InputLock
from status_manager import StatusTracker
from security_utils import SecretRedactor
from update_manager import APP_VERSION, load_manifest, download_and_verify, is_newer_version


class ProcessCheckDialog(QDialog):
    """本轮进程检测：检测、筛选、排序、重跑统一入口。"""
    retry_requested = Signal(list, str)
    exclude_requested = Signal(int, str)
    restore_requested = Signal(int, str)
    locate_requested = Signal(int)

    def __init__(self, rows, total_count, exited_count, alive_count, killed_count,
                 failed_indices=None, parent=None):
        super().__init__(parent)
        self.rows = list(rows)
        self.total_count = int(total_count)
        self.exited_count = int(exited_count)
        self.alive_count = int(alive_count)
        self.killed_count = int(killed_count)
        self.failed_indices = set(int(i) for i in (failed_indices or []))
        self.setWindowTitle("进程检测")
        self.setFixedSize(900, 620)
        self.setModal(False)
        self._sort_column = None
        self._sort_order = Qt.AscendingOrder
        self._build_ui()
        self._refresh_table()

    def _build_ui(self):
        self.setStyleSheet("""
            QDialog { background:#f8f9fa; }
            QLabel { color:#202124; }
            QLineEdit {
                height:34px; min-height:34px; max-height:34px;
                border:1px solid #cfd4da; border-radius:6px;
                background:#ffffff; color:#202124;
                padding:0 10px; font-size:13px;
            }
            QLineEdit:hover { border-color:#b7bdc4; }
            QLineEdit:focus { border:1px solid #8e969f; }
            QTableWidget {
                border:1px solid #d8dde2; border-radius:6px;
                background:#ffffff; alternate-background-color:#fafbfc;
                gridline-color:#e5e8eb; selection-background-color:#e9edf1;
                selection-color:#202124; outline:0; font-size:13px;
            }
            QTableWidget::item { padding:0 8px; }
            QHeaderView { background:#f3f5f6; }
            QHeaderView::section {
                height:36px; background:#f3f5f6; color:#59616a;
                border-top:0; border-bottom:1px solid #d8dde2;
                border-left:0; border-right:1px solid #e1e5e8;
                padding:0 8px; font-size:12px; font-weight:600;
            }
            QHeaderView::section:last { border-right:0; }
            QTableCornerButton::section { background:#f3f5f6; border:0; border-bottom:1px solid #d8dde2; }
            QPushButton#rerunButton {
                height:34px; min-height:34px; min-width:76px;
                border:1px solid #cfd4da; border-radius:6px;
                background:#ffffff; color:#30343a; font-size:13px;
            }
            QPushButton#rerunButton:hover { background:#f1f3f5; }
            QPushButton#rerunButton:disabled { color:#a4aab0; background:#f5f6f7; }
            QMenu { border:1px solid #d5d9dd; background:#fff; padding:4px; }
            QMenu::item { padding:7px 22px; border-radius:4px; }
            QMenu::item:selected { background:#eef1f3; }
        """)
        root=QVBoxLayout(self); root.setContentsMargins(22,18,22,16); root.setSpacing(0)
        title_row=QHBoxLayout(); title_row.setContentsMargins(0,0,0,8)
        title=QLabel("进程检测"); title.setStyleSheet("font-size:19px;font-weight:600;color:#202124;")
        title_row.addWidget(title); title_row.addStretch(1)
        subtitle=QLabel("本轮及重跑记录"); subtitle.setStyleSheet("font-size:12px;color:#8a929a;")
        title_row.addWidget(subtitle); root.addLayout(title_row)
        line=QWidget(); line.setFixedHeight(1); line.setStyleSheet("background:#dfe3e6;"); root.addWidget(line)

        toolbar=QHBoxLayout(); toolbar.setContentsMargins(0,10,0,12); toolbar.setSpacing(8)
        fl=QLabel("状态筛选"); fl.setStyleSheet("font-size:12px;color:#737b83;"); toolbar.addWidget(fl)
        self.filter_box=QComboBox(); self.filter_box.addItems(["全部","运行中","主动排除","已退出"])
        self.filter_box.setCurrentIndex(0); self.filter_box.setFixedWidth(118); self.filter_box.setFixedHeight(34)
        self.filter_box.currentTextChanged.connect(self._refresh_table); toolbar.addWidget(self.filter_box)
        toolbar.addStretch(1)
        self.search_box=QLineEdit(); self.search_box.setPlaceholderText("搜索账号或 PID"); self.search_box.setClearButtonEnabled(True)
        self.search_box.setFixedWidth(270); self.search_box.textChanged.connect(self._refresh_table); toolbar.addWidget(self.search_box)
        root.addLayout(toolbar)

        self.table=QTableWidget(0,8)
        self.table.setHorizontalHeaderLabels(["序号","账号","PID","次数","进程状态","任务结果","启动时间","结束方式"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection); self.table.setFocusPolicy(Qt.StrongFocus)
        self.table.viewport().installEventFilter(self); self.table.setSortingEnabled(False); self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(True); self.table.setWordWrap(False); self.table.setTextElideMode(Qt.ElideRight)
        self.table.verticalHeader().setVisible(False); self.table.verticalHeader().setDefaultSectionSize(36)
        header=self.table.horizontalHeader(); header.setFixedHeight(37); header.setDefaultAlignment(Qt.AlignCenter)
        header.setSortIndicatorShown(False); header.sectionClicked.connect(self._sort_by_column)
        for c in range(7): header.setSectionResizeMode(c,QHeaderView.Fixed)
        header.setSectionResizeMode(7,QHeaderView.Stretch)
        header.resizeSection(0,55); header.resizeSection(1,170); header.resizeSection(2,78); header.resizeSection(3,58); header.resizeSection(4,86); header.resizeSection(5,105); header.resizeSection(6,92)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu); self.table.customContextMenuRequested.connect(self._show_context_menu)
        self.empty_label=QLabel("没有符合当前筛选条件的进程",self.table.viewport()); self.empty_label.setAlignment(Qt.AlignCenter)
        self.empty_label.setStyleSheet("color:#9299a0;font-size:13px;background:transparent;"); self.empty_label.hide()
        root.addWidget(self.table,1)

        bottom=QHBoxLayout(); bottom.setContentsMargins(0,10,0,0); bottom.setSpacing(8)
        excluded_count = sum(1 for r in self.rows if r.get("state") == "主动排除")
        summary=QLabel(f"启动 {self.total_count}    ·    已退出 {self.exited_count}    ·    运行中 {self.alive_count}    ·    主动排除 {excluded_count}    ·    主动结束 {self.killed_count}")
        summary.setStyleSheet("font-size:11px;color:#9299a0;"); bottom.addWidget(summary); bottom.addStretch(1)
        self.rerun_filter=QComboBox(); self.rerun_filter.addItems(["重跑未进行全部","重跑失败账号","重跑已退出账号"])
        self.rerun_filter.setCurrentIndex(0)
        self.rerun_filter.setFixedWidth(140); self.rerun_filter.setFixedHeight(34); bottom.addWidget(self.rerun_filter)
        self.rerun_btn=QPushButton("重跑"); self.rerun_btn.setObjectName("rerunButton"); self.rerun_btn.clicked.connect(self._rerun_by_filter); bottom.addWidget(self.rerun_btn)
        root.addLayout(bottom)
        self._update_rerun_button()

    def eventFilter(self,obj,event):
        if obj is self.table.viewport() and event.type()==QEvent.MouseButtonPress and event.button()==Qt.LeftButton:
            if not self.table.indexAt(event.position().toPoint()).isValid(): self.table.clearSelection(); self.table.clearFocus()
        return super().eventFilter(obj,event)

    def mousePressEvent(self,event):
        if event.button()==Qt.LeftButton:
            child=self.childAt(event.position().toPoint())
            if child is None or child is self: self.table.clearSelection(); self.table.clearFocus()
        super().mousePressEvent(event)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,'empty_label'):
            vp=self.table.viewport(); self.empty_label.setGeometry(vp.rect()); self.empty_label.raise_()

    def _sort_by_column(self,column):
        self._sort_order = Qt.DescendingOrder if self._sort_column==column and self._sort_order==Qt.AscendingOrder else Qt.AscendingOrder
        self._sort_column=column; self._refresh_table()

    def _make_item(self,value,muted=False):
        item=QTableWidgetItem(str(value)); item.setTextAlignment(Qt.AlignCenter|Qt.AlignVCenter)
        if muted: item.setForeground(QBrush(QColor("#9aa1a8")))
        return item

    def _refresh_table(self):
        mode=self.filter_box.currentText(); keyword=self.search_box.text().strip().lower()
        allowed={"运行中","主动排除","已退出"} if mode=="全部" else {mode}
        filtered=[r for r in self.rows if r["state"] in allowed and (not keyword or keyword in r["account"].lower() or keyword in r["pid"].lower())]
        if self._sort_column is not None:
            col=self._sort_column
            def key(r):
                if col==0:return int(r.get("index",-1))
                if col==1:return r.get("account","").casefold()
                if col==2:
                    try:return int(r.get("pid",0))
                    except:return r.get("pid","")
                if col==3:return int(r.get("attempt",1) or 1)
                if col==4:return r.get("state","")
                if col==5:return r.get("result","")
                if col==6:return r.get("started","")
                return r.get("reason","")
            filtered.sort(key=key,reverse=self._sort_order==Qt.DescendingOrder)
        self.table.clearContents(); self.table.setRowCount(len(filtered))
        for r,row in enumerate(filtered):
            idx=int(row.get("index",-1))
            values=[str(idx+1) if idx >= 0 else "—",row["account"],row["pid"],str(row.get("attempt",1)),row["state"],row.get("result","—"),row["started"],row["reason"]]
            for c,v in enumerate(values):
                item=self._make_item(v, (c in (5,7) and v=="—")); item.setData(Qt.UserRole,idx); self.table.setItem(r,c,item)
        self.table.clearSelection(); self.empty_label.setVisible(not filtered)
        if not filtered:self.empty_label.raise_()
        self._update_rerun_button()

    def _selected_index(self):
        row=self.table.currentRow()
        if row<0:return None
        item=self.table.item(row,0)
        if not item:return None
        try:return int(item.data(Qt.UserRole))
        except:return None

    def _rerun_by_filter(self):
        mode=self.rerun_filter.currentText()
        if mode=="重跑失败账号":
            indices=sorted(self.failed_indices); label="失败账号"
        elif mode=="重跑已退出账号":
            indices=sorted({int(r.get("index",-1)) for r in self.rows if int(r.get("index",-1))>=0 and r.get("state")=="已退出"}); label="已退出账号"
        else:
            # “未进行全部”=失败账号 + 已退出账号，按账号原始索引去重，只跑一次。
            exited_indices={int(r.get("index",-1)) for r in self.rows if int(r.get("index",-1))>=0 and r.get("state")=="已退出"}
            indices=sorted({int(i) for i in self.failed_indices if int(i)>=0} | exited_indices)
            label="未进行全部账号"
        if not indices:
            QMessageBox.information(self,"无法重跑",f"当前没有可重跑的{label}。",parent=self); return
        self.retry_requested.emit(indices,label)
        self.accept()

    def _update_rerun_button(self):
        if not hasattr(self,'rerun_btn'):return
        mode=self.rerun_filter.currentText()
        if mode=="重跑失败账号":
            ok=bool(self.failed_indices)
        elif mode=="重跑已退出账号":
            ok=any(r.get("state")=="已退出" and int(r.get("index",-1))>=0 for r in self.rows)
        else:
            exited_indices={int(r.get("index",-1)) for r in self.rows if int(r.get("index",-1))>=0 and r.get("state")=="已退出"}
            ok=bool({int(i) for i in self.failed_indices if int(i)>=0} | exited_indices)
        self.rerun_btn.setEnabled(ok)

    def _show_context_menu(self,pos):
        row=self.table.indexAt(pos).row()
        if row<0:return
        self.table.selectRow(row)
        idx=self._selected_index()
        if idx is None or idx<0:return
        account=self.table.item(row,1).text() if self.table.item(row,1) else "该账号"
        current_state=self.table.item(row,4).text() if self.table.item(row,4) else ""
        menu=QMenu(self)
        rerun=menu.addAction(f"重跑账号：{account}")
        rerun.setEnabled(current_state != "主动排除")
        # “主动排除 / 恢复主动排除”是互斥的同一个右键功能：
        # 普通状态时执行排除，已经排除时则直接恢复，避免菜单同时出现两个相反操作。
        toggle_exclude=menu.addAction("恢复主动排除" if current_state == "主动排除" else "主动排除")
        locate=menu.addAction("定位账号")
        rerun.triggered.connect(lambda: self._rerun_single(idx,account))
        if current_state == "主动排除":
            toggle_exclude.triggered.connect(lambda: self._restore_single(idx,account))
        else:
            toggle_exclude.triggered.connect(lambda: self._exclude_single(idx,account))
        locate.triggered.connect(lambda: self.locate_requested.emit(int(idx)))
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def _rerun_single(self,index,account):
        self.retry_requested.emit([int(index)],f"账号 {account}")
        self.close()

    def _exclude_single(self,index,account):
        self.exclude_requested.emit(int(index), str(account))
        for data in self.rows:
            try: same=int(data.get("index",-1)) == int(index)
            except Exception: same=False
            if same:
                data["state"]="主动排除"
                data["result"]="登录成功"
                data["reason"]="用户主动排除"
                break
        self._refresh_table()

    def _restore_single(self,index,account):
        self.restore_requested.emit(int(index), str(account))
        for data in self.rows:
            try: same=int(data.get("index",-1)) == int(index)
            except Exception: same=False
            if same:
                data["state"] = str(data.get("previous_state") or "运行中")
                data["result"] = str(data.get("previous_result") or "运行中")
                data["reason"] = str(data.get("previous_reason") or "—")
                break
        self._refresh_table()


class Signals(QObject):
    log = Signal(str)
    input_lock_state = Signal(bool)
    row = Signal(int, str)
    progress = Signal(int, int)
    finished = Signal()
    csv_daily = Signal(str, str)




class HandleViewerDialog(QDialog):
    """句柄查看器 4.0：融合外部抓取器的真实 Win32 树遍历与本工具的工作流定位。"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("句柄查看器 · 4.0")
        self.resize(1450, 900)
        self.setMinimumSize(1050, 680)
        self.ctrl = Win32Controller()
        self.root_hwnd = 0
        self._top_window_rows = []
        self._build_ui()
        self.refresh_windows()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 10)
        root.setSpacing(8)

        title = QLabel("句柄查看器")
        title.setStyleSheet("font-size:20px;font-weight:700;")
        sub = QLabel("识别算法与外部抓取器保持一致：EnumWindows + GetWindow(GW_CHILD/GW_HWNDNEXT)；同时保留 Desktop 全树检索。")
        sub.setStyleSheet("color:#6b7280;")
        root.addWidget(title); root.addWidget(sub)

        # 顶层窗口检索区
        topbox = QGroupBox("① 顶层窗口")
        tl = QGridLayout(topbox)
        tl.setContentsMargins(10, 8, 10, 8)
        self.window_search = QLineEdit()
        self.window_search.setPlaceholderText("搜索标题 / ClassName / HWND / PID；也可直接输入 0x句柄")
        self.window_search_field = QComboBox()
        self.window_search_field.addItems(["全部", "标题", "ClassName", "HWND", "PID"])
        self.window_search_btn = QPushButton("检索")
        self.window_search_clear_btn = QPushButton("清空")
        self.refresh_btn = QPushButton("刷新")
        self.window_combo = QComboBox()
        self.inspect_btn = QPushButton("查看窗口树")
        self.desktop_btn = QPushButton("查看 Desktop 全树")
        self.window_search.returnPressed.connect(self.filter_top_windows)
        self.window_search_btn.clicked.connect(self.filter_top_windows)
        self.window_search_clear_btn.clicked.connect(self.clear_top_window_search)
        self.refresh_btn.clicked.connect(self.refresh_windows)
        self.inspect_btn.clicked.connect(self.inspect_selected)
        self.desktop_btn.clicked.connect(self.inspect_desktop)
        tl.addWidget(QLabel("搜索："), 0, 0); tl.addWidget(self.window_search, 0, 1, 1, 4)
        tl.addWidget(self.window_search_field, 0, 5); tl.addWidget(self.window_search_btn, 0, 6)
        tl.addWidget(self.window_search_clear_btn, 0, 7); tl.addWidget(self.refresh_btn, 0, 8)
        tl.addWidget(QLabel("当前窗口："), 1, 0); tl.addWidget(self.window_combo, 1, 1, 1, 6)
        tl.addWidget(self.inspect_btn, 1, 7); tl.addWidget(self.desktop_btn, 1, 8)
        root.addWidget(topbox)

        # 全局控件检索区
        searchbox = QGroupBox("② 全局控件检索")
        sl = QHBoxLayout(searchbox); sl.setContentsMargins(10, 8, 10, 8)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("例如：608854 / 0x608854 / Edit / Edit[4] / WTWindow / 774986620")
        self.search_field = QComboBox()
        self.search_field.addItems(["全部", "窗口标题", "类名", "HWND", "PID", "选择器", "控件文本"])
        self.search_text_check = QCheckBox("读取控件文本")
        self.search_desktop_check = QCheckBox("加入 Desktop 全树")
        self.search_desktop_check.setChecked(True)
        self.search_btn = QPushButton("开始检索")
        self.search_clear_btn = QPushButton("清除结果")
        self.search_count = QLabel("未检索")
        self.search_edit.returnPressed.connect(self.search_controls)
        self.search_btn.clicked.connect(self.search_controls)
        self.search_clear_btn.clicked.connect(self.clear_search)
        for w in (self.search_edit, self.search_field, self.search_text_check,
                  self.search_desktop_check, self.search_btn, self.search_clear_btn, self.search_count):
            sl.addWidget(w, 1 if w is self.search_edit else 0)
        root.addWidget(searchbox)

        self.splitter = QSplitter(Qt.Vertical)
        root.addWidget(self.splitter, 1)

        # 上半：检索结果
        search_panel = QWidget(); sp = QVBoxLayout(search_panel); sp.setContentsMargins(0,0,0,0)
        sp.addWidget(QLabel("检索结果（双击直接定位）"))
        self.search_results = QTreeWidget()
        self.search_results.setColumnCount(8)
        self.search_results.setHeaderLabels(["对象", "HWND", "ClassName", "选择器", "标题", "PID", "顶层窗口", "文本"])
        self.search_results.setAlternatingRowColors(True)
        self.search_results.setSortingEnabled(True)
        self.search_results.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.search_results.itemDoubleClicked.connect(self.open_search_result)
        self.search_results.itemClicked.connect(self.on_search_result_clicked)
        sp.addWidget(self.search_results)
        self.splitter.addWidget(search_panel)

        # 下半：树 + 详情
        bottom = QSplitter(Qt.Horizontal)
        tree_panel = QWidget(); tp = QVBoxLayout(tree_panel); tp.setContentsMargins(0,0,0,0)
        tree_tools = QHBoxLayout()
        self.tree_filter = QLineEdit(); self.tree_filter.setPlaceholderText("树内快速过滤：ClassName / HWND / 标题 / Edit[4]")
        self.tree_filter.textChanged.connect(self.filter_tree_view)
        self.tree_copy_btn = QPushButton("复制当前定位")
        self.tree_read_btn = QPushButton("读取文本/诊断")
        self.test_text = QLineEdit(); self.test_text.setPlaceholderText("给选中控件发送测试文字")
        self.test_btn = QPushButton("发送")
        self.tree_copy_btn.clicked.connect(self.copy_selected)
        self.tree_read_btn.clicked.connect(self.read_selected_text)
        self.test_btn.clicked.connect(self.send_test_text)
        for w in (self.tree_filter, self.tree_copy_btn, self.tree_read_btn, self.test_text, self.test_btn):
            tree_tools.addWidget(w, 1 if w is self.tree_filter or w is self.test_text else 0)
        tp.addLayout(tree_tools)
        self.tree = QTreeWidget()
        self.tree.setColumnCount(9)
        self.tree.setHeaderLabels(["层级 / 控件", "HWND", "ClassName", "序号选择器", "标题", "文本预览", "可见", "启用", "父HWND"])
        self.tree.setAlternatingRowColors(True)
        self.tree.setSortingEnabled(True)
        self.tree.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tree.setStyleSheet("QTreeWidget::item:selected{background:#fef08a;color:#111827;}")
        self.tree.itemClicked.connect(self.on_item_clicked)
        self.tree.itemDoubleClicked.connect(self.copy_selected)
        tp.addWidget(self.tree, 1)
        bottom.addWidget(tree_panel)

        detail = QGroupBox("当前节点")
        dl = QVBoxLayout(detail)
        self.info = QTextEdit(); self.info.setReadOnly(True)
        self.info.setPlaceholderText("选择窗口或控件后，这里显示完整定位信息。")
        dl.addWidget(self.info)
        bottom.addWidget(detail)
        bottom.setStretchFactor(0, 4); bottom.setStretchFactor(1, 2)
        self.splitter.addWidget(bottom)
        self.splitter.setStretchFactor(0, 1); self.splitter.setStretchFactor(1, 4)

        self.status = QLabel("就绪")
        self.status.setStyleSheet("color:#6b7280;padding:3px 2px;")
        root.addWidget(self.status)

    def _enumerate_top_windows(self):
        import win32gui, win32process
        rows=[]
        for hwnd in self.ctrl.find_windows():
            try:
                rows.append({'hwnd':int(hwnd),'title':win32gui.GetWindowText(hwnd) or '',
                             'class_name':win32gui.GetClassName(hwnd) or '',
                             'pid':int(win32process.GetWindowThreadProcessId(hwnd)[1])})
            except Exception: pass
        return rows

    def refresh_windows(self):
        self._top_window_rows=self._enumerate_top_windows(); self.filter_top_windows()

    def filter_top_windows(self):
        rows=list(self._top_window_rows)
        kw=self.window_search.text().strip().lower(); field=self.window_search_field.currentText()
        old=self.window_combo.currentData()
        self.window_combo.blockSignals(True); self.window_combo.clear()
        desktop=self.ctrl.desktop_hwnd()
        if (not kw) or field in ("全部","ClassName") and kw in ("desktop","#32769") or field=="HWND" and kw in (str(desktop),hex(desktop).lower()):
            self.window_combo.addItem(f"Desktop | #32769 | HWND={desktop}", desktop)
        for r in rows:
            vals={'全部':[r['title'],r['class_name'],r['hwnd'],r['pid']], '标题':[r['title']],
                  'ClassName':[r['class_name']], 'HWND':[r['hwnd']], 'PID':[r['pid']]}[field]
            if kw and not any(kw in str(v).lower() for v in vals): continue
            self.window_combo.addItem(f"{r['title'] or '(无标题)'} | {r['class_name']} | HWND={r['hwnd']} | PID={r['pid']}",r['hwnd'])
        self.window_combo.blockSignals(False)
        if old is not None:
            i=self.window_combo.findData(old)
            if i>=0:self.window_combo.setCurrentIndex(i)
        if self.window_combo.count() and self.window_combo.currentIndex()<0:self.window_combo.setCurrentIndex(0)
        self.status.setText(f"顶层窗口：{self.window_combo.count()} 个匹配")

    def clear_top_window_search(self): self.window_search.clear(); self.refresh_windows()
    def inspect_desktop(self):
        self.window_combo.setCurrentIndex(self.window_combo.findData(self.ctrl.desktop_hwnd())); self.inspect_selected()

    def inspect_selected(self):
        if self.window_combo.currentIndex()<0:return
        self.root_hwnd=int(self.window_combo.currentData()); self.populate_tree(self.root_hwnd)
        self.status.setText(f"正在查看 HWND={self.root_hwnd} 的完整控件树")

    def populate_tree(self, root_hwnd):
        import win32gui
        self.tree.setSortingEnabled(False); self.tree.clear(); self.root_hwnd=int(root_hwnd)
        root_item=QTreeWidgetItem(self.tree)
        cls=win32gui.GetClassName(root_hwnd); title=win32gui.GetWindowText(root_hwnd) or ''
        root_text = self.ctrl._grabber_get_text(root_hwnd, 300) or ""
        vals=["根节点",str(root_hwnd),cls,cls,title,root_text[:500],"是" if win32gui.IsWindowVisible(root_hwnd) else "否","是" if win32gui.IsWindowEnabled(root_hwnd) else "否","-"]
        for i,v in enumerate(vals):root_item.setText(i,v)
        root_item.setData(0,Qt.UserRole,{'hwnd':root_hwnd,'parent':0,'selector':cls,'title':title,'class_name':cls,'occurrence':1,'root_hwnd':root_hwnd,'text':root_text})
        self._add_children(root_item,root_hwnd,0)
        root_item.setExpanded(True)
        self.tree.setSortingEnabled(True)
        self.tree.sortItems(0,Qt.AscendingOrder)
        for i in range(9):self.tree.resizeColumnToContents(i)
        self.status.setText("控件树加载完成；树排序只改变显示，不改变真实选择器")

    def _add_children(self,parent_item,parent_hwnd,depth):
        import win32gui
        if depth>=30:return
        counters={}
        for hwnd in self.ctrl.iter_direct_children(parent_hwnd):
            try: cls=win32gui.GetClassName(hwnd); title=win32gui.GetWindowText(hwnd) or ''
            except Exception: continue
            counters[cls]=counters.get(cls,0)+1; n=counters[cls]
            item=QTreeWidgetItem(parent_item)
            text = self.ctrl._grabber_get_text(hwnd, 300) or ""
            vals=[f"{cls} [{n}]",str(hwnd),cls,f"{cls}[{n}]",title,text[:500],
                  "是" if win32gui.IsWindowVisible(hwnd) else "否","是" if win32gui.IsWindowEnabled(hwnd) else "否",str(parent_hwnd)]
            for i,v in enumerate(vals):item.setText(i,v)
            item.setData(0,Qt.UserRole,{'hwnd':int(hwnd),'parent':int(parent_hwnd),'selector':f'{cls}[{n}]','title':title,'class_name':cls,'occurrence':n,'root_hwnd':self.root_hwnd,'text':text})
            self._add_children(item,hwnd,depth+1)

    def selected_data(self):
        item=self.tree.currentItem(); return item.data(0,Qt.UserRole) if item else None

    def on_item_clicked(self,item,column):
        d=item.data(0,Qt.UserRole)
        if not d:return
        self.info.setPlainText(self._format_data(d)); self.status.setText(f"已选中 HWND={d['hwnd']} | {d.get('selector','')}")

    def _format_data(self,d):
        return (f"HWND       : {d.get('hwnd')}\nParent     : {d.get('parent')}\n"
                f"ClassName  : {d.get('class_name','')}\nSelector   : {d.get('selector','')}\n"
                f"Title      : {d.get('title','')}\nPID        : {d.get('pid','')}\n"
                f"Root HWND  : {d.get('root_hwnd','')}\nDepth      : {d.get('depth','')}")

    def filter_tree_view(self,kw):
        kw=kw.strip().lower()
        def rec(parent):
            for i in range(parent.childCount()):
                item=parent.child(i); d=item.data(0,Qt.UserRole) or {}
                vals=' '.join(str(d.get(k,'')) for k in ('hwnd','class_name','selector','title','parent')).lower()
                child_hit=rec(item)
                item.setHidden(bool(kw) and kw not in vals and not child_hit)
                if child_hit and kw: item.setExpanded(True)
            return any(not parent.child(i).isHidden() for i in range(parent.childCount()))
        rec(self.tree.invisibleRootItem())

    def search_controls(self):
        kw=self.search_edit.text().strip()
        if not kw:self.search_count.setText("请输入检索内容");return
        self.search_results.setSortingEnabled(False); self.search_results.clear(); self.status.setText("正在按外部抓取器规则检索……"); QApplication.processEvents()
        try:
            rows=self.ctrl.search_controls(kw,self.search_field.currentText(),self.search_text_check.isChecked(),self.search_desktop_check.isChecked(),max_controls=50000)
        except Exception as e:
            self.search_count.setText("检索失败");self.status.setText(str(e));return
        for d in rows:
            item=QTreeWidgetItem(self.search_results)
            vals=["根窗口" if d.get('is_root') else "控件",str(d.get('hwnd','')),d.get('class_name',''),d.get('selector',''),d.get('title',''),str(d.get('pid','')),d.get('root_title',''),(d.get('text','') or '')[:500]]
            for i,v in enumerate(vals):item.setText(i,str(v))
            item.setData(0,Qt.UserRole,d)
        self.search_results.setSortingEnabled(True); self.search_results.sortItems(0,Qt.AscendingOrder)
        self.search_count.setText(f"找到 {len(rows)} 个匹配项"); self.status.setText(f"检索完成：{len(rows)} 个结果")
        for i in range(8):self.search_results.resizeColumnToContents(i)

    def clear_search(self):self.search_edit.clear();self.search_results.clear();self.search_count.setText("未检索")
    def on_search_result_clicked(self,item,column):
        d=item.data(0,Qt.UserRole)
        if d:self.info.setPlainText(self._format_data(d))

    def open_search_result(self,item,column=0):
        d=item.data(0,Qt.UserRole)
        if not d:return
        root=int(d.get('root_hwnd') or d.get('hwnd'))
        idx=self.window_combo.findData(root)
        if idx<0:
            self.window_search.clear();self.refresh_windows();idx=self.window_combo.findData(root)
        if idx>=0:self.window_combo.setCurrentIndex(idx)
        self.root_hwnd=root;self.populate_tree(root)
        target=int(d.get('hwnd')); found=self._find_tree_item_by_hwnd(self.tree.invisibleRootItem(),target)
        if found:
            p=found.parent()
            while p:p.setExpanded(True);p=p.parent()
            self.tree.setCurrentItem(found);self.tree.scrollToItem(found);self.on_item_clicked(found,0)
        else:
            self.status.setText(f"检索命中 HWND={target}，但当前树未展开到该节点；可直接复制 HWND。")

    def _find_tree_item_by_hwnd(self,parent_item,hwnd):
        for i in range(parent_item.childCount()):
            item=parent_item.child(i);d=item.data(0,Qt.UserRole)
            if d and int(d.get('hwnd',-1))==int(hwnd):return item
            f=self._find_tree_item_by_hwnd(item,hwnd)
            if f:return f
        return None

    def read_selected_text(self):
        d=self.selected_data()
        if not d:self.status.setText("请先选中控件");return
        try:
            info=self.ctrl.get_text_details(int(d['hwnd']),timeout_ms=1200);text=str(info.get('text') or '')
            lines=[f"HWND : {info.get('hwnd')}",f"ClassName : {info.get('class_name')}",f"Parent : {info.get('parent')}",f"Parent ClassName : {info.get('parent_class')}",f"PID : {info.get('process_id')}",f"Control ID : {info.get('control_id')}",f"WM_GETTEXTLength : {info.get('length',0)}",f"WM_GETTEXT返回 : {info.get('wm_gettext_return','')}",f"读取方式 : {info.get('method','')}",f"字符数 : {len(text)}","","========== 完整文本 ==========",text or '(空)']
            dlg=QDialog(self);dlg.setWindowTitle(f"文本读取诊断 · HWND={d['hwnd']}");dlg.resize(900,620);lay=QVBoxLayout(dlg);ed=QTextEdit();ed.setReadOnly(True);ed.setPlainText('\n'.join(lines));lay.addWidget(ed);bb=QDialogButtonBox(QDialogButtonBox.Close);cp=bb.addButton('复制完整结果',QDialogButtonBox.ActionRole);cp.clicked.connect(lambda: QApplication.clipboard().setText('\n'.join(lines)));bb.rejected.connect(dlg.reject);lay.addWidget(bb);dlg.exec()
            self.status.setText(f"读取完成：HWND={d['hwnd']}，字符数={len(text)}")
        except Exception as e:self.status.setText(f"读取失败：{e}")

    def send_test_text(self):
        d=self.selected_data()
        if not d:self.status.setText("请先选中控件");return
        try:self.ctrl.set_text(int(d['hwnd']),self.test_text.text());self.status.setText(f"已向 HWND={d['hwnd']} 发送测试文本")
        except Exception as e:self.status.setText(f"发送失败：{e}")

    def copy_selected(self,*args):
        d=self.selected_data()
        if not d:return
        text=f"HWND={d.get('hwnd')} | Parent={d.get('parent')} | ClassName={d.get('class_name')} | Selector={d.get('selector')} | Title={d.get('title','')}"
        QApplication.clipboard().setText(text);self.status.setText("已复制定位信息")


class AccountEditDialog(QDialog):
    """CSV 账号编辑/新增对话框：紧凑、分组清晰，日期操作集中在到期时间区域。"""
    def __init__(self, parent=None, row=None):
        super().__init__(parent)
        self.setWindowTitle("编辑账号" if row else "添加账号")
        self.setMinimumSize(600, 470)
        self.resize(640, 600)
        self.row_data = dict(row or {})

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 18, 20, 18)
        root.setSpacing(12)

        # 仅适度放大编辑窗口文字，不改变原版布局、间距和功能。
        self.setStyleSheet("""
            QDialog { font-size: 14px; }
            QLabel, QLineEdit, QComboBox, QCheckBox, QPushButton, QGroupBox { font-size: 14px; }
        """)

        title = QLabel("编辑账号信息" if row else "添加账号")
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        root.addWidget(title)

        subtitle = QLabel("点击保存后立即写入当前 CSV 文件；添加和编辑账号均会直接保存。")
        subtitle.setStyleSheet("color: #6b7280;")
        root.addWidget(subtitle)

        basic = QGroupBox("账号信息")
        form = QFormLayout(basic)
        form.setContentsMargins(14, 14, 14, 14)
        form.setHorizontalSpacing(18)
        form.setVerticalSpacing(16)

        self.account_edit = QLineEdit(self.row_data.get("account", ""))
        self.account_edit.setPlaceholderText("请输入账号")
        self.password_edit = QLineEdit(self.row_data.get("password", ""))
        self.password_edit.setPlaceholderText("请输入密码")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.show_password = QCheckBox("显示")
        self.show_password.toggled.connect(
            lambda checked: self.password_edit.setEchoMode(
                QLineEdit.Normal if checked else QLineEdit.Password
            )
        )
        pw_row = QHBoxLayout()
        pw_row.setContentsMargins(0, 0, 0, 0)
        pw_row.addWidget(self.password_edit, 1)
        pw_row.addWidget(self.show_password)

        self.create_edit = QLineEdit(self.row_data.get("create_time", ""))
        self.create_edit.setPlaceholderText("例如 2026-10-05 12:00:00")
        self.remark_edit = QLineEdit(self.row_data.get("remark", ""))
        self.remark_edit.setPlaceholderText("可选备注")

        # 账号状态可在编辑账号信息时直接修改；支持预设状态，也允许输入自定义状态。
        status_options = ["未运行", "登录成功", "登录失败", "密码错误", "封禁", "跳过", "已过期"]
        current_status = str(self.row_data.get("status", "未运行") or "未运行").strip()
        if current_status not in status_options:
            status_options.append(current_status)
        self.status_edit = QComboBox()
        self.status_edit.setEditable(True)
        self.status_edit.addItems(status_options)
        self.status_edit.setCurrentText(current_status)
        self.status_edit.setToolTip("可直接修改账号状态；自定义状态也可以直接输入。")

        form.addRow("账号：", self.account_edit)
        form.addRow("密码：", pw_row)
        form.addRow("状态：", self.status_edit)
        form.addRow("创建时间：", self.create_edit)
        form.addRow("备注：", self.remark_edit)
        # 仅增加“账号信息”分组框的整体高度；内部字段、字体、间距和顺序保持不变。
        basic.setMinimumHeight(242)
        root.addWidget(basic)

        date_box = QGroupBox("到期时间")
        date_layout = QVBoxLayout(date_box)
        date_layout.setContentsMargins(14, 14, 14, 14)
        date_layout.setSpacing(8)

        self.expire_edit = QLineEdit(self.row_data.get("expire_time", ""))
        self.expire_edit.setPlaceholderText("例如 2026-11-04 12:00:00；留空表示无到期时间")
        expire_row = QHBoxLayout()
        expire_row.setContentsMargins(0, 0, 0, 0)
        expire_row.addWidget(self.expire_edit, 1)
        clear_btn = QPushButton("清除")
        clear_btn.setToolTip("清空到期时间，方便重新设置")
        clear_btn.clicked.connect(self.clear_expire)
        expire_row.addWidget(clear_btn)
        date_layout.addLayout(expire_row)

        quick_label = QLabel("快速调整：")
        quick_label.setStyleSheet("color: #6b7280;")
        quick_row = QHBoxLayout()
        quick_row.setContentsMargins(0, 0, 0, 0)
        quick_row.addWidget(quick_label)
        for text, days in (("+7 天", 7), ("+30 天", 30), ("从今天 +7 天", 7), ("从今天 +30 天", 30)):
            btn = QPushButton(text)
            if text.startswith("从今天"):
                btn.clicked.connect(lambda checked=False, d=days: self.set_expire_from_today(d))
            else:
                btn.clicked.connect(lambda checked=False, d=days: self.add_expire_days(d))
            quick_row.addWidget(btn)
        quick_row.addStretch(1)
        date_layout.addLayout(quick_row)
        root.addWidget(date_box)

        self.update_edit = QLineEdit(self.row_data.get("update_time", ""))
        self.update_edit.setReadOnly(True)
        self.update_edit.setPlaceholderText("保存编辑时自动更新")
        update_row = QHBoxLayout()
        update_row.setContentsMargins(0, 0, 0, 0)
        update_row.addWidget(QLabel("更新时间："))
        update_row.addWidget(self.update_edit, 1)
        root.addLayout(update_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("保存")
        buttons.button(QDialogButtonBox.Cancel).setText("取消")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def clear_expire(self):
        self.expire_edit.clear()
        self.expire_edit.setFocus()

    def _parse_expire(self, text):
        formats = [
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
            "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d"
        ]
        for fmt in formats:
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                pass
        return None

    def add_expire_days(self, days):
        base = self._parse_expire(self.expire_edit.text().strip()) or datetime.now()
        target = base + timedelta(days=days)
        self.expire_edit.setText(target.strftime("%Y-%m-%d %H:%M:%S"))

    def set_expire_from_today(self, days):
        target = datetime.now() + timedelta(days=days)
        self.expire_edit.setText(target.strftime("%Y-%m-%d %H:%M:%S"))

    def get_row(self):
        return {
            "account": self.account_edit.text().strip(),
            "password": self.password_edit.text(),
            "status": self.status_edit.currentText().strip() or "未运行",
            "create_time": self.create_edit.text().strip(),
            "expire_time": self.expire_edit.text().strip(),
            "update_time": self.update_edit.text().strip(),
            "remark": self.remark_edit.text().strip(),
        }


class ExpiryColorDelegate(QStyledItemDelegate):
    """过期账号整格浅红高亮；选中过期账号整格浅红黄混合高亮。文字始终保持原来的黑色。"""
    EXPIRED_BG = QColor("#f3c1c1")
    EXPIRED_SELECTED_BG = QColor("#e9cf9f")

    def paint(self, painter, option, index):
        expired = bool(index.data(Qt.UserRole + 1))
        if not expired:
            super().paint(painter, option, index)
            return

        opt = QStyleOptionViewItem(option)
        selected = bool(opt.state & QStyle.StateFlag.State_Selected)
        bg = self.EXPIRED_SELECTED_BG if selected else self.EXPIRED_BG

        # 先把当前单元格整个区域铺满浅色。这样不是“文字变色”，而是整格/整行背景高亮。
        painter.save()
        painter.fillRect(opt.rect, bg)
        painter.restore()

        # 交给 Qt 正常绘制文字、图标、焦点等，但关闭系统默认选中背景，
        # 并强制文字使用原来的黑色。每一列都会经过此 delegate，因此整行都会高亮。
        opt.state &= ~QStyle.StateFlag.State_Selected
        opt.backgroundBrush = QBrush(bg)
        opt.palette.setColor(QPalette.ColorRole.Base, bg)
        opt.palette.setColor(QPalette.ColorRole.AlternateBase, bg)
        opt.palette.setColor(QPalette.ColorRole.Text, QColor("#111827"))
        opt.palette.setColor(QPalette.ColorRole.WindowText, QColor("#111827"))
        super().paint(painter, opt, index)


class AccountVerificationDialog(QDialog):
    """本地账号验证入口；后续可将 verify_account 替换为网络授权接口。"""
    VERIFY_ACCOUNT = "2583100599"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("账号验证")
        self.setModal(True)
        self.setFixedSize(430, 220)
        self.verified_account = ""

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(12)

        title = QLabel("软件账号验证")
        title.setStyleSheet("font-size:18px;font-weight:600;")
        root.addWidget(title)

        hint = QLabel("请输入已授权账号。未验证通过前不能使用本软件。")
        hint.setStyleSheet("color:#6b7280;")
        root.addWidget(hint)

        row = QHBoxLayout()
        row.addWidget(QLabel("账号："))
        self.account_edit = QLineEdit()
        self.account_edit.setPlaceholderText("请输入授权账号")
        self.account_edit.setClearButtonEnabled(True)
        self.account_edit.returnPressed.connect(self.verify)
        row.addWidget(self.account_edit, 1)
        root.addLayout(row)

        self.status_label = QLabel("状态：未验证")
        self.status_label.setStyleSheet("color:#b45309;")
        root.addWidget(self.status_label)

        self.remember_account = QCheckBox("记住授权账号")
        self.remember_account.setChecked(True)
        root.addWidget(self.remember_account)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.verify_btn = QPushButton("验证")
        self.verify_btn.setFixedWidth(90)
        self.verify_btn.clicked.connect(self.verify)
        buttons.addWidget(self.verify_btn)
        cancel = QPushButton("退出软件")
        cancel.setFixedWidth(90)
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        root.addLayout(buttons)

        remembered = ""
        try:
            remembered = str(parent.memory.settings.get("authorized_account", "")) if parent is not None and hasattr(parent, "memory") else ""
        except Exception:
            remembered = ""
        if remembered:
            self.account_edit.setText(remembered)

        self.account_edit.setFocus()

    def verify_account(self, account):
        """验证接口预留：未来可在此替换为网络验证/设备锁定/授权期检查。"""
        return str(account).strip() == self.VERIFY_ACCOUNT

    def verify(self):
        account = self.account_edit.text().strip()
        if self.verify_account(account):
            self.verified_account = account
            try:
                if self.remember_account.isChecked() and self.parent() is not None and hasattr(self.parent(), "memory"):
                    self.parent().memory.save_settings(authorized_account=account)
                elif self.parent() is not None and hasattr(self.parent(), "memory"):
                    self.parent().memory.save_settings(authorized_account="")
            except Exception:
                pass
            self.status_label.setText("状态：验证成功")
            self.status_label.setStyleSheet("color:#15803d;font-weight:600;")
            self.accept()
            return
        self.status_label.setText("状态：验证失败，账号无效")
        self.status_label.setStyleSheet("color:#dc2626;font-weight:600;")
        QMessageBox.warning(self, "验证失败", "当前账号未获得授权，无法使用本软件。")
        self.account_edit.selectAll()
        self.account_edit.setFocus()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        icon_path = Path(__file__).resolve().with_name("app_icon.ico")
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        self.setWindowTitle(f"句柄上号器 · 自动化工作流平台 {APP_VERSION}（v22）")
        self.resize(1050, 850)

        self.accounts = []
        self._secret_redactor = SecretRedactor()
        self.current_workflow_path = None
        self.editor = None
        self.stop_requested = False
        self.running = False
        self._restoring_memory = False
        self._last_run_exe = ""
        self._last_run_csv = ""
        self.profile_store = SoftwareProfileStore(Path(__file__).parent)
        self._active_profile_name = None
        QApplication.instance().installEventFilter(self)
        self.schedule_timer = QTimer(self)
        self.schedule_timer.timeout.connect(self.check_schedule)
        self.schedule_fired = False
        self._scheduled_target = None
        self.parallel_threads = []
        self._failed_indices = set()
        self._status_tracker = StatusTracker()
        self._run_processes = {}  # 当前运行批次的 PID -> 账号信息
        self._process_history = []  # 每个账号只保留最新记录；重跑仅累计次数
        self._killed_processes = []  # 本程序主动结束的进程
        self._run_stats = {"success": 0, "failed": 0, "skipped": 0, "stopped": 0}
        self._run_stats_generation = 0
        self._engine_current_row = -1
        self._run_locked_exe = ""
        self._run_locked_csv = ""
        self._run_locked_workflow_index = -1
        self._stats_lock = threading.Lock()
        self._history_lock = threading.Lock()
        self.verified = False
        self.verified_account = ""

        self.engine = WorkflowEngine()
        self._run_history = []
        self.signals = Signals()
        self.signals.log.connect(self.write_log)
        self.signals.row.connect(self.update_row)
        self.signals.progress.connect(self.update_progress)
        self.signals.finished.connect(self.finished)
        self.signals.csv_daily.connect(self.on_csv_daily_signal)
        self.input_lock = InputLock(
            logger=lambda msg: self.signals.log.emit(str(msg)),
            state_callback=lambda locked: self.signals.input_lock_state.emit(bool(locked)),
        )

        # 简化日志模式下用于避免同一账号重复显示。
        self._simple_logged_accounts = set()
        self._log_records = []
        self._last_failure_capture = 0.0
        self._log_file_lock = threading.Lock()
        # 日志路径与文件句柄按日缓存，避免每条日志都 resolve/mkdir/open/close。
        self._log_base_dir = Path(__file__).parent
        self._log_dir = self._log_base_dir / "logs"
        self._log_file_date = None
        self._log_file_handle = None
        self._pending_log_lines = deque()
        self._pending_log_dropped = 0
        self._pending_log_limit = 10000
        self._log_persist_error = None

        base_dir = Path(__file__).parent
        self.store = WorkflowStore(base_dir / "workflows")
        self.memory = MemoryStore(base_dir)
        self.csv_project_store = CSVProjectStore(base_dir)
        self._csv_daily_lock = threading.Lock()
        self._csv_daily_results = self._load_csv_daily_results()
        self._advanced_schedule = {}
        self._auto_process_retry_round = 0
        try:
            ap=base_dir / "config" / "advanced_schedule.json"
            if ap.exists(): self._advanced_schedule=json.loads(ap.read_text(encoding="utf-8"))
        except Exception: pass

        self.build()
        self.refresh_profile_combo()

        # 启动即验证：验证失败/取消直接退出，不允许进入正常使用状态。
        if not self.verify_startup_account():
            QTimer.singleShot(0, self.close)
            return

        self.restore_memory()
        for recovery_warning in getattr(self.memory, "recovery_warnings", []):
            self.write_log_force("配置恢复提醒：" + str(recovery_warning))
        if getattr(self.csv_project_store, "load_warning", ""):
            self.write_log_force("配置恢复提醒：" + str(self.csv_project_store.load_warning))
        for recovery_warning in getattr(self.store, "recovery_warnings", []):
            self.write_log_force("配置恢复提醒：" + str(recovery_warning))
        # 每日 00:00 状态重置：启动时先补做一次，随后由 1 秒定时器负责跨日检测。
        self._check_daily_csv_status_reset()
        self.schedule_timer.start(1000)

    def verify_startup_account(self):
        remembered = str(self.memory.settings.get("authorized_account", "")).strip()
        if remembered and AccountVerificationDialog(self).verify_account(remembered):
            self.verified = True
            self.verified_account = remembered
            if hasattr(self, "validation_status_label"):
                self.validation_status_label.setText(f"已验证：{self.verified_account}（已记忆）")
                self.validation_status_label.setStyleSheet("color:#15803d;font-weight:600;")
            return True
        dlg = AccountVerificationDialog(self)
        result = dlg.exec()
        if result == QDialog.Accepted:
            self.verified = True
            self.verified_account = dlg.verified_account
            if hasattr(self, "validation_status_label"):
                self.validation_status_label.setText(f"已验证：{self.verified_account}")
                self.validation_status_label.setStyleSheet("color:#15803d;font-weight:600;")
            return True
        return False

    def require_verified(self):
        if self.verified:
            return True
        QMessageBox.warning(self, "需要验证", "请先完成账号验证。")
        return False

    # =========================
    # 界面
    # =========================

    def build(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        tabs = QTabWidget()
        tabs.addTab(self.build_run_tab(), "运行中心")
        tabs.addTab(self.build_software_tab(), "软件启动工作台")
        tabs.addTab(self.build_workflow_tab(), "工作流工作台")
        tabs.addTab(self.build_csv_tab(), "CSV账号管理")
        tabs.addTab(self.build_advanced_tab(), "3.0高级中心")
        layout.addWidget(tabs)
        self.tabs = tabs
        self.tabs.currentChanged.connect(self.on_tab_changed)

    def build_run_tab(self):
        w = QWidget()
        l = QVBoxLayout(w)
        grid = QGridLayout()
        for _c in range(4, 8):
            grid.setColumnStretch(_c, 1)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(5)

        # 仅将“启动项目”至“并发账号数”这五行包进“运行设置”框。
        # 内部控件的行列、尺寸和间距保持原样，不改变其它运行中心布局。
        settings_box = QGroupBox("运行设置")
        settings_layout = QVBoxLayout(settings_box)
        settings_layout.setContentsMargins(8, 8, 8, 8)
        settings_layout.setSpacing(0)
        settings_grid = QGridLayout()
        settings_grid.setHorizontalSpacing(6)
        settings_grid.setVerticalSpacing(5)
        settings_layout.addLayout(settings_grid)

        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(350)
        self.profile_combo.setMaximumWidth(380)
        self.profile_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.profile_combo.setStyleSheet("QComboBox { text-align: left; }")
        self.profile_combo.currentIndexChanged.connect(self.on_profile_changed)
        manage_profiles = QPushButton("管理启动项目")
        manage_profiles.clicked.connect(lambda: self.tabs.setCurrentIndex(1))
        settings_grid.addWidget(QLabel("启动项目："), 0, 0)
        settings_grid.addWidget(self.profile_combo, 0, 1)
        settings_grid.addWidget(manage_profiles, 0, 2)

        # EXE/CSV 仍保留为内部状态，但不再在运行中心单独展示。
        self.exe = QLineEdit(); self.exe.setReadOnly(True); self.exe.hide()
        self.csv = QLineEdit(); self.csv.setReadOnly(True); self.csv.hide()

        self.workflow_combo = QComboBox()
        self.workflow_combo.currentIndexChanged.connect(self.on_workflow_changed)
        self.workflow_combo.setMinimumWidth(350)
        self.workflow_combo.setMaximumWidth(380)
        settings_grid.addWidget(QLabel("使用哪套工作流："), 1, 0)
        settings_grid.addWidget(self.workflow_combo, 1, 1)
        rb = QPushButton("刷新工作流")
        rb.setFixedWidth(96)
        rb.clicked.connect(self.refresh_workflows)
        settings_grid.addWidget(rb, 1, 2)

        self.start_wait = QSpinBox()
        self.start_wait.setRange(0, 300)
        self.start_wait.setValue(3)
        self.start_wait.setFixedWidth(350)
        self.start_wait.setToolTip("启动软件后等待多少秒再执行工作流。")
        self.start_wait.valueChanged.connect(self.save_current_memory)
        wait_label = QLabel("软件启动后等待：")
        settings_grid.addWidget(wait_label, 2, 0)
        settings_grid.addWidget(self.start_wait, 2, 1)
        settings_grid.addWidget(QLabel("秒"), 2, 2)

        self.interval = QSpinBox()
        self.interval.setRange(0, 300)
        self.interval.setValue(2)
        self.interval.setFixedWidth(350)
        self.interval.setToolTip("一个账号处理完成后，等待多少秒再处理下一个账号。")
        self.interval.valueChanged.connect(self.save_current_memory)
        settings_grid.addWidget(QLabel("两个账号之间等待："), 3, 0)
        settings_grid.addWidget(self.interval, 3, 1)
        settings_grid.addWidget(QLabel("秒"), 3, 2)

        self.concurrency = QSpinBox()
        self.concurrency.setRange(1, 32); self.concurrency.setValue(1)
        self.concurrency.valueChanged.connect(self.save_current_memory)
        self.concurrency.setToolTip("1=兼容原来的串行模式；大于1时每个账号使用独立 WorkflowEngine/运行上下文并发执行。")
        settings_grid.addWidget(QLabel("并发账号数："), 4, 0); settings_grid.addWidget(self.concurrency, 4, 1); settings_grid.addWidget(QLabel("个（1=串行）"), 4, 2)

        self.range_start = QSpinBox()
        self.range_start.setRange(1, 999999)
        self.range_start.setValue(1)
        self.range_start.setFixedWidth(100)
        # 允许直接键盘输入完整数字；关闭键盘逐字跟踪，避免从 50 改成 80 时输入第一个数字就被范围联动打断。
        self.range_start.setKeyboardTracking(False)
        self.range_start.valueChanged.connect(self.fix_range)

        self.range_end = QSpinBox()
        self.range_end.setRange(1, 999999)
        self.range_end.setValue(1)
        self.range_end.setFixedWidth(100)
        # 允许直接键盘输入完整数字；失焦/确认后再执行范围联动。
        self.range_end.setKeyboardTracking(False)
        self.range_end.valueChanged.connect(self.fix_range)

        range_box = QGroupBox("运行账号范围")
        range_box.setMinimumHeight(58)
        range_layout = QHBoxLayout(range_box)
        range_layout.setContentsMargins(10, 6, 10, 6)
        range_layout.setSpacing(8)
        range_layout.addWidget(QLabel("从第")); range_layout.addWidget(self.range_start)
        range_layout.addWidget(QLabel("个到第")); range_layout.addWidget(self.range_end); range_layout.addWidget(QLabel("个"))
        self.all_start_btn = QPushButton("全部启动")
        self.all_start_btn.setMinimumWidth(90)
        self.all_start_btn.setToolTip("将右侧运行范围自动设置为当前账号总数，即第 1 个到最后一个账号。")
        self.all_start_btn.clicked.connect(self.set_all_range)
        range_layout.addWidget(self.all_start_btn)
        self.range_total_label = QLabel("总数：0"); self.range_selected_label = QLabel("本次：0 个")
        range_layout.addSpacing(15); range_layout.addWidget(self.range_total_label); range_layout.addWidget(self.range_selected_label); range_layout.addStretch(1)
        # “运行设置”和“运行账号范围”固定为同样的宽度，避免随内容/窗口布局产生忽长忽短。
        # 宽度按当前运行中心左侧区域预留，右侧布局保持原样。
        settings_box.setFixedWidth(620)
        range_box.setFixedWidth(620)

        # “总数 / 本次”预留 3 位数字的显示宽度（例如 999），数字增加时不改变布局。
        label_font = self.range_total_label.font()
        fm = self.range_total_label.fontMetrics()
        self.range_total_label.setFixedWidth(fm.horizontalAdvance("总数：999") + 4)
        self.range_selected_label.setFixedWidth(fm.horizontalAdvance("本次：999 个") + 4)

        # 运行设置占用原来左侧第0~4行的位置；其它区域位置不变。
        grid.addWidget(settings_box, 0, 0, 5, 4)
        # 运行账号范围必须独占一整行；此前与“并发账号数”共用第4行，导致控件发生视觉重叠。
        grid.addWidget(range_box, 5, 0, 1, 4)

        # 右侧：独立的“账号验证”预留区 + “运行控制台”。
        # 账号验证独立成线框，避免与运行控制台叠加，也为后续验证功能预留稳定位置。
        validation_box = QGroupBox("账号验证")
        validation_box.setMinimumWidth(390)
        validation_layout = QHBoxLayout(validation_box)
        validation_layout.setContentsMargins(12, 8, 12, 8)
        self.validation_status_label = QLabel("验证中…")
        self.validation_status_label.setStyleSheet("color:#6b7280;")
        validation_btn = QPushButton("重新验证")
        validation_btn.setFixedHeight(30)
        validation_btn.clicked.connect(self.reverify_account)
        validation_layout.addWidget(self.validation_status_label, 1)
        validation_layout.addWidget(validation_btn)
        grid.addWidget(validation_box, 0, 4, 1, 4)

        console = QGroupBox("运行控制台")
        console.setMinimumWidth(390)
        console_layout = QVBoxLayout(console)
        console_layout.setContentsMargins(12, 10, 12, 10)
        console_layout.setSpacing(8)

        console_grid = QGridLayout()
        console_grid.setHorizontalSpacing(8)
        console_grid.setVerticalSpacing(8)
        # 按要求交换“暂停”和“停止”的位置：第一行右侧为停止，第二行右侧为暂停。
        console_buttons = [
            ("读取账号", self.load_csv),
            ("停止", self.stop),
            ("继续", self.resume),
            ("暂停", self.pause),
        ]
        for idx, (text, fn) in enumerate(console_buttons):
            b = QPushButton(text)
            b.setMinimumHeight(32)
            b.clicked.connect(fn)
            console_grid.addWidget(b, idx // 2, idx % 2)
        console_layout.addLayout(console_grid)

        # 运行选项紧跟在控制按钮下面。
        option_row = QHBoxLayout()
        self.skip_expired = QCheckBox("自动跳过已过期账号")
        self.skip_expired.stateChanged.connect(self.save_current_memory)
        self.skip_empty = QCheckBox("自动跳过空密码账号")
        self.skip_empty.setChecked(True)
        self.skip_empty.stateChanged.connect(self.save_current_memory)
        option_row.addWidget(self.skip_expired)
        option_row.addWidget(self.skip_empty)
        option_row.addStretch(1)
        console_layout.addLayout(option_row)

        console_note = QLabel("运行前先读取账号；运行中可暂停、继续或停止。")
        console_note.setStyleSheet("color:#6b7280;")
        console_note.setWordWrap(True)
        console_layout.addWidget(console_note)

        # 独立账号验证位于控制台正上方，控制台不再包含验证框。
        grid.addWidget(console, 1, 4, 5, 4)
        l.addLayout(grid)

        launch_box = QGroupBox("启动方式")
        launch_layout = QHBoxLayout(launch_box)
        self.manual_start_btn = QPushButton("▶ 手动启动")
        self.manual_start_btn.setMinimumHeight(38)
        self.manual_start_btn.clicked.connect(self.start)
        self.manual_start_btn.setFixedWidth(112)
        launch_layout.addWidget(self.manual_start_btn)
        # 锁定键鼠启动：放在“手动启动”右侧、定时启动左侧。
        # 仅任务运行期间有效，运行结束后自动失效。
        self.lock_input_on_start = QCheckBox("锁定键鼠启动")
        self.lock_input_on_start.setToolTip("任务运行期间锁定键盘和鼠标；F12 解锁，F11 重新锁定。任务不会停止。")
        self.lock_input_on_start.setFixedWidth(105)
        launch_layout.addWidget(self.lock_input_on_start)
        self.schedule_time = QTimeEdit(QTime.currentTime().addSecs(60))
        self.schedule_time.setDisplayFormat("HH:mm")
        self.schedule_time.setFixedWidth(200)
        self.schedule_enable = QCheckBox("定时启动")
        self.schedule_enable.setFixedWidth(78)
        self.schedule_enable.stateChanged.connect(self.on_schedule_changed)
        self.schedule_time.timeChanged.connect(self.on_schedule_time_changed)
        self.schedule_cancel_btn = QPushButton("取消定时")
        self.schedule_cancel_btn.setFixedWidth(82)
        self.schedule_cancel_btn.clicked.connect(self.cancel_schedule)
        launch_layout.addWidget(self.schedule_enable)
        launch_layout.addWidget(QLabel("时间："))
        launch_layout.addWidget(self.schedule_time)
        launch_layout.addWidget(self.schedule_cancel_btn)

        self.schedule_label = QLabel("定时状态：未设置")
        self.schedule_label.setStyleSheet("color:#6b7280;")
        launch_layout.addWidget(self.schedule_label)

        launch_layout.addStretch(1)
        l.addWidget(launch_box)

        # 运行总览：把记忆、账号摘要、本轮统计统一放进一个线框区域。
        overview_box = QGroupBox("运行总览")
        overview_layout = QVBoxLayout(overview_box)
        overview_layout.setContentsMargins(12, 8, 12, 8)
        overview_layout.setSpacing(6)

        self.memory_label = QLabel("记忆状态：尚未建立项目")
        self.memory_label.setStyleSheet("color: #666;")
        overview_layout.addWidget(self.memory_label)

        summary_row = QHBoxLayout()
        self.summary = QLabel("尚未读取账号")
        summary_row.addWidget(self.summary)
        self.show_run_password = QCheckBox("显示密码")
        self.show_run_password.setStyle(QApplication.style())
        self.show_run_password.setStyleSheet("")
        self.show_run_password.setToolTip("勾选后在运行中心显示真实密码；不勾选时以 * 号隐藏。不会修改 CSV 中的密码。")
        self.show_run_password.stateChanged.connect(self.refresh_run_password_display)
        summary_row.addWidget(self.show_run_password)
        summary_row.addStretch(1)
        overview_layout.addLayout(summary_row)

        stats_row = QHBoxLayout()
        self.run_stats_label = QLabel("本轮统计：成功 0 ｜ 失败 0 ｜ 跳过 0 ｜ 停止 0")
        self.run_stats_label.setStyleSheet("color:#4b5563;")
        stats_row.addWidget(self.run_stats_label)
        self.process_check_btn = QPushButton("进程检测")
        # 进程检测可随时打开：运行前、运行中、运行完成后均允许查看当前已有记录。
        self.process_check_btn.setEnabled(True)
        self.process_check_btn.setFixedWidth(90)
        self.process_check_btn.setToolTip("随时打开进程检测；会检测当前已记录、由上号器启动过的软件进程。")
        self.process_check_btn.clicked.connect(self.check_run_processes)
        stats_row.addWidget(self.process_check_btn)
        stats_row.addStretch(1)
        overview_layout.addLayout(stats_row)
        l.addWidget(overview_box)

        # 运行中心账号搜索：只隐藏不匹配的行，不改变 self.accounts 原始索引。
        run_search_row = QHBoxLayout()
        run_search_row.addWidget(QLabel("搜索账号："))
        self.run_account_search = QLineEdit()
        self.run_account_search.setPlaceholderText("输入账号、密码、到期时间、状态或备注进行搜索…")
        self.run_account_search.setClearButtonEnabled(True)
        self.run_account_search.textChanged.connect(self.filter_run_accounts)
        run_search_row.addWidget(self.run_account_search, 1)
        self.run_search_result = QLabel("匹配：0 / 0")
        run_search_row.addWidget(self.run_search_result)
        l.addLayout(run_search_row)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels([
            "序号", "账号", "密码", "到期时间", "当前状态 / 备注"
        ])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        header.setSectionsMovable(True)
        header.setMinimumSectionSize(60)
        self.table.setColumnWidth(0, 70)
        self.table.setColumnWidth(1, 130)
        self.table.setColumnWidth(2, 130)
        self.table.setColumnWidth(3, 110)
        self.table.setColumnWidth(4, 220)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setSortingEnabled(False)
        self.table.setStyleSheet("""
            QTableWidget::item:selected {
                background: #fef08a;
                color: #111827;
            }
            QTableWidget::item:hover {
                background: #fef08a;
                color: #111827;
            }
            QTableWidget::item:focus {
                outline: none;
            }
        """)
        self.table.setItemDelegate(ExpiryColorDelegate(self.table))
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_run_table_menu)
        self.table.viewport().installEventFilter(self)
        l.addWidget(self.table)

        log_bar = QHBoxLayout()
        log_bar.addWidget(QLabel("运行日志"))
        self.log_persist_status = QLabel("磁盘日志：正常")
        self.log_persist_status.setToolTip("磁盘日志写入状态；写入失败时记录会暂存在内存并在后续重试。")
        self.log_persist_status.setStyleSheet("color: #15803d;")
        log_bar.addWidget(self.log_persist_status)
        self.simplify_output = QCheckBox("简化输出（仅显示登录账号）")
        # 使用系统原生复选框，保留标准的 ✓ 勾选标记，不覆盖为黄色方块。
        self.simplify_output.setStyle(QApplication.style())
        self.simplify_output.setStyleSheet("")
        self.simplify_output.setToolTip("勾选后只显示当前处理的登录账号，不显示工作流步骤、句柄、等待等详细日志。")
        self.simplify_output.stateChanged.connect(self.on_simplify_output_changed)
        log_bar.addWidget(self.simplify_output)
        self.log_level_filter = QComboBox()
        self.log_level_filter.addItems(["全部等级", "INFO", "SUCCESS", "WARNING", "ERROR"])
        self.log_level_filter.setToolTip("筛选运行日志等级；不影响后台完整日志文件。")
        self.log_level_filter.currentTextChanged.connect(self.refresh_log_view)
        log_bar.addWidget(self.log_level_filter)
        self.log_search = QLineEdit()
        self.log_search.setPlaceholderText("搜索日志关键词…")
        self.log_search.setClearButtonEnabled(True)
        self.log_search.setMaximumWidth(220)
        self.log_search.textChanged.connect(self.refresh_log_view)
        log_bar.addWidget(self.log_search)
        self.auto_failure_screenshot = QCheckBox("失败自动截图")
        self.auto_failure_screenshot.setChecked(True)
        self.auto_failure_screenshot.setToolTip("检测到工作流步骤/账号执行失败时，自动保存当前桌面截图到 error_capture 文件夹。")
        log_bar.addWidget(self.auto_failure_screenshot)
        log_bar.addStretch(1)
        clear_log = QPushButton("清空显示")
        clear_log.setToolTip("只清空当前窗口的日志显示，不删除磁盘上的日志文件。")
        clear_log.clicked.connect(self.clear_log)
        log_bar.addWidget(clear_log)
        l.addLayout(log_bar)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        # 长时间挂机时限制日志块数量，避免 QTextEdit 无限膨胀。
        self.log.document().setMaximumBlockCount(5000)
        l.addWidget(self.log)

        return w

    def build_software_tab(self):
        w = QWidget()
        root = QVBoxLayout(w)
        root.setContentsMargins(12, 12, 12, 12)

        title = QLabel("软件启动工作台")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        root.addWidget(title)

        splitter = QSplitter(Qt.Horizontal)

        # 左侧：启动项目列表
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 8, 0)
        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.addWidget(QLabel("启动项目"))
        title_row.addStretch(1)
        b_up = QToolButton(); b_up.setText("↑"); b_up.setToolTip("上移")
        b_down = QToolButton(); b_down.setText("↓"); b_down.setToolTip("下移")
        b_up.setFixedSize(24, 24); b_down.setFixedSize(24, 24)
        b_up.clicked.connect(lambda: self.move_profile(-1))
        b_down.clicked.connect(lambda: self.move_profile(1))
        title_row.addWidget(b_up); title_row.addWidget(b_down)
        lv.addLayout(title_row)
        self.profile_list = QListWidget()
        self.profile_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.profile_list.currentRowChanged.connect(self.load_profile_editor)
        lv.addWidget(self.profile_list, 1)

        left_btns = QHBoxLayout()
        b_new = QPushButton("新建")
        b_new.clicked.connect(self.new_profile)
        b_delete = QPushButton("删除")
        b_delete.clicked.connect(self.delete_profile)
        b_refresh = QPushButton("刷新")
        b_refresh.clicked.connect(self.refresh_profile_editor)
        left_btns.addWidget(b_new)
        left_btns.addWidget(b_delete)
        left_btns.addWidget(b_refresh)
        lv.addLayout(left_btns)

        # 右侧：只编辑名称、EXE、CSV
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(8, 0, 0, 0)

        box = QGroupBox("启动项目设置")
        form = QFormLayout(box)

        self.profile_name = QLineEdit()
        self.profile_name.setPlaceholderText("例如：游戏A")
        form.addRow("项目名称：", self.profile_name)

        exe_row = QHBoxLayout()
        self.profile_exe = QLineEdit()
        self.profile_exe.setPlaceholderText("选择要启动的软件 EXE")
        exe_btn = QPushButton("选择 EXE")
        exe_btn.clicked.connect(self.choose_profile_exe)
        exe_row.addWidget(self.profile_exe, 1)
        exe_row.addWidget(exe_btn)
        form.addRow("软件 EXE：", exe_row)

        csv_row = QHBoxLayout()
        self.profile_csv = QLineEdit()
        self.profile_csv.setPlaceholderText("选择账号 CSV / TSV 文件")
        csv_btn = QPushButton("选择账号文件")
        csv_btn.clicked.connect(self.choose_profile_csv)
        csv_row.addWidget(self.profile_csv, 1)
        csv_row.addWidget(csv_btn)
        form.addRow("账号文件：", csv_row)

        rv.addWidget(box)

        # v10：启动项目升级为完整运行方案。旧版只有 EXE/CSV 的配置仍可继续使用；
        # 用户保存时才会将工作流与运行参数写入项目，避免启动时强行覆盖旧记忆。
        runtime_box = QGroupBox("项目运行方案（可选保存）")
        runtime_grid = QGridLayout(runtime_box)
        runtime_grid.addWidget(QLabel("工作流："), 0, 0)
        self.profile_workflow = QComboBox()
        self.profile_workflow.setMinimumWidth(280)
        self.profile_workflow.addItem("沿用原有项目记忆", "")
        refresh_profile_wf = QPushButton("刷新")
        refresh_profile_wf.clicked.connect(self.refresh_profile_workflow_choices)
        runtime_grid.addWidget(self.profile_workflow, 0, 1, 1, 2)
        runtime_grid.addWidget(refresh_profile_wf, 0, 3)

        def _profile_spin(name, maximum, default):
            widget = QSpinBox()
            widget.setRange(1 if name in ("concurrency", "range_start", "range_end") else 0, maximum)
            widget.setValue(default)
            setattr(self, name, widget)
            return widget

        self.profile_start_wait = _profile_spin("profile_start_wait", 300, 3)
        self.profile_interval = _profile_spin("profile_interval", 300, 2)
        self.profile_concurrency = _profile_spin("profile_concurrency", 32, 1)
        self.profile_range_start = _profile_spin("profile_range_start", 999999, 1)
        self.profile_range_end = _profile_spin("profile_range_end", 999999, 1)
        runtime_grid.addWidget(QLabel("启动后等待（秒）："), 1, 0)
        runtime_grid.addWidget(self.profile_start_wait, 1, 1)
        runtime_grid.addWidget(QLabel("账号间隔（秒）："), 1, 2)
        runtime_grid.addWidget(self.profile_interval, 1, 3)
        runtime_grid.addWidget(QLabel("并发账号数："), 2, 0)
        runtime_grid.addWidget(self.profile_concurrency, 2, 1)
        range_row = QHBoxLayout()
        range_row.addWidget(QLabel("从")); range_row.addWidget(self.profile_range_start)
        range_row.addWidget(QLabel("到")); range_row.addWidget(self.profile_range_end)
        range_row.addWidget(QLabel("号"))
        runtime_grid.addWidget(QLabel("账号范围："), 2, 2)
        runtime_grid.addLayout(range_row, 2, 3)
        self.profile_skip_expired = QCheckBox("自动跳过已过期账号")
        self.profile_skip_empty = QCheckBox("自动跳过空密码账号")
        self.profile_skip_empty.setChecked(True)
        runtime_grid.addWidget(self.profile_skip_expired, 3, 0, 1, 2)
        runtime_grid.addWidget(self.profile_skip_empty, 3, 2, 1, 2)
        rv.addWidget(runtime_box)

        save_row = QHBoxLayout()
        save_btn = QPushButton("保存启动项目")
        save_btn.setMinimumHeight(36)
        save_btn.clicked.connect(self.save_profile)
        save_row.addWidget(save_btn)
        save_row.addStretch(1)
        rv.addLayout(save_row)

        note = QLabel("每个项目可单独保存 EXE、账号文件、工作流、等待/间隔、并发、账号范围和跳过规则。旧版项目仍兼容；旧项目未保存运行方案时继续使用原有记忆。")
        note.setWordWrap(True)
        note.setStyleSheet("color: #666;")
        rv.addWidget(note)
        rv.addStretch(1)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setSizes([300, 850])
        root.addWidget(splitter, 1)

        self.refresh_profile_editor()
        return w

    def refresh_profile_editor(self):
        if not hasattr(self, 'profile_list'): return
        self.refresh_profile_workflow_choices()
        self.profile_list.clear()
        for p in self.profile_store.data:
            self.profile_list.addItem(p.get('name', '未命名'))
        self.refresh_profile_combo()
        if self.profile_list.count(): self.profile_list.setCurrentRow(0)

    def refresh_profile_workflow_choices(self):
        if not hasattr(self, "profile_workflow"):
            return
        current = self.profile_workflow.currentData()
        self.profile_workflow.blockSignals(True)
        self.profile_workflow.clear()
        self.profile_workflow.addItem("沿用原有项目记忆", "")
        for path in self.store.list():
            self.profile_workflow.addItem(Path(path).stem, str(path))
        idx = self.profile_workflow.findData(current)
        self.profile_workflow.setCurrentIndex(idx if idx >= 0 else 0)
        self.profile_workflow.blockSignals(False)

    def refresh_profile_combo(self):
        if not hasattr(self, 'profile_combo'): return
        cur = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True); self.profile_combo.clear()
        for p in self.profile_store.data:
            self.profile_combo.addItem(p.get('name', '未命名'), p.get('name', ''))
        if cur:
            i = self.profile_combo.findData(cur)
            if i >= 0: self.profile_combo.setCurrentIndex(i)
        self.profile_combo.blockSignals(False)

    def load_profile_editor(self, row):
        if row < 0 or row >= len(self.profile_store.data):
            self._editing_profile_name = None
            return
        p = self.profile_store.data[row]
        self._editing_profile_name = p.get('name', '')
        self.profile_name.setText(p.get('name', ''))
        self.profile_exe.setText(p.get('exe', ''))
        self.profile_csv.setText(p.get('csv', ''))
        runtime = p.get("runtime") if isinstance(p.get("runtime"), dict) else None
        project_memory = {}
        if runtime is None and p.get("exe") and p.get("csv") and hasattr(self, "memory"):
            try:
                project_memory = self.memory.get_project(p.get("exe", ""), p.get("csv", ""))
            except Exception:
                project_memory = {}
        if runtime is None:
            runtime = project_memory
        self.profile_start_wait.setValue(int(runtime.get("start_wait", getattr(self, "start_wait", None).value() if hasattr(self, "start_wait") else 3)))
        self.profile_interval.setValue(int(runtime.get("interval", getattr(self, "interval", None).value() if hasattr(self, "interval") else 2)))
        self.profile_concurrency.setValue(int(runtime.get("concurrency", getattr(self, "concurrency", None).value() if hasattr(self, "concurrency") else 1)))
        self.profile_range_start.setValue(max(1, int(runtime.get("range_start", getattr(self, "range_start", None).value() if hasattr(self, "range_start") else 1))))
        self.profile_range_end.setValue(max(self.profile_range_start.value(), int(runtime.get("range_end", getattr(self, "range_end", None).value() if hasattr(self, "range_end") else 1))))
        self.profile_skip_expired.setChecked(bool(runtime.get("skip_expired", getattr(self, "skip_expired", None).isChecked() if hasattr(self, "skip_expired") else False)))
        self.profile_skip_empty.setChecked(bool(runtime.get("skip_empty", getattr(self, "skip_empty", None).isChecked() if hasattr(self, "skip_empty") else True)))
        workflow = str(p.get("workflow", "") or project_memory.get("workflow", "") or "")
        self.profile_workflow.setCurrentIndex(max(0, self.profile_workflow.findData(workflow)))

    def current_profile(self):
        name = self.profile_name.text().strip()
        if not name:
            exe_name = Path(self.profile_exe.text().strip()).stem or '启动项目'
            csv_name = Path(self.profile_csv.text().strip()).stem
            name = f'{exe_name} - {csv_name}' if csv_name else exe_name
        if self.profile_range_start.value() > self.profile_range_end.value():
            raise ValueError("账号范围的起始序号不能大于结束序号。")
        return {
            'name': name,
            'exe': self.profile_exe.text().strip(),
            'csv': self.profile_csv.text().strip(),
            'workflow': str(self.profile_workflow.currentData() or ""),
            'runtime': {
                'start_wait': self.profile_start_wait.value(),
                'interval': self.profile_interval.value(),
                'concurrency': self.profile_concurrency.value(),
                'range_start': self.profile_range_start.value(),
                'range_end': self.profile_range_end.value(),
                'skip_expired': self.profile_skip_expired.isChecked(),
                'skip_empty': self.profile_skip_empty.isChecked(),
            },
        }

    def choose_profile_exe(self):
        p, _ = QFileDialog.getOpenFileName(self, '选择要启动的软件', '', 'EXE 程序 (*.exe)')
        if p: self.profile_exe.setText(p)

    def choose_profile_csv(self):
        p, _ = QFileDialog.getOpenFileName(self, '选择账号文件', '', '账号文件 (*.csv *.tsv);;所有文件 (*)')
        if p: self.profile_csv.setText(p)

    def new_profile(self):
        self._editing_profile_name = None
        self.profile_list.setCurrentRow(-1)
        self.profile_list.clearSelection()
        self.profile_name.clear(); self.profile_exe.clear(); self.profile_csv.clear()
        if hasattr(self, "exe"):
            self.profile_exe.setText(self.exe.text().strip())
            self.profile_csv.setText(self.csv.text().strip())
            self.profile_start_wait.setValue(self.start_wait.value())
            self.profile_interval.setValue(self.interval.value())
            self.profile_concurrency.setValue(self.concurrency.value())
            self.profile_range_start.setValue(self.range_start.value())
            self.profile_range_end.setValue(max(self.range_start.value(), self.range_end.value()))
            self.profile_skip_expired.setChecked(self.skip_expired.isChecked())
            self.profile_skip_empty.setChecked(self.skip_empty.isChecked())
            idx = self.profile_workflow.findData(self.workflow_combo.currentData())
            self.profile_workflow.setCurrentIndex(idx if idx >= 0 else 0)

    def save_profile(self):
        try:
            p = self.current_profile()
            if not p['exe'] or not p['csv']:
                raise ValueError('请先选择软件 EXE 和账号文件。')
            old_name = getattr(self, '_editing_profile_name', None)
            if old_name and old_name != p['name']:
                if any(x.get('name') == p['name'] for x in self.profile_store.data):
                    raise ValueError(f'项目名称“{p["name"]}”已经存在，请使用不同名称。')
                old_index = next((i for i, x in enumerate(self.profile_store.data) if x.get('name') == old_name), -1)
                if old_index >= 0:
                    cleaned = self.profile_store._clean(p)
                    self.profile_store.data[old_index] = cleaned
                    self.profile_store.save()
                else:
                    self.profile_store.upsert(p)
            else:
                self.profile_store.upsert(p)
            self.refresh_profile_editor()
            for i, x in enumerate(self.profile_store.data):
                if x.get('name') == p['name']:
                    self.profile_list.setCurrentRow(i); break
            self.apply_profile_to_run(p)
            self.write_log('已保存启动项目：' + p['name'])
        except Exception as e: QMessageBox.critical(self, '保存启动项目失败', str(e))

    def delete_profile(self):
        row = self.profile_list.currentRow()
        if row < 0 or row >= len(self.profile_store.data): return
        name = self.profile_store.data[row].get('name', '')
        if QMessageBox.question(self, '确认删除', f'确定删除“{name}”吗？') == QMessageBox.Yes:
            self.profile_store.delete(name)
            if self._active_profile_name == name:
                self._active_profile_name = None
            self.refresh_profile_editor()

    def move_profile(self, delta):
        row = self.profile_list.currentRow()
        target = row + int(delta)
        if row < 0 or target < 0 or target >= len(self.profile_store.data):
            return
        self.profile_store.data[row], self.profile_store.data[target] = (
            self.profile_store.data[target], self.profile_store.data[row]
        )
        self.profile_store.save()
        self.refresh_profile_editor()
        self.profile_list.setCurrentRow(target)
        self.refresh_profile_combo()
        self.write_log(f"已调整启动项目顺序：{self.profile_store.data[target].get('name', '')}")

    def on_profile_changed(self, index):
        if getattr(self, '_restoring_memory', False) or index < 0:
            return
        name = self.profile_combo.itemData(index)
        for p in self.profile_store.data:
            if p.get('name') != name:
                continue
            if self.running:
                self.write_log("当前正在运行，禁止应用启动项目切换；请等待本轮结束后再切换。")
                # 运行期间不能让下拉框显示一个实际上未应用的项目。
                self._restoring_memory = True
                try:
                    previous = self.profile_combo.findData(self._active_profile_name or "")
                    self.profile_combo.setCurrentIndex(previous)
                finally:
                    self._restoring_memory = False
                return
            self.apply_profile_to_run(p)
            return

    def _close_process_check_dialog(self):
        """状态基准发生变化时关闭旧检测窗口，避免它继续展示上一批的快照。"""
        dlg = getattr(self, "_process_check_dialog", None)
        self._process_check_dialog = None
        if dlg is not None:
            try:
                dlg.close()
            except Exception:
                pass

    def apply_profile_to_run(self, p):
        if self.running:
            self.write_log("当前正在运行，禁止应用启动项目切换；请等待本轮结束后再切换。")
            return
        exe = str(p.get('exe', '') or '').strip()
        csv_path = str(p.get('csv', '') or '').strip()
        # 项目切换后，旧进程检测窗口和上一项目的账号索引均失效。
        self._close_process_check_dialog()
        self._failed_indices.clear()
        self._status_tracker = StatusTracker()
        # 项目之间严格隔离：旧项目的 PID 历史、当前批次进程表和主动结束记录均不可复用。
        if hasattr(self, "_process_history"):
            self._process_history.clear()
        if hasattr(self, "_run_processes"):
            self._run_processes.clear()
        if hasattr(self, "_killed_processes"):
            self._killed_processes.clear()
        self._run_stats = {"success": 0, "failed": 0, "skipped": 0, "stopped": 0}
        self.refresh_run_stats()
        self._restoring_memory = True
        try:
            self.exe.setText(exe)
            self.csv.setText(csv_path)
            if hasattr(self, "csv_manage_path"):
                self.csv_manage_path.setText(csv_path)
        finally:
            self._restoring_memory = False

        # 先恢复旧版已有的 exe+CSV 项目记忆，再应用新版本中显式保存的运行方案。
        if csv_path and os.path.isfile(csv_path):
            if exe and os.path.isfile(exe):
                self.apply_project_memory(exe, csv_path, load_csv=True)
            else:
                self.load_csv(show_message=False, restore_range=True)
                self.write_log(f"启动项目“{p.get('name', '')}”的软件 EXE 不存在；账号文件已载入，但运行前必须修正 EXE 路径。")
        else:
            # 关键安全边界：CSV 路径失效时清空旧项目账号，不能让旧账号列表跟着新路径继续运行。
            self.accounts = []
            self._secret_redactor.update([])
            self.table.setRowCount(0)
            self.range_start.setMaximum(1)
            self.range_end.setMaximum(1)
            self.range_start.setValue(1)
            self.range_end.setValue(1)
            self.range_total_label.setText("总数：0")
            self.write_log(f"启动项目“{p.get('name', '')}”的账号文件不存在，已清空旧账号列表：{csv_path or '未设置路径'}")

        runtime = p.get("runtime") if isinstance(p.get("runtime"), dict) else None
        saved_workflow = str(p.get("workflow", "") or "").strip()
        self._restoring_memory = True
        try:
            if runtime is not None:
                self.start_wait.setValue(max(0, min(300, int(runtime.get("start_wait", self.start_wait.value())))))
                self.interval.setValue(max(0, min(300, int(runtime.get("interval", self.interval.value())))))
                self.concurrency.setValue(max(1, min(32, int(runtime.get("concurrency", self.concurrency.value())))))
                self.skip_expired.setChecked(bool(runtime.get("skip_expired", self.skip_expired.isChecked())))
                self.skip_empty.setChecked(bool(runtime.get("skip_empty", self.skip_empty.isChecked())))
                if self.accounts:
                    start = max(1, min(int(runtime.get("range_start", 1)), len(self.accounts)))
                    end = max(start, min(int(runtime.get("range_end", len(self.accounts))), len(self.accounts)))
                    self.range_start.setValue(start)
                    self.range_end.setValue(end)
            if saved_workflow:
                self.current_workflow_path = saved_workflow
            self.refresh_workflows()
            if saved_workflow and not any(str(x) == saved_workflow for x in self.store.list()):
                self.write_log(f"项目工作流路径不存在，已保留当前可用工作流：{saved_workflow}")
        finally:
            self._restoring_memory = False
        self.update_range_labels()
        self._active_profile_name = str(p.get("name", "") or "")
        if hasattr(self, "profile_combo"):
            self.profile_combo.blockSignals(True)
            try:
                self.profile_combo.setCurrentIndex(self.profile_combo.findData(self._active_profile_name))
            finally:
                self.profile_combo.blockSignals(False)
        if runtime is not None or saved_workflow:
            self.save_current_memory()

    def start_parallel_profiles(self):
        profiles = [dict(x) for x in self.profile_store.data]
        if not profiles:
            QMessageBox.information(self, '并行启动', '还没有保存启动项目。'); return
        for p in profiles:
            threading.Thread(target=self.run_profile_worker, args=(p,), daemon=True).start()
        self.write_log(f'已请求并行启动 {len(profiles)} 个启动项目。')

    def run_profile_worker(self, p):
        try:
            exe = p.get('exe', ''); csv = p.get('csv', '')
            if not os.path.isfile(exe):
                self.signals.log.emit(f"启动项目“{p.get('name','')}”的软件 EXE 不存在，已跳过。"); return
            if not os.path.isfile(csv):
                self.signals.log.emit(f"启动项目“{p.get('name','')}”的账号文件不存在，已跳过。"); return
            pm = ProcessManager(); pid = pm.start(exe)
            self.signals.log.emit(f"启动项目“{p.get('name','')}”：软件已启动 PID={pid}，上号器不会自动关闭。账号文件：{csv}")
        except Exception as e:
            self.signals.log.emit(f"启动项目“{p.get('name','')}”失败：{e}")

    def build_workflow_tab(self):
        w = QWidget()
        root = QVBoxLayout(w)

        # 顶部只负责工作流管理，和“步骤删除”彻底分开，避免误操作。
        top = QHBoxLayout()
        title = QLabel("工作流工作台")
        title.setStyleSheet("font-size: 16px; font-weight: 600;")
        top.addWidget(title)
        top.addStretch()
        debug_btn = QPushButton("单步调试工作流")
        debug_btn.setFixedHeight(32)
        debug_btn.setToolTip("选择工作流和测试账号，启动独立软件实例后逐步执行，支持断点、变量和句柄监视。")
        debug_btn.clicked.connect(self.open_debugger)
        top.addWidget(debug_btn)
        handle_btn = QPushButton("查看窗口句柄")
        handle_btn.setFixedHeight(32)
        handle_btn.setToolTip("打开统一句柄查看器；可从这里查找 HWND、ClassName、Selector 和控件文本。")
        handle_btn.clicked.connect(self.show_tree)
        top.addWidget(handle_btn)
        root.addLayout(top)

        split = QSplitter(Qt.Horizontal)

        # 左侧：仅管理“工作流文件”
        left = QWidget()
        lv = QVBoxLayout(left)
        wf_title = QLabel("工作流列表")
        wf_title.setStyleSheet("font-weight: 600;")
        wf_title_row = QHBoxLayout()
        wf_title_row.setContentsMargins(0, 0, 0, 0)
        wf_title_row.addWidget(wf_title)
        wf_title_row.addStretch(1)
        up_wf_btn = QToolButton(); up_wf_btn.setText("↑"); up_wf_btn.setToolTip("上移")
        down_wf_btn = QToolButton(); down_wf_btn.setText("↓"); down_wf_btn.setToolTip("下移")
        up_wf_btn.setFixedSize(24, 24); down_wf_btn.setFixedSize(24, 24)
        up_wf_btn.clicked.connect(lambda: self.move_workflow(-1))
        down_wf_btn.clicked.connect(lambda: self.move_workflow(1))
        wf_title_row.addWidget(up_wf_btn); wf_title_row.addWidget(down_wf_btn)
        lv.addLayout(wf_title_row)
        self.wf_list = QListWidget()
        self.wf_list.currentRowChanged.connect(self.select_workflow)
        lv.addWidget(self.wf_list, 1)

        manage = QGridLayout()
        new_btn = QPushButton("新建工作流")
        import_btn = QPushButton("导入 JSON")
        refresh_btn = QPushButton("刷新")
        rename_wf_btn = QPushButton("重命名工作流")
        copy_wf_btn = QPushButton("复制工作流")
        export_wf_btn = QPushButton("导出工作流")
        export_all_btn = QPushButton("导出全部")
        import_multi_btn = QPushButton("导入工作流")
        delete_wf_btn = QPushButton("删除整个工作流")
        delete_wf_btn.setToolTip("只删除左侧选中的工作流文件，不会删除步骤中的单个动作。")
        delete_wf_btn.setStyleSheet("color: #b00020;")
        new_btn.clicked.connect(self.new_workflow)
        import_btn.clicked.connect(self.import_workflows)
        refresh_btn.clicked.connect(self.refresh_workflows)
        rename_wf_btn.clicked.connect(self.rename_workflow)
        copy_wf_btn.clicked.connect(self.copy_workflow)
        export_wf_btn.clicked.connect(self.export_current_workflow)
        export_all_btn.clicked.connect(self.export_all_workflows)
        import_multi_btn.clicked.connect(self.import_workflows)
        delete_wf_btn.clicked.connect(self.delete_workflow)
        manage.addWidget(new_btn, 0, 0)
        manage.addWidget(import_btn, 0, 1)
        manage.addWidget(refresh_btn, 1, 0)
        manage.addWidget(rename_wf_btn, 1, 1)
        manage.addWidget(copy_wf_btn, 2, 0)
        manage.addWidget(export_wf_btn, 2, 1)
        manage.addWidget(export_all_btn, 3, 0)
        manage.addWidget(import_multi_btn, 3, 1)
        manage.addWidget(delete_wf_btn, 4, 0, 1, 2)
        lv.addLayout(manage)
        split.addWidget(left)

        # 右侧：只编辑当前工作流，不放“删除整个工作流”按钮。
        right = QWidget()
        rv = QVBoxLayout(right)
        self.editor_host = QWidget()
        self.editor_layout = QVBoxLayout(self.editor_host)
        self.editor_layout.setContentsMargins(0, 0, 0, 0)
        rv.addWidget(self.editor_host, 1)

        save_bar = QHBoxLayout()
        save_btn = QPushButton("保存当前工作流")
        save_as_btn = QPushButton("另存为")
        check_btn = QPushButton("工作流检查器")
        version_btn = QPushButton("版本/备份")
        history_btn = QPushButton("运行历史")
        save_btn.clicked.connect(self.save_workflow)
        save_as_btn.clicked.connect(self.save_as_workflow)
        check_btn.clicked.connect(self.workflow_checker)
        version_btn.clicked.connect(self.workflow_versions)
        history_btn.clicked.connect(self.show_run_history)
        save_bar.addWidget(save_btn)
        save_bar.addWidget(save_as_btn)
        save_bar.addWidget(check_btn)
        save_bar.addWidget(version_btn)
        save_bar.addWidget(history_btn)
        save_bar.addStretch()
        rv.addLayout(save_bar)
        split.addWidget(right)
        split.setSizes([280, 900])
        root.addWidget(split, 1)

        tip = QLabel(
            "左侧管理工作流文件；右侧只编辑步骤。删除步骤只会删除当前步骤，"
            "删除整个工作流必须点击左侧明确标注的“删除整个工作流”。"
        )
        tip.setWordWrap(True)
        root.addWidget(tip)

        self.refresh_wf_list()
        return w

    # =========================
    # 记忆系统
    # =========================

    def restore_memory(self):
        self._restoring_memory = True
        try:
            s = self.memory.settings

            # 全局最近使用路径
            exe = s.get("last_exe", "")
            csv = s.get("last_csv", "")
            if exe:
                self.exe.setText(exe)
            if csv:
                self.csv.setText(csv)

            # 窗口位置 / 大小
            geometry = s.get("window_geometry")
            if geometry:
                try:
                    from PySide6.QtCore import QByteArray
                    self.restoreGeometry(QByteArray.fromBase64(geometry.encode("ascii")))
                except Exception:
                    pass

            # 表格列宽 / 顺序
            self._restore_table_memory(s)

            if hasattr(self, "simplify_output"):
                self.simplify_output.setChecked(bool(s.get("simplify_output", False)))

            if s.get("schedule_time"):
                t = QTime.fromString(str(s.get("schedule_time")), "HH:mm")
                if t.isValid():
                    self.schedule_time.setTime(t)
                    if bool(s.get("schedule_enabled", False)):
                        dt=self._next_schedule_datetime()
                        self._scheduled_target=dt
                        self.schedule_enable.setChecked(True)
                        day="今天" if dt.date()==QDate.currentDate() else "明天"
                        self.schedule_label.setText(f"定时状态：{day} {dt.toString('HH:mm')} 启动")

            if exe and csv and os.path.isfile(exe) and os.path.isfile(csv):
                self.apply_project_memory(exe, csv, load_csv=True)
                matching = next((x for x in self.profile_store.data if x.get("exe", "").strip() == exe and x.get("csv", "").strip() == csv), None)
                self._active_profile_name = str(matching.get("name", "") or "") if matching else None
                if hasattr(self, "profile_combo"):
                    self.profile_combo.blockSignals(True)
                    try:
                        self.profile_combo.setCurrentIndex(self.profile_combo.findData(self._active_profile_name or ""))
                    finally:
                        self.profile_combo.blockSignals(False)
            else:
                self._active_profile_name = None
                if hasattr(self, "profile_combo"):
                    self.profile_combo.blockSignals(True)
                    self.profile_combo.setCurrentIndex(-1)
                    self.profile_combo.blockSignals(False)
                self.refresh_memory_label()
        finally:
            self._restoring_memory = False

    def _restore_table_memory(self, settings):
        widths = settings.get("table_column_widths")
        if isinstance(widths, list) and len(widths) == self.table.columnCount():
            for i, width in enumerate(widths):
                try:
                    self.table.setColumnWidth(i, max(60, int(width)))
                except Exception:
                    pass

        order = settings.get("table_column_order")
        if isinstance(order, list) and len(order) == self.table.columnCount():
            try:
                header = self.table.horizontalHeader()
                for target_pos, logical_index in enumerate(order):
                    current_pos = header.visualIndex(int(logical_index))
                    if current_pos != target_pos:
                        header.moveSection(current_pos, target_pos)
            except Exception:
                pass

    def _save_table_memory(self):
        header = self.table.horizontalHeader()
        widths = [self.table.columnWidth(i) for i in range(self.table.columnCount())]
        order = [header.logicalIndex(i) for i in range(self.table.columnCount())]
        self.memory.settings["table_column_widths"] = widths
        self.memory.settings["table_column_order"] = order

    def _restore_csv_table_memory(self, settings):
        if not hasattr(self, "csv_manager_table"):
            return
        widths = settings.get("csv_table_column_widths") if isinstance(settings, dict) else None
        if isinstance(widths, list) and len(widths) == self.csv_manager_table.columnCount():
            for i, width in enumerate(widths):
                try:
                    self.csv_manager_table.setColumnWidth(i, max(60, int(width)))
                except Exception:
                    pass
        order = settings.get("csv_table_column_order") if isinstance(settings, dict) else None
        if isinstance(order, list) and len(order) == self.csv_manager_table.columnCount():
            try:
                header = self.csv_manager_table.horizontalHeader()
                for target_pos, logical_index in enumerate(order):
                    current_pos = header.visualIndex(int(logical_index))
                    if current_pos != target_pos:
                        header.moveSection(current_pos, target_pos)
            except Exception:
                pass

    def _schedule_csv_table_memory(self):
        if getattr(self, "_restoring_memory", False):
            return
        if hasattr(self, "_csv_header_save_timer"):
            self._csv_header_save_timer.start()

    def _save_csv_table_memory(self):
        if getattr(self, "_restoring_memory", False) or not hasattr(self, "csv_manager_table"):
            return
        header = self.csv_manager_table.horizontalHeader()
        self.memory.settings["csv_table_column_widths"] = [self.csv_manager_table.columnWidth(i) for i in range(self.csv_manager_table.columnCount())]
        self.memory.settings["csv_table_column_order"] = [header.logicalIndex(i) for i in range(self.csv_manager_table.columnCount())]
        self.memory._save(self.memory.settings_file, self.memory.settings)

    def save_current_memory(self, *args):
        if self._restoring_memory:
            return

        exe = self.exe.text().strip()
        csv = self.csv.text().strip()

        self.memory.settings["last_exe"] = exe
        self.memory.settings["last_csv"] = csv
        self._save_table_memory()

        if exe and csv:
            self.memory.save_project(
                exe,
                csv,
                workflow=self.workflow_combo.currentData(),
                start_wait=self.start_wait.value(),
                interval=self.interval.value(),
                concurrency=self.concurrency.value(),
                range_start=self.range_start.value(),
                range_end=self.range_end.value(),
                skip_expired=self.skip_expired.isChecked(),
                skip_empty=self.skip_empty.isChecked(),
            )
        else:
            self.memory.save_settings(
                last_exe=exe,
                last_csv=csv,
            )
            return

        self.memory._save(self.memory.settings_file, self.memory.settings)
        self.refresh_memory_label()

    def apply_project_memory(self, exe, csv, load_csv=True):
        if not exe or not csv:
            return

        project = self.memory.get_project(exe, csv)
        runtime = self.memory.get_runtime(exe, csv)

        self._restoring_memory = True
        try:
            self.exe.setText(exe)
            self.csv.setText(csv)

            if project:
                self.start_wait.setValue(int(project.get("start_wait", self.start_wait.value())))
                self.interval.setValue(int(project.get("interval", self.interval.value())))
                self.concurrency.setValue(int(project.get("concurrency", self.concurrency.value())))
                self.skip_expired.setChecked(bool(project.get("skip_expired", self.skip_expired.isChecked())))
                self.skip_empty.setChecked(bool(project.get("skip_empty", self.skip_empty.isChecked())))

                workflow = project.get("workflow")
                if workflow:
                    self.current_workflow_path = str(workflow)

            if load_csv:
                self.load_csv(show_message=False, restore_range=True)

            self.refresh_workflows()
            self.select_saved_workflow()

            if project:
                start = int(project.get("range_start", 1))
                end = int(project.get("range_end", max(1, len(self.accounts))))
                if self.accounts:
                    start = max(1, min(start, len(self.accounts)))
                    end = max(start, min(end, len(self.accounts)))
                    self.range_start.setValue(start)
                    self.range_end.setValue(end)

            self.refresh_memory_label(runtime)
        finally:
            self._restoring_memory = False

    def select_saved_workflow(self):
        path = self.current_workflow_path
        if not path:
            return
        paths = self.store.list()
        for i, p in enumerate(paths):
            if str(p) == str(path):
                self.workflow_combo.setCurrentIndex(i)
                if hasattr(self, "wf_list"):
                    self.wf_list.setCurrentRow(i)
                return

    def refresh_memory_label(self, runtime=None):
        if not hasattr(self, "memory_label"):
            return
        exe = self.exe.text().strip()
        csv = self.csv.text().strip()
        if not exe or not csv:
            self.memory_label.setText("记忆状态：尚未建立项目")
            return

        if runtime is None:
            runtime = self.memory.get_runtime(exe, csv)

        last_account = runtime.get("last_account", "")
        last_result = runtime.get("last_result", "")
        last_time = runtime.get("last_run_time", "")

        text = "记忆状态：项目设置已保存"
        if last_account:
            text += f" ｜ 上次账号：{last_account}"
        if last_result:
            text += f" ｜ 结果：{last_result}"
        if last_time:
            text += f" ｜ 时间：{last_time}"
        self.memory_label.setText(text)

    def resume_from_last(self):
        exe = self.exe.text().strip()
        csv = self.csv.text().strip()
        if not exe or not csv:
            QMessageBox.information(self, "没有记忆", "请先选择软件 EXE 和账号 CSV。")
            return

        if not self.accounts:
            self.load_csv(show_message=False, restore_range=False)
        if not self.accounts:
            return

        runtime = self.memory.get_runtime(exe, csv)
        next_index = int(runtime.get("next_index", 1))

        if next_index > len(self.accounts):
            QMessageBox.information(
                self,
                "已经处理完成",
                f"这个项目上次已经运行到第 {len(self.accounts)} 个账号之后，没有可继续的账号。"
            )
            return

        self.range_start.setValue(next_index)
        if self.range_end.value() < next_index:
            self.range_end.setValue(len(self.accounts))

        self.write_log(f"已恢复断点：准备从第 {next_index} 个账号继续。")
        self.refresh_memory_label(runtime)

    # =========================
    # 路径 / 工作流记忆
    # =========================

    def on_exe_changed(self):
        if self._restoring_memory:
            return
        if self.running:
            self.exe.blockSignals(True)
            self.exe.setText(self._run_locked_exe)
            self.exe.blockSignals(False)
            self.write_log("当前正在运行，禁止切换启动软件；请等待本轮结束后再切换。")
            return
        exe = self.exe.text().strip()
        csv = self.csv.text().strip()
        self.memory.save_settings(last_exe=exe)
        if exe and csv and os.path.isfile(exe) and os.path.isfile(csv):
            self.apply_project_memory(exe, csv, load_csv=True)
        else:
            self.refresh_memory_label()

    def on_csv_changed(self):
        if self._restoring_memory:
            return
        if self.running:
            self.csv.blockSignals(True)
            self.csv.setText(self._run_locked_csv)
            self.csv.blockSignals(False)
            self.write_log("当前正在运行，禁止切换账号 CSV；请等待本轮结束后再切换。")
            return
        exe = self.exe.text().strip()
        csv = self.csv.text().strip()
        self.memory.save_settings(last_csv=csv)
        if csv and os.path.isfile(csv):
            if exe and os.path.isfile(exe):
                self.apply_project_memory(exe, csv, load_csv=True)
            else:
                self.load_csv(show_message=False, restore_range=True)
                self.refresh_memory_label()

    def on_workflow_changed(self, index):
        if self._restoring_memory or index < 0:
            return
        if self.running:
            self.workflow_combo.blockSignals(True)
            if self._run_locked_workflow_index >= 0:
                self.workflow_combo.setCurrentIndex(self._run_locked_workflow_index)
            self.workflow_combo.blockSignals(False)
            self.write_log("当前正在运行，禁止切换工作流；请等待本轮结束后再切换。")
            return
        path = self.workflow_combo.itemData(index)
        if path:
            self.current_workflow_path = str(path)
            self.memory.save_settings(last_workflow=self.current_workflow_path)
            self.save_current_memory()

    def eventFilter(self, obj, event):
        # 运行中心账号表：点击表格外任意位置都取消黄色高亮；点击表格空白同样取消。
        if hasattr(self, "table") and event.type() == 2:
            try:
                pos = event.globalPosition().toPoint()
                table_rect = self.table.rect()
                table_top_left = self.table.mapToGlobal(table_rect.topLeft())
                table_rect.moveTopLeft(table_top_left)
                if not table_rect.contains(pos):
                    self.clear_run_table_selection()
                elif obj is self.table.viewport():
                    local = self.table.viewport().mapFromGlobal(pos)
                    if not self.table.indexAt(local).isValid():
                        self.clear_run_table_selection()
            except Exception:
                pass
        return super().eventFilter(obj, event)

    def clear_run_table_selection(self):
        if hasattr(self, "table"):
            self.table.clearSelection()
            self.table.setCurrentItem(None)

    def on_tab_changed(self, index):
        # 打开 CSV 账号管理标签时自动重新读取当前文件。
        if index == 3 and hasattr(self, "csv_manager_table"):
            self.load_csv_manager()

    def show_run_table_menu(self, pos):
        item = self.table.itemAt(pos)
        if item is None:
            self.clear_run_table_selection()
            return
        row = item.row()
        self.table.selectRow(row)
        account = self.accounts[row].account if 0 <= row < len(self.accounts) else (self.table.item(row, 1).text() if self.table.item(row, 1) else "")
        password = self.accounts[row].password if 0 <= row < len(self.accounts) else ""
        menu = QMenu(self)
        launch_one = menu.addAction("单独启动此账号")
        launch_one.setToolTip("只启动当前右键选中的账号；使用上方“运行设置”中的软件、工作流、等待、跳过规则和并发设置。")
        menu.addSeparator()
        copy_account = menu.addAction("复制账号")
        copy_password = menu.addAction("复制密码")
        copy_both = menu.addAction("复制账号 + 密码")
        action = menu.exec(self.table.viewport().mapToGlobal(pos))
        if action is launch_one:
            self.start_single_account(row)
        elif action is copy_account:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(account)
        elif action is copy_password:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(password)
        elif action is copy_both:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(f"{account}\t{password}")

    def start_single_account(self, row):
        """从账号表右键单独启动当前账号；完全复用上方“运行设置”。"""
        if not self.require_verified():
            return
        if self.running:
            QMessageBox.information(self, "正在运行", "当前已经有任务在运行，请等待本轮结束后再单独启动账号。")
            return
        if row < 0 or row >= len(self.accounts):
            return

        exe = self.exe.text().strip()
        csv_path = self.csv.text().strip()
        wfpath = self.workflow_combo.currentData()
        if not os.path.isfile(exe):
            QMessageBox.warning(self, "无法启动账号", "当前“运行设置”中的软件 EXE 不存在。")
            return
        if not os.path.isfile(csv_path):
            QMessageBox.warning(self, "无法启动账号", "当前“运行设置”中的账号 CSV 不存在。")
            return
        if not wfpath or not os.path.isfile(wfpath):
            QMessageBox.warning(self, "无法启动账号", "当前“运行设置”中没有有效的工作流。")
            return

        try:
            workflow = self.store.load(wfpath)
            if not isinstance(workflow, dict) or not isinstance(workflow.get("steps"), list) or not workflow.get("steps"):
                QMessageBox.warning(self, "工作流为空", "当前选择的工作流没有可执行步骤。")
                return
            validation = self.engine.validate_workflow(workflow)
            if validation.get("errors"):
                QMessageBox.warning(
                    self, "工作流检查未通过",
                    "发现以下配置错误：\n\n" + "\n".join(f"• {x}" for x in validation["errors"])
                )
                return
            for warning in validation.get("warnings", []):
                self.write_log("工作流检查提醒：" + warning)
        except Exception as e:
            QMessageBox.critical(self, "工作流读取失败", str(e))
            return

        # 注意：这里不修改“运行账号范围”。右键单独启动只取当前这一行，
        # 但启动软件、工作流、等待、跳过规则、并发数全部读取上方“运行设置”。
        # 高级调度不再覆盖基础运行参数，避免与运行中心的并发、启动间隔、工作流重试功能重合。
        options = {
            "start_wait": self.start_wait.value(),
            "interval": self.interval.value(),
            "skip_expired": self.skip_expired.isChecked(),
            "skip_empty": self.skip_empty.isChecked(),
        }
        account = self.accounts[row]
        self.save_current_memory()
        self.stop_requested = False
        self._auto_process_retry_round = 0
        self._run_locked_exe = exe
        self._run_locked_csv = csv_path
        self._run_locked_workflow_index = self.workflow_combo.currentIndex()
        self.running = True
        if hasattr(self, "process_check_btn"):
            self.process_check_btn.setEnabled(False)
        if self.lock_input_on_start.isChecked():
            try:
                self.input_lock.begin_session(locked=True)
            except Exception as e:
                self.running = False
                QMessageBox.warning(self, "键鼠锁定失败", f"无法启用全局键鼠锁定：\n{e}")
                return
        self._simple_logged_accounts.clear()
        self._close_process_check_dialog()
        self._failed_indices.clear()
        self._status_tracker = StatusTracker()
        self._run_processes = {}
        self._process_history = []
        self._killed_processes = []
        self._run_stats_generation += 1
        self._run_stats = {"success": 0, "failed": 0, "skipped": 0, "stopped": 0}
        self.refresh_run_stats()
        self.engine.logger = lambda message: self.signals.log.emit(str(message))
        self.engine.stop_event.clear()
        self.engine.resume()
        self._last_run_exe = exe
        self._last_run_csv = csv_path
        self._engine_current_row = row
        self.engine.status_callback = lambda status: self.signals.row.emit(row, str(status))
        self.write_log(f"右键单独启动账号：第 {row + 1} 个，登录账号：{account.account}（使用上方运行设置）")

        threading.Thread(
            target=self.run_all,
            args=(exe, csv_path, workflow, [row], options),
            daemon=True
        ).start()

    def clear_log(self):
        # 清空内存中的当前会话记录；磁盘日志文件保留，便于事后排查。
        self._log_records = []
        if hasattr(self, "log"):
            self.log.clear()

    @staticmethod
    def _classify_log_level(message):
        """按语义优先级分级，避免普通重试/结果汇总被关键词误判为 ERROR。"""
        text = str(message).strip()
        if not text:
            return "INFO"

        # 明确的成功信息优先，避免“失败截图已保存”等复合短语被“失败”误伤。
        if "失败截图已保存" in text or "截图保存成功" in text:
            return "SUCCESS"
        if "失败截图保存失败" in text:
            return "WARNING"
        if re.match(r"^运行结束：成功(?:\s|$)", text):
            return "SUCCESS"

        # 运行结果汇总是业务结果，不等同于未处理异常。
        if re.match(r"^运行结束：失败(?:\s|$)", text):
            return "WARNING"

        # 失败后按配置重试、跳过或继续执行，是可恢复/受控分支。
        controlled_retry = any(token in text for token in (
            "重试失败，按设置", "重试失败后继续", "重试后继续", "重试后成功",
            "按设置进入下一步", "按配置跳过", "按设置跳过", "主动排除",
            "已跳过", "跳过当前步骤", "用户主动停止", "任务已停止",
        ))
        if controlled_retry:
            return "WARNING" if ("失败" in text or "超时" in text or "未找到" in text) else "INFO"

        # 真正的执行错误/异常/中断优先于一般警告词。
        if any(token in text for token in (
            "Traceback", "未处理异常", "工作流异常", "步骤执行失败", "执行失败",
            "运行中断", "无法启用", "键鼠锁定模块异常", "并发失败",
        )):
            return "ERROR"
        if any(token in text for token in ("失败", "异常", "错误")):
            return "ERROR"
        if any(token in text for token in ("警告", "提醒", "超时", "跳过", "未找到", "重试")):
            return "WARNING"
        if any(token in text for token in ("成功", "完成", "已保存", "已启动", "已重新定位")):
            return "SUCCESS"
        return "INFO"

    def _report_log_persist_error(self, exc):
        """首次进入落盘故障状态时同时提示界面与可用 stderr；后续同一故障不刷屏。"""
        message = f"[日志落盘警告] 磁盘日志写入失败，记录暂存内存并将在后续重试：{exc}"
        first_failure = self._log_persist_error is None
        self._log_persist_error = str(exc)
        if not first_failure:
            return
        # write_log_force 只直接写 UI，不会再次进入磁盘持久化，避免递归。
        try:
            self.write_log_force(message)
            if hasattr(self, "log_persist_status"):
                self.log_persist_status.setText("磁盘日志：写入失败（记录暂存）")
                self.log_persist_status.setStyleSheet("color: #b91c1c; font-weight: 600;")
                self.log_persist_status.setToolTip(message)
        except Exception:
            pass
        try:
            stream = getattr(sys, "__stderr__", None)
            if stream:
                stream.write(message + "\n")
                stream.flush()
        except Exception:
            pass

    def _close_log_file(self):
        handle = self._log_file_handle
        self._log_file_handle = None
        self._log_file_date = None
        if handle is not None:
            try:
                handle.flush()
            except Exception:
                pass
            try:
                handle.close()
            except Exception:
                pass

    def _open_log_for_day(self, day):
        if self._log_file_handle is not None and self._log_file_date == day:
            return self._log_file_handle
        self._close_log_file()
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._log_file_handle = (self._log_dir / f"run_{day}.log").open("a", encoding="utf-8", newline="")
        self._log_file_date = day
        return self._log_file_handle

    def _persist_log_record(self, line):
        # 每条记录绑定生成时的日期，避免跨午夜后把暂存日志写进错误日期文件。
        day = datetime.now().strftime("%Y%m%d")
        with self._log_file_lock:
            if len(self._pending_log_lines) >= self._pending_log_limit and self._log_persist_error is not None:
                # 队列已满时先试一次恢复；如果磁盘已恢复，就先补写旧记录，避免在恢复瞬间多丢一条。
                try:
                    while self._pending_log_lines:
                        pending_day, pending_line = self._pending_log_lines[0]
                        handle = self._open_log_for_day(pending_day)
                        handle.write(pending_line + "\n")
                        handle.flush()
                        self._pending_log_lines.popleft()
                    self._log_persist_error = None
                    self.write_log_force("[日志落盘恢复] 磁盘日志写入已恢复，暂存记录已补写完成。")
                    if hasattr(self, "log_persist_status"):
                        self.log_persist_status.setText("磁盘日志：已恢复")
                        self.log_persist_status.setStyleSheet("color: #15803d; font-weight: 600;")
                        self.log_persist_status.setToolTip("磁盘写入已恢复，暂存日志已补写完成。")
                except Exception as exc:
                    self._report_log_persist_error(exc)
                    self._close_log_file()
                    # 磁盘仍不可写：本次只尝试一次，淘汰最旧记录后退出，避免重复 I/O 放大卡顿。
                    self._pending_log_lines.popleft()
                    self._pending_log_dropped += 1
                    self._pending_log_lines.append((day, str(line)))
                    return
            if len(self._pending_log_lines) >= self._pending_log_limit:
                # 磁盘持续不可写时限制内存占用；明确累计丢弃数量，恢复后向界面告警。
                self._pending_log_lines.popleft()
                self._pending_log_dropped += 1
            self._pending_log_lines.append((day, str(line)))
            had_error = self._log_persist_error is not None
            try:
                while self._pending_log_lines:
                    pending_day, pending_line = self._pending_log_lines[0]
                    handle = self._open_log_for_day(pending_day)
                    handle.write(pending_line + "\n")
                    handle.flush()
                    self._pending_log_lines.popleft()
                self._log_persist_error = None
                if had_error:
                    self.write_log_force("[日志落盘恢复] 磁盘日志写入已恢复，暂存记录已补写完成。")
                    if hasattr(self, "log_persist_status"):
                        self.log_persist_status.setText("磁盘日志：已恢复")
                        self.log_persist_status.setStyleSheet("color: #15803d; font-weight: 600;")
                        self.log_persist_status.setToolTip("磁盘写入已恢复，暂存日志已补写完成。")
                if self._pending_log_dropped:
                    dropped = self._pending_log_dropped
                    self._pending_log_dropped = 0
                    self.write_log_force(f"[日志缓存告警] 因暂存队列达到 {self._pending_log_limit} 条上限，已有 {dropped} 条最旧日志被丢弃。")
            except Exception as exc:
                self._report_log_persist_error(exc)
                # 失效句柄不跨调用复用；记录仍留在队列中等待下一次重试。
                self._close_log_file()

    def _flush_and_close_log_file(self):
        """退出时最后尝试写入暂存日志并关闭缓存句柄。"""
        with self._log_file_lock:
            had_error = self._log_persist_error is not None
            try:
                while self._pending_log_lines:
                    pending_day, pending_line = self._pending_log_lines[0]
                    handle = self._open_log_for_day(pending_day)
                    handle.write(pending_line + "\n")
                    handle.flush()
                    self._pending_log_lines.popleft()
                self._log_persist_error = None
                if had_error:
                    self.write_log_force("[日志落盘恢复] 退出前暂存日志已补写完成。")
                    if hasattr(self, "log_persist_status"):
                        self.log_persist_status.setText("磁盘日志：已恢复")
                        self.log_persist_status.setStyleSheet("color: #15803d; font-weight: 600;")
                        self.log_persist_status.setToolTip("退出前磁盘写入已恢复，暂存日志已补写完成。")
                if self._pending_log_dropped:
                    dropped = self._pending_log_dropped
                    self._pending_log_dropped = 0
                    self.write_log_force(f"[日志缓存告警] 因暂存队列达到 {self._pending_log_limit} 条上限，已有 {dropped} 条最旧日志被丢弃。")
            except Exception as exc:
                self._report_log_persist_error(exc)
            finally:
                self._close_log_file()

    def refresh_log_view(self, *_):
        if not hasattr(self, "log"):
            return
        if hasattr(self, "simplify_output") and self.simplify_output.isChecked():
            return
        level = self.log_level_filter.currentText() if hasattr(self, "log_level_filter") else "全部等级"
        query = self.log_search.text().strip().casefold() if hasattr(self, "log_search") else ""
        visible = []
        for record in getattr(self, "_log_records", []):
            if level != "全部等级" and record["level"] != level:
                continue
            if query and query not in record["text"].casefold():
                continue
            visible.append(record["line"])
        self.log.setPlainText("\n".join(visible[-5000:]))
        cursor = self.log.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.log.setTextCursor(cursor)

    def _capture_failure_screenshot(self, message):
        if not hasattr(self, "auto_failure_screenshot") or not self.auto_failure_screenshot.isChecked():
            return
        text = str(message)
        is_failure = (("步骤" in text and "失败" in text) or
                      ("工作流异常" in text) or
                      ("账号" in text and "失败" in text) or
                      ("并发失败" in text))
        if not is_failure:
            return
        now = time.time()
        if now - float(getattr(self, "_last_failure_capture", 0.0)) < 3.0:
            return
        self._last_failure_capture = now
        try:
            screen = QApplication.primaryScreen()
            if screen is None:
                self.write_log("失败截图保存失败：当前没有可用的主屏幕接口。")
                return
            image = screen.grabWindow(0)
            if image.isNull():
                self.write_log("失败截图保存失败：抓取到的桌面图像为空。")
                return
            root = self._log_base_dir / "error_capture" / datetime.now().strftime("%Y%m%d")
            root.mkdir(parents=True, exist_ok=True)
            safe = re.sub(r"[^\w.-]+", "_", text, flags=re.UNICODE).strip("._")[:48] or "failure"
            path = root / f"failure_{datetime.now():%H%M%S}_{safe}.png"
            if image.save(str(path), "PNG"):
                self.write_log(f"失败截图已保存：{path}")
            else:
                # Qt 的 save() 可直接返回 False 而不抛异常；必须明确记录。
                self.write_log(f"失败截图保存失败：QImage.save() 返回 False，路径：{path}")
        except Exception as exc:
            # 截图是辅助诊断能力，任何失败都不能中断上号流程；该消息不满足截图触发条件，不会递归截图。
            try:
                self.write_log(f"失败截图保存失败：{type(exc).__name__}: {exc}")
            except Exception:
                try:
                    self._report_log_persist_error(f"截图记录失败：{exc}")
                except Exception:
                    pass

    # =========================
    # CSV 账号管理
    # =========================

    def build_csv_tab(self):
        w = QWidget()
        root = QHBoxLayout(w)
        root.setContentsMargins(12, 12, 12, 12)

        splitter = QSplitter(Qt.Horizontal)

        # 左侧：CSV 项目列表，行为与软件启动工作台一致。
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 8, 0)
        csv_title_row = QHBoxLayout()
        csv_title_row.setContentsMargins(0, 0, 0, 0)
        csv_title_row.addWidget(QLabel("CSV项目"))
        csv_title_row.addStretch(1)
        b_csv_up = QToolButton(); b_csv_up.setText("↑"); b_csv_up.setToolTip("上移")
        b_csv_down = QToolButton(); b_csv_down.setText("↓"); b_csv_down.setToolTip("下移")
        b_csv_up.setFixedSize(24, 24); b_csv_down.setFixedSize(24, 24)
        b_csv_up.clicked.connect(lambda: self.move_csv_project(-1))
        b_csv_down.clicked.connect(lambda: self.move_csv_project(1))
        csv_title_row.addWidget(b_csv_up); csv_title_row.addWidget(b_csv_down)
        lv.addLayout(csv_title_row)
        self.csv_project_list = QListWidget()
        self.csv_project_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.csv_project_list.currentRowChanged.connect(self.load_csv_project_editor)
        lv.addWidget(self.csv_project_list, 1)
        btns = QHBoxLayout()
        bnew = QPushButton("新建")
        bnew.clicked.connect(self.new_csv_project)
        bdel = QPushButton("删除")
        bdel.clicked.connect(self.delete_csv_project)
        bref = QPushButton("刷新")
        bref.clicked.connect(self.refresh_csv_project_list)
        btns.addWidget(bnew); btns.addWidget(bdel); btns.addWidget(bref)
        lv.addLayout(btns)
        splitter.addWidget(left)

        # 右侧：保留现有 CSV 编辑功能，只把“当前文件”纳入项目管理。
        right = QWidget()
        l = QVBoxLayout(right)
        top = QHBoxLayout()
        top.addWidget(QLabel("CSV项目设置"))
        top.addStretch(1)
        self.csv_project_name = QLineEdit()
        self.csv_project_name.setPlaceholderText("自定义项目标题")
        self.csv_project_name.setMaximumWidth(260)
        top.addWidget(self.csv_project_name)
        save_project_btn = QPushButton("保存项目")
        save_project_btn.clicked.connect(self.save_csv_project)
        top.addWidget(save_project_btn)
        l.addLayout(top)

        path_row = QHBoxLayout()
        path_row.addWidget(QLabel("CSV文件："))
        self.csv_manage_path = QLineEdit()
        self.csv_manage_path.setPlaceholderText("选择要编辑的 CSV / TSV")
        path_row.addWidget(self.csv_manage_path, 1)
        choose = QPushButton("选择文件")
        choose.clicked.connect(self.choose_csv_manage)
        open_csv_btn = QPushButton("打开所选CSV文件")
        open_csv_btn.setToolTip("使用 Windows 默认程序打开当前选中的 CSV / TSV 文件。")
        open_csv_btn.clicked.connect(self.open_selected_csv_file)
        path_row.addWidget(choose)
        path_row.addWidget(open_csv_btn)
        l.addLayout(path_row)

        control = QHBoxLayout()
        self.csv_total_control = QLabel("总账号：0")
        control.addWidget(self.csv_total_control)
        add_btn = QPushButton("＋ 添加账号")
        add_btn.clicked.connect(self.add_csv_account)
        del_btn = QPushButton("删除选中账号")
        del_btn.clicked.connect(self.delete_csv_account)
        copy_account_btn = QPushButton("复制账号")
        copy_account_btn.clicked.connect(self.copy_selected_csv_account)
        copy_password_btn = QPushButton("复制密码")
        copy_password_btn.clicked.connect(self.copy_selected_csv_password)
        self.csv_show_password = QCheckBox("显示密码")
        self.csv_show_password.setChecked(False)
        self.csv_show_password.setToolTip("勾选后显示 CSV 管理表中的真实密码；不勾选时使用 * 号隐藏。")
        self.csv_show_password.toggled.connect(self.toggle_csv_password_display)
        for b in (add_btn, del_btn, copy_account_btn, copy_password_btn):
            control.addWidget(b)
        control.addWidget(self.csv_show_password)
        control.addStretch(1)
        l.addLayout(control)

        self._csv_manager_rows = []
        self.csv_manager_table = QTableWidget(0, 7)
        self.csv_manager_table.setHorizontalHeaderLabels(["账号", "密码", "创建时间", "到期时间", "更新时间", "备注", "状态"])
        csv_header = self.csv_manager_table.horizontalHeader()
        csv_header.setSectionResizeMode(QHeaderView.Interactive)
        csv_header.setSectionsMovable(True)
        self._csv_header_save_timer = QTimer(self)
        self._csv_header_save_timer.setSingleShot(True)
        self._csv_header_save_timer.setInterval(400)
        self._csv_header_save_timer.timeout.connect(self._save_csv_table_memory)
        csv_header.sectionResized.connect(lambda *_: self._schedule_csv_table_memory())
        csv_header.sectionMoved.connect(lambda *_: self._schedule_csv_table_memory())
        self._restore_csv_table_memory(self.memory.settings)
        self.csv_manager_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.csv_manager_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.csv_manager_table.setAlternatingRowColors(True)
        self.csv_manager_table.setStyleSheet("QTableWidget::item:selected { background: #fef08a; color: #111827; } QTableWidget::item:hover { background: #fef08a; color: #111827; }")
        self.csv_manager_table.setItemDelegate(ExpiryColorDelegate(self.csv_manager_table))
        self.csv_manager_table.itemDoubleClicked.connect(lambda item: self.edit_csv_account(item.row()))

        # CSV 账号搜索：只隐藏不匹配的原始行，不改变 _csv_manager_rows 的索引。
        csv_search_row = QHBoxLayout()
        csv_search_row.addWidget(QLabel("搜索账号："))
        self.csv_account_search = QLineEdit()
        self.csv_account_search.setPlaceholderText("输入账号、密码、创建/到期/更新时间或备注进行搜索…")
        self.csv_account_search.setClearButtonEnabled(True)
        self.csv_account_search.textChanged.connect(self.filter_csv_manager_rows)
        csv_search_row.addWidget(self.csv_account_search, 1)
        self.csv_search_result = QLabel("匹配：0 / 0")
        csv_search_row.addWidget(self.csv_search_result)
        l.addLayout(csv_search_row)
        status_row = QHBoxLayout()
        status_row.addWidget(QLabel("状态筛选："))
        self.csv_status_filter = QComboBox()
        self.csv_status_filter.addItems(["全部","未运行","已过期","登录成功","登录失败","密码错误","封禁","跳过","自定义"])
        self.csv_status_filter.currentTextChanged.connect(self.on_csv_status_filter_changed)
        status_row.addWidget(self.csv_status_filter)
        batch = QPushButton("批量设置状态")
        batch.clicked.connect(self.batch_set_csv_status)
        status_row.addWidget(batch)
        clear = QPushButton("清除筛选")
        clear.clicked.connect(self.clear_csv_manager_filter)
        status_row.addWidget(clear)
        self.csv_manager_refresh_btn = QPushButton("刷新")
        self.csv_manager_refresh_btn.setToolTip("重新读取当前 CSV 文件，并重新应用当前搜索与状态筛选")
        self.csv_manager_refresh_btn.clicked.connect(self.refresh_csv_manager_from_disk)
        status_row.addWidget(self.csv_manager_refresh_btn)
        status_row.addStretch(1)
        l.addLayout(status_row)

        l.addWidget(self.csv_manager_table)

        bottom = QHBoxLayout()
        for text, fn in [("↑ 上移", lambda: self.move_csv_row(-1)), ("↓ 下移", lambda: self.move_csv_row(1)),
                         ("恢复读取顺序", self.load_csv_manager), ("保存到 CSV", self.save_csv_manager)]:
            x = QPushButton(text); x.clicked.connect(fn); bottom.addWidget(x)
        bottom.addStretch(1)
        self.csv_manager_info = QLabel("打开项目会自动读取 CSV。修改后点击‘保存到 CSV’写入原文件。")
        self.csv_manager_status = QLabel("")
        self.csv_manager_status.setMinimumWidth(180)
        bottom.addWidget(self.csv_manager_info)
        bottom.addWidget(self.csv_manager_status)
        l.addLayout(bottom)
        splitter.addWidget(right)
        splitter.setSizes([280, 1000])
        root.addWidget(splitter, 1)
        self.refresh_csv_project_list()
        return w

    def _set_table_search_result(self, label, matched, total):
        if label is not None:
            label.setText(f"匹配：{matched} / {total}")

    def filter_run_accounts(self, text=None):
        """过滤运行中心账号表，只隐藏行，不改变 self.accounts 原始索引。"""
        if not hasattr(self, "table"):
            return
        query = str(text if text is not None else self.run_account_search.text()).strip().casefold()
        matched = 0
        total = self.table.rowCount()
        for row in range(total):
            values = []
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item is not None:
                    values.append(item.text())
            ok = (not query) or any(query in value.casefold() for value in values)
            self.table.setRowHidden(row, not ok)
            if ok:
                matched += 1
        self._set_table_search_result(getattr(self, "run_search_result", None), matched, total)

    def _csv_daily_results_path(self):
        path = Path(__file__).resolve().parent / "config" / "csv_daily_results.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def _csv_daily_key(self, path):
        try:
            return os.path.normcase(os.path.abspath(os.path.normpath(str(path))))
        except Exception:
            return str(path).strip().casefold()

    def _load_csv_daily_results(self):
        """读取当天的 CSV 管理运行结果；跨日后自动丢弃旧日结果。"""
        today = datetime.now().strftime("%Y-%m-%d")
        path = self._csv_daily_results_path()
        try:
            data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            if data.get("date") != today:
                return {}
            files = data.get("files", {})
            return files if isinstance(files, dict) else {}
        except Exception:
            return {}

    def _save_csv_daily_results(self, snapshot=None):
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            path = self._csv_daily_results_path()
            payload = {"date": today, "files": snapshot if snapshot is not None else self._csv_daily_results}
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(path)
        except Exception:
            pass

    def _record_csv_daily_result(self, csv_path, account, result):
        """只记录最终运行结果到 CSV 管理器的当天记录；运行中心本身不保存历史。"""
        if not csv_path or not account:
            return
        with self._csv_daily_lock:
            today = datetime.now().strftime("%Y-%m-%d")
            current_file = self._csv_daily_results_path()
            # 跨日运行时自动开始新的一天，不把昨天的结果混入今天。
            if current_file.exists():
                try:
                    disk = json.loads(current_file.read_text(encoding="utf-8"))
                    if disk.get("date") != today:
                        self._csv_daily_results = {}
                except Exception:
                    pass
            key = self._csv_daily_key(csv_path)
            result_text = str(result or "").strip() or "未运行"
            files = self._csv_daily_results.setdefault(key, {})
            files[str(account)] = result_text
            snapshot = json.loads(json.dumps(self._csv_daily_results, ensure_ascii=False))
            self._save_csv_daily_results(snapshot)

            # 运行结果同时直接写回 CSV 的 status 字段。这样软件关闭后重新启动，
            # 当天状态仍然保留；每天 00:00 的重置逻辑会统一改回“未运行”。
            try:
                rows = load_rows(csv_path)
                changed = False
                for row in rows:
                    if str(row.get("account", "") or "").strip() == str(account).strip():
                        if str(row.get("status", "") or "").strip() != result_text:
                            row["status"] = result_text
                            changed = True
                        break
                if changed:
                    save_rows(csv_path, rows)
            except Exception as csv_error:
                self.write_log(f"CSV状态写回失败：{csv_error}")
        # Qt 界面只在主线程刷新，后台并发线程绝不直接操作 QTableWidget。
        try:
            self.signals.csv_daily.emit(str(csv_path), str(account))
        except Exception:
            pass

    def on_csv_daily_signal(self, csv_path, account):
        if hasattr(self, "csv_manage_path") and self._same_csv_path(self.csv_manage_path.text().strip(), csv_path):
            self._refresh_csv_manager_daily_results()

    def _refresh_csv_manager_daily_results(self):
        if not hasattr(self, "csv_manager_table"):
            return
        rows = getattr(self, "_csv_manager_rows", [])
        path = self.csv_manage_path.text().strip() if hasattr(self, "csv_manage_path") else ""
        daily = self._csv_daily_results.get(self._csv_daily_key(path), {}) if path else {}
        for r, data in enumerate(rows):
            if r >= self.csv_manager_table.rowCount():
                break
            expired = self._csv_row_is_expired(data)
            shown = self._csv_status_display(data)
            cell = self.csv_manager_table.item(r, 6)
            if cell is None:
                cell = QTableWidgetItem(shown)
                cell.setFlags(cell.flags() & ~Qt.ItemIsEditable)
                self.csv_manager_table.setItem(r, 6, cell)
            else:
                cell.setText(shown)
            cell.setData(Qt.UserRole + 1, expired)
        self.filter_csv_manager_rows()

    def _csv_status_display(self, row):
        """返回 CSV 管理表应显示的状态；当天运行结果优先，过期状态最高优先级。"""
        if self._csv_row_is_expired(row):
            return "已过期"
        # CSV 是状态唯一真实来源；运行完成后状态会直接写回 CSV，
        # 重启软件也继续读取 CSV 中保存的状态。
        status = str(row.get("status", "") or "未运行").strip() or "未运行"
        if status == "跳过：已过期":
            return "已过期"
        if status == "跳过：密码为空" or status == "跳过：空密码" or status.startswith("跳过："):
            return "跳过"
        if status in ("成功", "完成"):
            return "登录成功"
        if status.startswith("失败：") or status == "失败":
            return "登录失败"
        return status

    def _same_csv_path(self, a, b):
        """比较两个 CSV 路径，兼容大小写、相对路径与规范化路径差异。"""
        if not a or not b:
            return False
        try:
            return os.path.normcase(os.path.abspath(os.path.normpath(str(a)))) == os.path.normcase(os.path.abspath(os.path.normpath(str(b))))
        except Exception:
            return str(a).strip().casefold() == str(b).strip().casefold()

    def clear_csv_manager_filter(self):
        if not hasattr(self, "csv_account_search"):
            return
        self.csv_account_search.clear()
        self.csv_status_filter.blockSignals(True)
        self.csv_status_filter.setCurrentIndex(0)
        self.csv_status_filter.blockSignals(False)
        self.refresh_csv_manager_from_disk()

    def on_csv_status_filter_changed(self, value):
        """切回“全部”时从磁盘重新扫描当前 CSV，确保被隐藏的行和数据源都完全恢复。"""
        if str(value).strip() == "全部":
            self.refresh_csv_manager_from_disk()
        else:
            self.filter_csv_manager_rows()

    def refresh_csv_manager_from_disk(self):
        path = self.csv_manage_path.text().strip() if hasattr(self, "csv_manage_path") else ""
        if not path:
            return
        try:
            rows = load_rows(path)
            self.load_csv_manager_from_rows(rows)
            self._refresh_csv_manager_daily_results()
            self.csv_manager_status.setText(f"已刷新：{Path(path).name}")
        except Exception as exc:
            QMessageBox.critical(self, "刷新 CSV 失败", str(exc))

    def filter_csv_manager_rows(self, text=None):
        """按原始数据统一计算可见状态；“全部”时已由状态切换处理器先从磁盘刷新。"""
        if not hasattr(self, "csv_manager_table"):
            return
        query = str(text if text is not None else self.csv_account_search.text()).strip().casefold()
        status_filter = self.csv_status_filter.currentText() if hasattr(self, "csv_status_filter") else "全部"
        rows = getattr(self, "_csv_manager_rows", [])
        table_rows = self.csv_manager_table.rowCount()
        # 先无条件恢复所有现有行，彻底清除上一次筛选留下的 hidden 状态。
        for row in range(table_rows):
            self.csv_manager_table.setRowHidden(row, False)
        matched = 0
        total = len(rows)
        for row, data in enumerate(rows):
            if row >= table_rows:
                break
            display_status = self._csv_status_display(data)
            values = [
                str(data.get("account", "")),
                str(data.get("password", "")),
                str(data.get("create_time", "")),
                str(data.get("expire_time", "")),
                str(data.get("update_time", "")),
                str(data.get("remark", "")),
                display_status,
            ]
            text_ok = (not query) or any(query in value.casefold() for value in values)
            status_ok = (status_filter == "全部") or (status_filter == display_status)
            visible = text_ok and status_ok
            self.csv_manager_table.setRowHidden(row, not visible)
            if visible:
                matched += 1
        for row in range(total, table_rows):
            self.csv_manager_table.setRowHidden(row, True)
        self._set_table_search_result(getattr(self, "csv_search_result", None), matched, total)

    def refresh_csv_project_list(self):
        if not hasattr(self, 'csv_project_list'):
            return
        current = self.csv_project_list.currentItem().text() if self.csv_project_list.currentItem() else ''
        self.csv_project_list.blockSignals(True)
        self.csv_project_list.clear()
        for item in self.csv_project_store.data:
            self.csv_project_list.addItem(item.get('name', '未命名'))
        self.csv_project_list.blockSignals(False)
        if current:
            for i in range(self.csv_project_list.count()):
                if self.csv_project_list.item(i).text() == current:
                    self.csv_project_list.setCurrentRow(i); return
        if self.csv_project_list.count():
            self.csv_project_list.setCurrentRow(0)
        elif hasattr(self, 'csv_project_name'):
            self.csv_project_name.clear(); self.csv_manage_path.clear(); self.csv_manager_table.setRowCount(0)

    def move_csv_project(self, delta):
        row = self.csv_project_list.currentRow()
        target = row + int(delta)
        if row < 0 or target < 0 or target >= len(self.csv_project_store.data):
            return
        self.csv_project_store.data[row], self.csv_project_store.data[target] = (
            self.csv_project_store.data[target], self.csv_project_store.data[row]
        )
        self.csv_project_store.save()
        current_name = self.csv_project_store.data[target].get('name', '')
        self.refresh_csv_project_list()
        for i in range(self.csv_project_list.count()):
            if self.csv_project_list.item(i).text() == current_name:
                self.csv_project_list.setCurrentRow(i)
                break
        self.csv_manager_info.setText(f"已调整 CSV 项目顺序：{current_name}")

    def load_csv_project_editor(self, row):
        if row < 0 or row >= len(self.csv_project_store.data): return
        item = self.csv_project_store.data[row]
        self.csv_project_name.setText(item.get('name', ''))
        self.csv_manage_path.setText(item.get('path', ''))
        self.load_csv_manager()

    def new_csv_project(self):
        name, ok = QInputDialog.getText(self, '新建 CSV 项目', '项目标题：')
        if not ok or not name.strip(): return
        path, _ = QFileDialog.getOpenFileName(self, '选择 CSV / TSV', '', '账号文件 (*.csv *.tsv);;所有文件 (*)')
        if not path: return
        try:
            self.csv_project_store.add_or_update(name, path)
            self.refresh_csv_project_list()
            for i in range(self.csv_project_list.count()):
                if self.csv_project_list.item(i).text() == name.strip():
                    self.csv_project_list.setCurrentRow(i); break
        except Exception as e:
            QMessageBox.critical(self, '保存 CSV 项目失败', str(e))

    def save_csv_project(self):
        name = self.csv_project_name.text().strip()
        path = self.csv_manage_path.text().strip()
        old = self.csv_project_list.currentItem().text() if self.csv_project_list.currentItem() else None
        try:
            self.csv_project_store.add_or_update(name, path, old_name=old)
            self.refresh_csv_project_list()
            for i in range(self.csv_project_list.count()):
                if self.csv_project_list.item(i).text() == name:
                    self.csv_project_list.setCurrentRow(i); break
            self.csv_manager_info.setText(f"项目‘{name}’已保存。")
        except Exception as e:
            QMessageBox.warning(self, '保存 CSV 项目', str(e))

    def delete_csv_project(self):
        item = self.csv_project_list.currentItem()
        if not item: return
        name = item.text()
        if QMessageBox.question(self, '删除 CSV 项目', f'确定删除项目‘{name}’吗？\n不会删除磁盘上的 CSV 文件。', QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self.csv_project_store.delete(name)
        self.refresh_csv_project_list()

    def choose_csv_manage(self):
        p, _ = QFileDialog.getOpenFileName(self, "选择 CSV", "", "账号文件 (*.csv *.tsv);;所有文件 (*)")
        if p:
            self.csv_manage_path.setText(p)
            self.load_csv_manager()

    def open_selected_csv_file(self):
        path = self.csv_manage_path.text().strip() if hasattr(self, "csv_manage_path") else ""
        if not path:
            QMessageBox.information(self, "打开 CSV 文件", "请先在左侧选择 CSV 项目，或选择一个 CSV / TSV 文件。")
            return
        if not os.path.isfile(path):
            QMessageBox.warning(self, "打开 CSV 文件", f"文件不存在：\n{path}")
            return
        try:
            os.startfile(os.path.abspath(path))
            self.csv_manager_status.setText(f"已打开：{Path(path).name}")
        except Exception as e:
            QMessageBox.critical(self, "打开 CSV 文件失败", str(e))

    def load_csv_manager(self):
        path = self.csv_manage_path.text().strip()
        if not path:
            return
        try:
            rows = load_rows(path)
            self.load_csv_manager_from_rows(rows)
            self._refresh_csv_manager_daily_results()
            self.csv_manager_info.setText(f"已读取 {len(rows)} 个账号；状态列显示今日运行结果（当天有结果时优先显示）。")
            self.csv_manager_status.setText(f"已自动读取：{Path(path).name}")
        except Exception as e:
            QMessageBox.critical(self, "CSV读取失败", str(e))

    def add_csv_account(self):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        dlg = AccountEditDialog(self, {"create_time": now, "update_time": now})
        if dlg.exec() != QDialog.Accepted:
            return
        row = dlg.get_row()
        row["status"] = str(row.get("status", "未运行") or "未运行").strip() or "未运行"
        if not row["account"]:
            QMessageBox.warning(self, "添加账号", "账号不能为空。")
            return
        if not row["create_time"]:
            row["create_time"] = now
        row["update_time"] = now
        self._csv_manager_rows.append(row)
        self.load_csv_manager_from_rows(self._csv_manager_rows)
        new_row_index = self.csv_manager_table.rowCount() - 1
        self.csv_manager_table.selectRow(new_row_index)
        # 添加账号与双击编辑保持一致：在“添加账号”对话框点击“保存”后，立即写回当前 CSV。
        try:
            self._save_csv_manager_rows_direct()
            self.csv_manager_info.setText(f"账号“{row['account']}”已添加并直接保存到 CSV。")
        except Exception as e:
            # 内存中的新账号保留，但明确告知磁盘写入失败，避免用户误以为已经保存。
            self.csv_manager_info.setText("账号已添加到当前列表，但写入 CSV 失败。")
            QMessageBox.critical(self, "保存 CSV 失败", str(e))

    def _csv_row_is_expired(self, row):
        class _Row:
            pass
        x = _Row()
        x.expire_time = str(row.get("expire_time", ""))
        return is_expired(x)

    def load_csv_manager_from_rows(self, rows):
        self._csv_manager_rows = [dict(x) for x in rows]
        self.csv_manager_table.setRowCount(len(self._csv_manager_rows))
        keys = ["account", "password", "create_time", "expire_time", "update_time", "remark", "status"]
        for r, row in enumerate(self._csv_manager_rows):
            expired = self._csv_row_is_expired(row)
            for c, key in enumerate(keys):
                raw_value = str(row.get(key, ""))
                if key == "status" and expired:
                    value = "已过期"
                elif key == "password" and not self.csv_show_password.isChecked():
                    value = "*" * max(4, len(raw_value)) if raw_value else ""
                else:
                    value = raw_value
                item = QTableWidgetItem(value)
                if c != 5:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                item.setData(Qt.UserRole + 1, expired)
                if key == "password":
                    item.setData(Qt.UserRole + 2, raw_value)
                self.csv_manager_table.setItem(r, c, item)
        self.csv_total_control.setText(f"总账号：{len(self._csv_manager_rows)}")
        self.filter_csv_manager_rows()

    def edit_csv_account(self, row=None):
        if row is None:
            row = self.csv_manager_table.currentRow()
        if row is None or row < 0 or row >= self.csv_manager_table.rowCount():
            return
        data = self._csv_manager_rows[row]
        dlg = AccountEditDialog(self, data)
        if dlg.exec() != QDialog.Accepted:
            return
        updated = dict(data)
        updated.update(dlg.get_row())
        updated["status"] = str(updated.get("status", data.get("status", "未运行")) or "未运行").strip() or "未运行"
        if not updated["account"]:
            QMessageBox.warning(self, "编辑账号", "账号不能为空。")
            return
        updated["update_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self._csv_manager_rows[row] = updated
        self.load_csv_manager_from_rows(self._csv_manager_rows)
        self.csv_manager_table.selectRow(row)
        # 双击编辑并确认保存后，直接写回当前 CSV，不再要求用户额外点击“保存到 CSV”。
        try:
            self._save_csv_manager_rows_direct()
            self.csv_manager_info.setText(f"账号“{updated['account']}”已修改并直接保存到 CSV。")
        except Exception as e:
            self.csv_manager_info.setText("账号已修改，但写入 CSV 失败。")
            QMessageBox.critical(self, "保存 CSV 失败", str(e))

    def _csv_selected_row(self):
        if not hasattr(self, "csv_manager_table"):
            return -1
        row = self.csv_manager_table.currentRow()
        if 0 <= row < len(getattr(self, "_csv_manager_rows", [])):
            return row
        try:
            selected = self.csv_manager_table.selectionModel().selectedRows()
            if selected:
                row = selected[0].row()
                if 0 <= row < len(self._csv_manager_rows):
                    return row
        except Exception:
            pass
        return -1

    def copy_selected_csv_account(self):
        row = self._csv_selected_row()
        if row < 0:
            QMessageBox.information(self, "复制账号", "请先选择一个账号。")
            return
        account = str(self._csv_manager_rows[row].get("account", ""))
        QApplication.clipboard().setText(account)
        self.csv_manager_status.setText(f"已复制账号：{account}")

    def copy_selected_csv_password(self):
        row = self._csv_selected_row()
        if row < 0:
            QMessageBox.information(self, "复制密码", "请先选择一个账号。")
            return
        password = str(self._csv_manager_rows[row].get("password", ""))
        QApplication.clipboard().setText(password)
        account = str(self._csv_manager_rows[row].get("account", ""))
        self.csv_manager_status.setText(f"已复制账号“{account}”的密码。")

    def toggle_csv_password_display(self, checked):
        # 只改变界面显示，不修改 CSV 中保存的真实密码。
        rows = getattr(self, "_csv_manager_rows", [])
        for r, data in enumerate(rows):
            item = self.csv_manager_table.item(r, 1) if hasattr(self, "csv_manager_table") else None
            if item is None:
                continue
            password = str(data.get("password", ""))
            item.setText(password if checked else ("*" * max(4, len(password)) if password else ""))
        self.filter_csv_manager_rows()

    def delete_csv_account(self):
        row = self.csv_manager_table.currentRow()
        if row < 0 or row >= len(getattr(self, "_csv_manager_rows", [])):
            return
        account = self._csv_manager_rows[row].get("account", "")
        if QMessageBox.question(self, "删除账号", f"确定删除账号“{account}”吗？") != QMessageBox.Yes:
            return
        self._csv_manager_rows.pop(row)
        self.load_csv_manager_from_rows(self._csv_manager_rows)
        self.csv_manager_info.setText("已删除账号；点击‘保存到 CSV’后写入文件。")

    def adjust_selected_expire(self, days):
        row = self.csv_manager_table.currentRow()
        if row < 0 or row >= len(getattr(self, "_csv_manager_rows", [])):
            QMessageBox.information(self, "到期时间", "请先选择一个账号。")
            return
        text = self._csv_manager_rows[row].get("expire_time", "").strip()
        base = None
        formats = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
                   "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d"]
        for fmt in formats:
            try:
                base = datetime.strptime(text, fmt)
                break
            except ValueError:
                pass
        if base is None:
            base = datetime.now()
        target = base + timedelta(days=days)
        self._csv_manager_rows[row]["expire_time"] = target.strftime("%Y-%m-%d %H:%M:%S")
        self._csv_manager_rows[row]["update_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.load_csv_manager_from_rows(self._csv_manager_rows)
        self.csv_manager_table.selectRow(row)
        self.csv_manager_info.setText(f"账号“{self._csv_manager_rows[row]['account']}”到期时间已增加 {days} 天；记得保存。")

    def move_csv_row(self, delta):
        row = self.csv_manager_table.currentRow()
        target = row + delta
        if row < 0 or not (0 <= target < self.csv_manager_table.rowCount()):
            return
        # 同时更新内存数据，避免移动后双击编辑拿到旧账号。
        self._csv_manager_rows[row], self._csv_manager_rows[target] = (
            self._csv_manager_rows[target], self._csv_manager_rows[row]
        )
        self.load_csv_manager_from_rows(self._csv_manager_rows)
        self.csv_manager_table.selectRow(target)
        self.csv_manager_info.setText("账号顺序已调整；点击‘保存到 CSV’后写回文件。")

    def batch_set_csv_status(self):
        rows=[i.row() for i in self.csv_manager_table.selectionModel().selectedRows()]
        if not rows:
            QMessageBox.information(self,"批量设置状态","请先多选账号。")
            return
        status,ok=QInputDialog.getItem(self,"批量设置状态","新状态：",["未运行","登录成功","登录失败","密码错误","封禁","跳过","自定义"],0,False)
        if not ok:return
        if status=="自定义":
            status,ok=QInputDialog.getText(self,"自定义状态","状态名称：")
            if not ok or not status.strip():return
        for r in rows:
            if 0<=r<len(self._csv_manager_rows): self._csv_manager_rows[r]["status"]=status.strip()
        self.load_csv_manager_from_rows(self._csv_manager_rows)
        self.csv_manager_info.setText(f"已批量设置 {len(rows)} 个账号状态：{status.strip()}；保存后写回 CSV。")

    def _save_csv_manager_rows_direct(self):
        """把当前 CSV 管理器内存数据直接写回当前文件。"""
        path = self.csv_manage_path.text().strip()
        if not path:
            raise ValueError("请先选择 CSV 文件。")
        if self.running and self._same_csv_path(path, self.csv.text().strip()):
            raise RuntimeError("当前正在运行该 CSV，运行期间禁止修改并保存账号文件。")
        save_rows(path, self._csv_manager_rows)
        self.memory.save_settings(last_csv=path)
        if os.path.abspath(path) == os.path.abspath(self.csv.text().strip()):
            self.load_csv(show_message=False, restore_range=False)

    def save_csv_manager(self):
        path = self.csv_manage_path.text().strip()
        if not path:
            return
        try:
            self._save_csv_manager_rows_direct()
            self.csv_manager_info.setText(f"已保存：{len(self._csv_manager_rows)} 个账号。顺序和备注已经写回 CSV。")
        except Exception as e:
            QMessageBox.critical(self, "CSV保存失败", str(e))

    # =========================
    # 范围与定时启动
    # =========================

    def update_range_labels(self):
        total = len(self.accounts)
        start = self.range_start.value() if hasattr(self, "range_start") else 1
        end = self.range_end.value() if hasattr(self, "range_end") else 0
        self.range_total_label.setText(f"总数：{total}")
        self.range_selected_label.setText(f"本次：{max(0, end-start+1) if total else 0} 个")

    def _next_schedule_datetime(self):
        now=QDateTime.currentDateTime()
        t=self.schedule_time.time()
        dt=QDateTime(now.date(), t)
        if dt <= now:
            dt=dt.addDays(1)
        return dt

    def _update_schedule_label(self):
        if not self.schedule_enable.isChecked():
            self.schedule_label.setText("定时状态：未设置")
            return
        dt=self._scheduled_target or self._next_schedule_datetime()
        day="今天" if dt.date()==QDate.currentDate() else "明天"
        self.schedule_label.setText(f"定时状态：{day} {dt.toString('HH:mm')} 启动")

    def on_schedule_time_changed(self, *args):
        if getattr(self, '_restoring_memory', False):
            return
        if self.schedule_enable.isChecked():
            self._scheduled_target=self._next_schedule_datetime()
            self.memory.save_settings(schedule_enabled=True, schedule_time=self.schedule_time.time().toString("HH:mm"))
            self._update_schedule_label()

    def on_schedule_changed(self, state):
        if state:
            self.schedule_fired=False
            self._scheduled_target=self._next_schedule_datetime()
            self.schedule_label.setText(f"定时状态：{'今天' if self._scheduled_target.date()==QDate.currentDate() else '明天'} {self._scheduled_target.toString('HH:mm')} 启动")
            self.memory.save_settings(schedule_enabled=True, schedule_time=self.schedule_time.time().toString("HH:mm"))
        else:
            self.cancel_schedule()

    def cancel_schedule(self):
        if hasattr(self,'schedule_enable'):
            self.schedule_enable.blockSignals(True); self.schedule_enable.setChecked(False); self.schedule_enable.blockSignals(False)
        self.schedule_fired=False
        self._scheduled_target=None
        self.schedule_label.setText("定时状态：未设置")
        if hasattr(self,'memory'): self.memory.save_settings(schedule_enabled=False)

    def _check_daily_csv_status_reset(self):
        if self.running:
            return False
        """以 CSV 文件的最后修改日期作为每日状态日期。

        规则：
        1. CSV 文件修改日期 == 今天：保持 CSV 中现有 status，不做任何重置。
        2. CSV 文件修改日期 != 今天：把全部账号 status 重置为“未运行”，
           保存 CSV 后文件修改日期自然更新为今天。

        因此不需要额外的 reset_dates 记录文件，CSV 本身就是唯一状态来源。
        """
        csv_path = ""
        try:
            csv_path = self.csv.text().strip() if hasattr(self, "csv") else ""
        except Exception:
            csv_path = ""
        if not csv_path or not os.path.isfile(csv_path):
            return False

        try:
            path = Path(csv_path)
            today = datetime.now().date()
            file_date = datetime.fromtimestamp(path.stat().st_mtime).date()

            # 文件今天已经被保存过：说明今天的状态是当前状态，绝不清除。
            if file_date == today:
                return False

            rows = load_rows(csv_path)
            for row in rows:
                row["status"] = "未运行"

            # 保存后 CSV 的修改时间会更新为当前时间，作为今天的“状态日期”。
            save_rows(csv_path, rows)

            key = self._csv_daily_key(csv_path)
            with self._csv_daily_lock:
                self._csv_daily_results.pop(key, None)
                self._save_csv_daily_results(self._csv_daily_results)

            # 如果当前界面正在显示这个 CSV，立即刷新。
            if hasattr(self, "csv_manage_path") and self.csv_manage_path.text().strip() == csv_path:
                self.load_csv_manager()
            if hasattr(self, "csv") and self.csv.text().strip() == csv_path:
                self.load_csv(show_message=False, restore_range=False)

            self.write_log(
                f"每日状态重置完成：{Path(csv_path).name}，"
                f"CSV文件日期 {file_date.strftime('%Y-%m-%d')} → {today.strftime('%Y-%m-%d')}，"
                f"共 {len(rows)} 个账号 → 未运行"
            )
            return True
        except Exception as e:
            self.write_log(f"每日状态重置失败：{e}")
            return False

    def check_schedule(self):
        # 每秒检查一次日期；跨过 00:00 时只会对当前 CSV 执行一次重置。
        self._check_daily_csv_status_reset()
        # 旧版定时启动：勾选代表“持续启用”，到点后执行一次并自动安排下一次，绝不自动取消勾选。
        if hasattr(self,'schedule_enable') and self.schedule_enable.isChecked() and not self.running:
            if self._scheduled_target is None: self._scheduled_target=self._next_schedule_datetime()
            if QDateTime.currentDateTime() >= self._scheduled_target:
                # 先计算下一次触发点，再进入 start()，避免模态提示框产生嵌套事件循环时重复触发。
                self._scheduled_target = self._next_schedule_datetime()
                self.schedule_label.setText("定时状态：已触发，正在启动；下次仍按此时间运行")
                self.memory.save_settings(schedule_enabled=True, schedule_time=self.schedule_time.time().toString("HH:mm"))
                self.start()
                self.schedule_fired = False
                self._update_schedule_label()
                return
        # 3.0 高级调度
        if self.running: return
        sc=getattr(self,'_advanced_schedule',{}) or {}
        if not sc.get('enabled'): return
        try:
            target=QDateTime.fromString(str(sc.get('when','')),Qt.DateFormat.ISODate)
            if not target.isValid(): return
            now=QDateTime.currentDateTime()
            if now < target: return
            # 先推进计划时间，再启动任务，避免 start() 弹出模态框时 1 秒定时器重入重复启动。
            mode=sc.get('mode','仅一次')
            if mode=='仅一次': sc['enabled']=False
            elif mode=='每天':
                while target <= now: target=target.addDays(1)
                sc['when']=target.toString(Qt.DateFormat.ISODate)
            elif mode=='每小时':
                while target <= now: target=target.addSecs(3600)
                sc['when']=target.toString(Qt.DateFormat.ISODate)
            else:
                step=max(1,int(sc.get('repeat_interval',30)))*60
                while target <= now: target=target.addSecs(step)
                sc['when']=target.toString(Qt.DateFormat.ISODate)
            self._advanced_schedule=sc; self._save_advanced_schedule()
            self.write_log('高级调度到点，开始启动当前运行任务。'); self.start(scheduler_options=sc)
        except Exception as e: self.write_log('高级调度检查失败：'+str(e))
        return

    # =========================
    # 工作流
    # =========================

    def set_all_range(self):
        """一键将运行范围设为全部账号；右侧结束序号自动填入最大账号数。"""
        total = len(self.accounts)
        if total <= 0:
            # 尚未读取账号时，不擅自猜测最大值。
            return
        self.range_start.blockSignals(True)
        self.range_end.blockSignals(True)
        try:
            self.range_start.setValue(1)
            self.range_end.setValue(total)
        finally:
            self.range_start.blockSignals(False)
            self.range_end.blockSignals(False)
        self.update_range_labels()
        if not self._restoring_memory:
            self.save_current_memory()

    def fix_range(self):
        if self.range_start.value() > self.range_end.value():
            self.range_end.setValue(self.range_start.value())
        self.update_range_labels()
        if not self._restoring_memory:
            self.save_current_memory()

    def refresh_workflows(self):
        current_path = self.current_workflow_path or self.memory.settings.get("last_workflow")
        paths = self.store.list()

        self.workflow_combo.blockSignals(True)
        self.workflow_combo.clear()

        for p in paths:
            self.workflow_combo.addItem(p.stem, str(p))

        if current_path:
            for i in range(self.workflow_combo.count()):
                if self.workflow_combo.itemData(i) == str(current_path):
                    self.workflow_combo.setCurrentIndex(i)
                    self.current_workflow_path = str(current_path)
                    break

        self.workflow_combo.blockSignals(False)
        self.refresh_wf_list()

    def refresh_wf_list(self):
        if not hasattr(self, "wf_list"):
            return

        current_path = self.current_workflow_path
        paths = self.store.list()

        self.wf_list.clear()
        for p in paths:
            self.wf_list.addItem(p.stem)

        if current_path:
            for i, p in enumerate(paths):
                if str(p) == current_path:
                    self.wf_list.setCurrentRow(i)
                    return

    def move_workflow(self, delta):
        paths = self.store.list()
        row = self.wf_list.currentRow()
        target = row + int(delta)
        if row < 0 or target < 0 or target >= len(paths):
            return
        paths[row], paths[target] = paths[target], paths[row]
        self.store.set_order(paths)
        current_path = str(paths[target])
        self.refresh_workflows()
        self.refresh_wf_list()
        for i, path in enumerate(self.store.list()):
            if str(path) == current_path:
                self.wf_list.setCurrentRow(i)
                break
        self.write_log(f"已调整工作流顺序：{Path(current_path).stem}")

    def select_workflow(self, row):
        if row < 0:
            return

        paths = self.store.list()
        if row >= len(paths):
            return

        self.current_workflow_path = str(paths[row])

        try:
            data = self.store.load(paths[row])

            if self.editor:
                self.editor.deleteLater()
                self.editor = None

            self.editor = WorkflowEditor(data)
            while self.editor_layout.count():
                item = self.editor_layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()

            self.editor_layout.addWidget(self.editor)

            if not self._restoring_memory:
                self.memory.save_settings(last_workflow=self.current_workflow_path)
                self.save_current_memory()

        except Exception as e:
            QMessageBox.critical(self, "工作流错误", str(e))

    def new_workflow(self):
        name, ok = QInputDialog.getText(self, "新建工作流", "请输入工作流名称：")
        if not ok or not name.strip():
            return

        name = name.strip()
        p = self.store.save(name, {"name": name, "steps": []})
        self.current_workflow_path = str(p)

        self.refresh_workflows()
        paths = self.store.list()
        for i, path in enumerate(paths):
            if str(path) == str(p):
                self.wf_list.setCurrentRow(i)
                break

    def save_workflow(self):
        if not self.editor:
            return
        data = self.editor.get_data()
        if self.current_workflow_path:
            try:
                self.store.backup(self.current_workflow_path)
            except Exception:
                pass
            with open(self.current_workflow_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.write_log("工作流已保存：" + data.get("name", ""))
            self.refresh_wf_list()
        else:
            self.save_as_workflow()

    def save_as_workflow(self):
        if not self.editor:
            return
        data = self.editor.get_data()
        name, ok = QInputDialog.getText(
            self, "另存为", "请输入工作流名称：",
            text=data.get("name", "新工作流")
        )
        if not ok or not name.strip():
            return
        data["name"] = name.strip()
        p = self.store.save(name, data, overwrite=False)
        self.current_workflow_path = str(p)
        if self.editor:
            self.editor.data["name"] = p.stem
            self.editor.name_edit.setText(p.stem)
        self.refresh_wf_list()
        self.refresh_workflows()

    def import_workflow(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "导入工作流", "", "JSON 工作流 (*.json)"
        )
        if not p:
            return
        try:
            data = self.store.load(p)
            name, ok = QInputDialog.getText(
                self, "导入工作流", "保存为：",
                text=data.get("name", Path(p).stem)
            )
            if ok and name.strip():
                self.store.save(name, data)
                self.refresh_wf_list()
                self.refresh_workflows()
        except Exception as e:
            QMessageBox.critical(self, "导入失败", str(e))

    def rename_workflow(self):
        row = self.wf_list.currentRow()
        paths = self.store.list()
        if row < 0 or row >= len(paths):
            QMessageBox.information(self, "重命名工作流", "请先在左侧选择一个工作流。")
            return
        old_path = paths[row]
        try:
            data = self.store.load(old_path)
        except Exception as e:
            QMessageBox.critical(self, "重命名失败", f"读取工作流失败：{e}")
            return
        old_name = str(data.get("name") or old_path.stem)
        name, ok = QInputDialog.getText(self, "重命名工作流", "新的工作流名称：", text=old_name)
        if not ok or not name.strip():
            return
        name = name.strip()
        safe = "".join(c for c in name if c not in r'\/:*?"<>|')
        if not safe:
            QMessageBox.warning(self, "重命名失败", "工作流名称不能为空或只包含 Windows 不允许的文件名字符。")
            return
        new_path = old_path.with_name(safe + ".json")
        if new_path != old_path and new_path.exists():
            QMessageBox.warning(self, "重命名失败", f"工作流“{safe}”已经存在，请换一个名称。")
            return
        try:
            data["name"] = safe
            old_order = self.store.list()
            old_path.rename(new_path)
            new_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            renamed_order = [new_path if Path(x) == old_path else x for x in old_order]
            self.store.set_order(renamed_order)
            self.current_workflow_path = str(new_path)
            if self.editor:
                self.editor.data["name"] = safe
                self.editor.name_edit.setText(safe)
            self.refresh_workflows()
            self.write_log(f"工作流已重命名：{old_name} → {safe}")
        except Exception as e:
            QMessageBox.critical(self, "重命名失败", str(e))

    def translate_workflow_steps(self):
        if not self.editor:
            QMessageBox.information(self, "步骤中文化", "请先打开一个工作流。")
            return
        aliases = {
            "sleep": "wait", "delay": "wait", "wait_seconds": "wait",
            "findwindow": "find_window", "findWindow": "find_window",
            "findchild": "find_child", "findChild": "find_child",
            "settext": "set_text", "setText": "set_text",
            "sendkey": "send_key", "sendKey": "send_key",
            "closewindow": "close_window", "closeWindow": "close_window",
            "checkkeyword": "check_keyword", "checkKeyword": "check_keyword",
            "waitkeyword": "wait_keyword", "waitKeyword": "wait_keyword",
            "waitcondition": "wait_condition", "waitCondition": "wait_condition",
            "ifcondition": "if_condition", "ifCondition": "if_condition",
            "ifwindowexists": "if_window_exists", "ifWindowExists": "if_window_exists",
            "setstatus": "set_status", "setStatus": "set_status",
            "setvariable": "set_variable", "setVariable": "set_variable",
            "write_log": "log", "writeLog": "log",
        }
        changed = 0
        for step in self.editor.data.get("steps", []):
            if not isinstance(step, dict):
                continue
            old = str(step.get("action", "")).strip()
            new = aliases.get(old, aliases.get(old.lower()))
            if new and new != old:
                step["action"] = new
                changed += 1
        self.editor.refresh()
        if changed:
            self.save_workflow()
            QMessageBox.information(self, "步骤中文化", f"已统一翻译/转换 {changed} 个工作流步骤。\n\n步骤的执行逻辑没有改变。")
        else:
            QMessageBox.information(self, "步骤中文化", "当前工作流的步骤已经是标准步骤名称，无需转换。")

    def copy_workflow(self):
        row = self.wf_list.currentRow()
        paths = self.store.list()
        if row < 0 or row >= len(paths):
            QMessageBox.information(self, "复制工作流", "请先在左侧选择一个工作流。")
            return
        src = paths[row]
        try:
            data = self.store.load(src)
            old = str(data.get("name") or src.stem)
            name, ok = QInputDialog.getText(self, "复制工作流", "复制后的工作流名称：", text=f"{old} - 副本")
            if not ok or not name.strip():
                return
            dest = self.store.save(name.strip(), data, overwrite=False)
            self.current_workflow_path = str(dest)
            self.refresh_workflows()
            self.write_log(f"工作流已复制：{old} → {dest.stem}")
        except Exception as e:
            QMessageBox.critical(self, "复制失败", str(e))

    def export_current_workflow(self):
        row = self.wf_list.currentRow()
        paths = self.store.list()
        if row < 0 or row >= len(paths):
            QMessageBox.information(self, "导出工作流", "请先选择一个工作流。")
            return
        src = paths[row]
        out, _ = QFileDialog.getSaveFileName(self, "导出工作流", src.name, "工作流 JSON (*.json)")
        if not out:
            return
        try:
            Path(out).write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            self.write_log(f"工作流已导出：{out}")
        except Exception as e:
            QMessageBox.critical(self, "导出失败", str(e))

    def export_all_workflows(self):
        paths = self.store.list()
        if not paths:
            QMessageBox.information(self, "导出全部", "当前没有可导出的工作流。")
            return
        out, _ = QFileDialog.getSaveFileName(self, "导出全部工作流", "全部工作流.zip", "工作流包 (*.zip)")
        if not out:
            return
        try:
            self.store.export_zip(paths, out)
            self.write_log(f"已导出全部工作流：{out}（{len(paths)} 个）")
        except Exception as e:
            QMessageBox.critical(self, "导出失败", str(e))

    def import_workflows(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "导入工作流", "", "工作流文件 (*.json *.zip);;JSON 工作流 (*.json);;工作流包 (*.zip)"
        )
        if not files:
            return
        try:
            imported = []
            for f in files:
                if Path(f).suffix.lower() == ".zip":
                    imported.extend(self.store.import_zip(f))
                else:
                    imported.extend(self.store.import_files([f]))
            self.refresh_workflows()
            QMessageBox.information(self, "导入完成", f"成功导入 {len(imported)} 个工作流。")
        except Exception as e:
            QMessageBox.critical(self, "导入失败", str(e))

    def workflow_checker(self):
        if not self.editor:
            QMessageBox.information(self, "工作流检查器", "请先打开一个工作流。")
            return
        data = self.editor.get_data()
        result = self.engine.validate_workflow(data)
        lines = [f"工作流：{data.get('name','未命名')}", f"步骤数：{len(data.get('steps', []))}", ""]
        if result.get("errors"):
            lines.append("❌ 错误：")
            lines.extend(f"  · {x}" for x in result["errors"])
        else:
            lines.append("✓ 基础结构检查通过")
        if result.get("warnings"):
            lines.append("\n⚠ 警告：")
            lines.extend(f"  · {x}" for x in result["warnings"])
        lines.append("\n检查项目：")
        lines.append("✓ 操作类型 / 句柄引用 / 条件结构")
        lines.append("✓ 复合 AND / OR / NOT 条件兼容")
        lines.append("✓ 工作流变量步骤兼容")
        QMessageBox.information(self, "工作流检查器", "\n".join(lines))

    def workflow_versions(self):
        path = self.current_workflow_path
        if not path:
            QMessageBox.information(self, "版本/备份", "请先选择一个工作流。")
            return
        versions = self.store.list_versions(path)
        if not versions:
            QMessageBox.information(self, "版本/备份", "当前工作流还没有历史备份。保存修改后会自动创建备份。")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("工作流版本 / 自动备份")
        dlg.resize(620, 420)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(f"工作流：{Path(path).stem}\n共 {len(versions)} 个历史版本（最新在前）"))
        lst = QListWidget()
        for v in versions:
            lst.addItem(v.stem)
        lay.addWidget(lst)
        row = QHBoxLayout()
        restore = QPushButton("恢复选中版本")
        close = QPushButton("关闭")
        row.addWidget(restore); row.addStretch(); row.addWidget(close)
        lay.addLayout(row)
        close.clicked.connect(dlg.reject)
        def do_restore():
            idx = lst.currentRow()
            if idx < 0:
                return
            if QMessageBox.question(dlg, "确认恢复", "恢复前会自动再备份当前版本，确定继续吗？") != QMessageBox.Yes:
                return
            try:
                self.store.restore_version(path, versions[idx])
                dlg.accept()
                self.select_workflow(self.wf_list.currentRow())
                self.write_log(f"已恢复工作流历史版本：{versions[idx].name}")
            except Exception as e:
                QMessageBox.critical(dlg, "恢复失败", str(e))
        restore.clicked.connect(do_restore)
        dlg.exec()

    def show_run_history(self):
        history = getattr(self, "_run_history", [])
        if not history:
            # 从持久化文件读取
            try:
                hp = Path(__file__).resolve().parent / "config" / "run_history.jsonl"
                if hp.exists():
                    history = [json.loads(x) for x in hp.read_text(encoding="utf-8").splitlines() if x.strip()][-500:]
            except Exception:
                history = []
        dlg = QDialog(self)
        dlg.setWindowTitle("运行历史")
        dlg.resize(900, 520)
        lay = QVBoxLayout(dlg)
        table = QTableWidget(0, 7)
        table.setHorizontalHeaderLabels(["时间", "账号", "工作流", "结果", "PID", "步骤", "错误/备注"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        for rec in reversed(history[-500:]):
            r=table.rowCount(); table.insertRow(r)
            safe_message = self._secret_redactor.redact(rec.get("message", "")) if hasattr(self, "_secret_redactor") else rec.get("message", "")
            vals=[rec.get("time",""),rec.get("account",""),rec.get("workflow",""),rec.get("result",""),rec.get("pid",""),rec.get("step",""),safe_message]
            for c,v in enumerate(vals): table.setItem(r,c,QTableWidgetItem(str(v)))
        lay.addWidget(table)
        close=QPushButton("关闭"); close.clicked.connect(dlg.accept); lay.addWidget(close)
        dlg.exec()

    def delete_workflow(self):
        row = self.wf_list.currentRow()
        paths = self.store.list()
        if row < 0:
            return
        p = paths[row]
        if QMessageBox.question(
            self, "确认删除", f"确定删除“{p.stem}”吗？"
        ) == QMessageBox.Yes:
            self.store.delete(p)
            if self.current_workflow_path == str(p):
                self.current_workflow_path = None
                self.editor = None
            self.refresh_workflows()

    # =========================
    # 账号
    # =========================

    def choose_exe(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "选择要启动的软件", "", "EXE 程序 (*.exe)"
        )
        if p:
            self.exe.setText(p)
            self.on_exe_changed()

    def choose_csv(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "选择账号文件", "", "账号文件 (*.csv *.tsv);;所有文件 (*)"
        )
        if p:
            self.csv.setText(p)
            self.on_csv_changed()

    def load_csv(self, show_message=True, restore_range=True):
        path = self.csv.text().strip()
        if not path:
            if show_message:
                QMessageBox.warning(self, "读取账号", "请先选择账号 CSV / TSV 文件。")
            return

        try:
            self.accounts, csv_report = load_accounts(path, with_report=True)
            self._secret_redactor.update(a.password for a in self.accounts)
            if csv_report.get("skipped_rows", 0):
                warning = (
                    f"CSV 容错读取：成功载入 {csv_report.get('loaded_rows', len(self.accounts))} 行，"
                    f"跳过 {csv_report['skipped_rows']} 行字段损坏/账号字段缺失的记录。"
                )
                if csv_report.get("skipped_lines"):
                    warning += " 涉及行号：" + ", ".join(map(str, csv_report["skipped_lines"][:20]))
                    if len(csv_report["skipped_lines"]) > 20:
                        warning += " 等"
                self.write_log_force("[CSV 数据告警] " + warning)
                if show_message:
                    QMessageBox.warning(self, "CSV 存在异常行", warning + "\n\n正常账号已继续载入；请检查原文件后再保存。")
            self.table.setSortingEnabled(False)
            self.table.clearContents()
            self.table.setRowCount(len(self.accounts))

            self.range_start.setMaximum(max(1, len(self.accounts)))
            self.range_end.setMaximum(max(1, len(self.accounts)))
            self.range_total_label.setText(f"总数：{len(self.accounts)}")

            if restore_range:
                self.range_start.setValue(1)
                self.range_end.setValue(len(self.accounts))

            for i, a in enumerate(self.accounts):
                password_text = a.password if self.show_run_password.isChecked() else ("*" * len(str(a.password)))
                vals = [
                    i + 1, a.account, password_text,
                    a.expire_time, a.remark
                ]
                for c, v in enumerate(vals):
                    self.table.setItem(i, c, QTableWidgetItem(str(v)))

                status = "已过期" if is_expired(a) else "待处理"
                self.table.setItem(
                    i, 4, QTableWidgetItem(f"{status} | {a.remark}")
                )
                expired = is_expired(a)
                for cc in range(self.table.columnCount()):
                    cell = self.table.item(i, cc)
                    if cell is not None:
                        cell.setData(Qt.UserRole + 1, expired)

            self.refresh_run_serials()
            self.filter_run_accounts()
            start = self.range_start.value()
            end = self.range_end.value()
            self.summary.setText(
                f"共读取 {len(self.accounts)} 个账号；当前运行范围："
                f"第 {start} ～ {end} 个"
            )
            self.write_log(f"成功读取 {len(self.accounts)} 个账号")

            if not self._restoring_memory:
                self.save_current_memory()

        except Exception as e:
            if show_message:
                QMessageBox.critical(self, "读取账号失败", str(e))
            else:
                self.write_log(f"读取账号失败：{e}")

    def update_row(self, row, status):
        if 0 <= row < len(self.accounts):
            a = self.accounts[row]
            status_text = str(status).strip()
            info, transition = self._status_tracker.update(int(row), status_text)
            cell = QTableWidgetItem(f"{status_text} | {a.remark}")
            severity_colors = {"success": "#15803d", "error": "#b91c1c", "warning": "#b45309",
                               "info": "#1d4ed8", "neutral": "#374151"}
            cell.setForeground(QBrush(QColor(severity_colors.get(info.severity, "#374151"))))
            cell.setToolTip(f"状态类别：{info.label}\n状态迁移：{transition['from']} → {transition['to']}\n迁移合法：{'是' if transition['valid_transition'] else '否（保留原状态，不阻断流程）'}")
            # 状态刷新会重建单元格；同步保留“已过期”标记，避免自定义代理
            # 在运行过程中刷新状态后丢失过期视觉提示。
            cell.setData(Qt.UserRole + 1, bool(is_expired(a)))
            self.table.setItem(row, 4, cell)
            # 运行中心只反馈当前执行状态，不在这里记录历史；CSV 管理器只记录最终的今日结果。
            # 正在处理的账号始终高亮，并自动滚动到可见区域。
            self.table.setCurrentCell(row, 0)
            self.table.selectRow(row)
            item = self.table.item(row, 0)
            if item is not None:
                self.table.scrollToItem(item, QAbstractItemView.PositionAtCenter)

    def refresh_run_password_display(self, *_):
        """仅刷新运行中心密码列的显示，不修改账号数据。"""
        if not hasattr(self, "table"):
            return
        for row, account in enumerate(self.accounts):
            if row >= self.table.rowCount():
                break
            text = str(account.password) if self.show_run_password.isChecked() else ("*" * len(str(account.password)))
            self.table.setItem(row, 2, QTableWidgetItem(text))

    def refresh_run_serials(self):
        """强制按当前表格行顺序重写序号，避免视觉上出现重复序号。"""
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item is None:
                item = QTableWidgetItem()
                self.table.setItem(row, 0, item)
            item.setText(str(row + 1))
            item.setTextAlignment(Qt.AlignCenter)
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)

    # =========================
    # 运行
    # =========================

    def write_log(self, msg):
        if not hasattr(self, "log"):
            return
        if str(msg).startswith("__RUN_STATS__:"):
            try:
                parts = str(msg).split(":",1)[1].split("|")
                if len(parts) == 5:
                    gen,a,b,c,d = parts
                    if int(gen) != int(getattr(self, "_run_stats_generation", 0)):
                        return
                else:
                    a,b,c,d = parts
                incoming = {"success":int(a),"failed":int(b),"skipped":int(c),"stopped":int(d)}
                for k,v in incoming.items():
                    self._run_stats[k] = max(int(self._run_stats.get(k,0)), int(v))
                self.refresh_run_stats()
            except Exception:
                pass
            return

        raw = self._secret_redactor.redact(str(msg).strip())
        level = self._classify_log_level(raw)
        line = f"[{time.strftime('%H:%M:%S')}] [{level}] {raw}"
        self._log_records.append({"level": level, "text": raw, "line": line})
        if len(self._log_records) > 5000:
            del self._log_records[:-5000]
        self._persist_log_record(line)
        self._capture_failure_screenshot(raw)

        # 简化输出仍保持原来的“只显示账号开始/结束”行为；后台日志文件仍保留完整信息。
        if hasattr(self, "simplify_output") and self.simplify_output.isChecked():
            start_match = re.search(r"^正在运行账号\s*(\d+)\s*/\s*(\d+)\s*登录账号：\s*(.+)$", raw)
            if start_match:
                run_no, total_no, account = start_match.groups()
                account = account.strip()
                key = f"start:{run_no}/{total_no}:{account}"
                if account and key not in self._simple_logged_accounts:
                    self._simple_logged_accounts.add(key)
                    self.log.append(f"[{time.strftime('%H:%M:%S')}] 正在运行账号 {run_no}/{total_no} 登录账号：{account}")
                return
            end_match = re.search(r"^运行结束：\s*(成功|失败)(?:\s+账号序号=(\d+)\s*/\s*(\d+))?(?:\s+登录账号：\s*(.*))?$", raw)
            if end_match:
                result, run_no, total_no, account = end_match.groups()
                suffix = f" {run_no}/{total_no}" if run_no and total_no else ""
                account_text = f" 登录账号：{account.strip()}" if account else ""
                self.log.append(f"[{time.strftime('%H:%M:%S')}] 运行结束：{result}{suffix}{account_text}")
            return

        level_filter = self.log_level_filter.currentText() if hasattr(self, "log_level_filter") else "全部等级"
        query = self.log_search.text().strip().casefold() if hasattr(self, "log_search") else ""
        if (level_filter == "全部等级" or level == level_filter) and (not query or query in raw.casefold()):
            self.log.append(line)

    def on_simplify_output_changed(self, state):
        # 简化模式只展示账号开始/结束；退出简化模式后可恢复完整会话日志。
        enabled = not bool(state)
        for name in ("log_level_filter", "log_search"):
            widget = getattr(self, name, None)
            if widget is not None:
                widget.setEnabled(enabled)
        if enabled:
            self.refresh_log_view()
        self.memory.save_settings(simplify_output=bool(state))

    def update_progress(self, a, b):
        self.setWindowTitle(
            f"句柄上号器 · 工作流平台 1.0  [{a}/{b}]"
        )
        # 运行时自动把账号表滚动到当前账号，用户无需手动拖滚动条。
        try:
            row = max(0, min(int(a) - 1, self.table.rowCount() - 1))
            if row >= 0:
                self.table.scrollToItem(self.table.item(row, 0), QAbstractItemView.PositionAtCenter)
        except Exception:
            pass

    def reverify_account(self):
        if self.running:
            QMessageBox.information(self, "正在运行", "运行过程中不能重新验证。")
            return
        dlg = AccountVerificationDialog(self)
        if dlg.exec() == QDialog.Accepted:
            self.verified = True
            self.verified_account = dlg.verified_account
            self.validation_status_label.setText(f"已验证：{self.verified_account}")
            self.validation_status_label.setStyleSheet("color:#15803d;font-weight:600;")

    def start(self, scheduler_options=None):
        if not self.require_verified():
            return
        if self.running:
            QMessageBox.information(self, "正在运行", "当前已经有一轮任务在运行。")
            return

        if not self.accounts:
            self.load_csv()
        if not self.accounts:
            return

        exe = self.exe.text().strip()
        csv_path = self.csv.text().strip()

        if not os.path.isfile(exe):
            QMessageBox.warning(self, "无法开始", "请选择有效的软件 EXE 文件。")
            return

        if not os.path.isfile(csv_path):
            QMessageBox.warning(self, "无法开始", "请选择有效的账号 CSV 文件。")
            return

        wfpath = self.workflow_combo.currentData()
        if not wfpath or not os.path.isfile(wfpath):
            QMessageBox.warning(
                self, "无法开始", "请先在“工作流工作台”创建并保存一套工作流。"
            )
            return

        start = self.range_start.value()
        end = self.range_end.value()
        if start < 1 or end > len(self.accounts) or start > end:
            QMessageBox.warning(self, "运行范围错误", "请填写有效的账号范围。")
            return

        try:
            workflow = self.store.load(wfpath)
        except Exception as e:
            QMessageBox.critical(self, "工作流读取失败", str(e))
            return
        if not isinstance(workflow, dict) or not isinstance(workflow.get("steps"), list) or not workflow.get("steps"):
            QMessageBox.warning(self, "工作流为空", "当前选择的工作流没有可执行步骤，请先在‘工作流工作台’添加步骤并保存。")
            return

        # 开始前静态检查：只检查配置，不触碰目标软件。明显错误直接阻止运行，
        # 潜在的分支句柄等提醒写入日志，避免误拦截合法的高级工作流。
        validation = self.engine.validate_workflow(workflow)
        if validation.get("errors"):
            QMessageBox.warning(
                self, "工作流检查未通过",
                "发现以下配置错误：\n\n" + "\n".join(f"• {x}" for x in validation["errors"])
            )
            return
        for warning in validation.get("warnings", []):
            self.write_log("工作流检查提醒：" + warning)

        # 重要：把 GUI 参数在主线程一次性取出来，后台线程不再直接访问 Qt 控件。
        options = {
            "start_wait": self.start_wait.value(),
            "interval": self.interval.value(),
            "skip_expired": self.skip_expired.isChecked(),
            "skip_empty": self.skip_empty.isChecked(),
            "concurrency": self.concurrency.value(),
        }

        self.save_current_memory()
        self.memory.save_runtime(
            exe, csv_path,
            workflow=wfpath,
            range_start=start,
            range_end=end,
            last_start_index=start,
        )

        self.stop_requested = False
        if not (scheduler_options or {}).get("automatic_process_retry"):
            self._auto_process_retry_round = 0
        self._run_locked_exe = exe
        self._run_locked_csv = csv_path
        self._run_locked_workflow_index = self.workflow_combo.currentIndex()
        self.running = True
        if hasattr(self, "process_check_btn"):
            self.process_check_btn.setEnabled(False)
        if self.lock_input_on_start.isChecked():
            try:
                self.input_lock.begin_session(locked=True)
            except Exception as e:
                self.running = False
                QMessageBox.warning(self, "键鼠锁定失败", f"无法启用全局键鼠锁定：\n{e}")
                return
        self._simple_logged_accounts.clear()
        # 新的独立批次必须清空上一批 PID/失败/主动结束记录；进程检测触发的 retry_accounts
        # 不经过此处，因此重跑仍保留原记录并累计次数。旧检测窗口是快照，需一并关闭。
        self._close_process_check_dialog()
        self._failed_indices.clear()
        self._status_tracker = StatusTracker()
        self._run_processes = {}
        self._process_history = []
        self._killed_processes = []
        self._run_stats_generation += 1
        self._run_stats = {"success": 0, "failed": 0, "skipped": 0, "stopped": 0}
        self.refresh_run_stats()
        # 工作流引擎原先使用默认空 logger，导致工作流即使执行了，运行中心也完全看不到步骤日志。
        # 这里把引擎日志桥接到 GUI 日志信号，后台线程不会直接操作 Qt 控件。
        self.engine.logger = lambda message: self.signals.log.emit(str(message))
        self.engine.stop_event.clear()
        self.engine.resume()

        self._last_run_exe = exe
        self._last_run_csv = csv_path
        self.engine.status_callback = lambda status: self.signals.row.emit(self._engine_current_row, str(status)) if self._engine_current_row >= 0 else None

        threading.Thread(
            target=self.run_all,
            args=(exe, csv_path, workflow, list(range(start - 1, end)), options),
            daemon=True
        ).start()

    def run_all(self, exe, csv_path, wf, indices, options):
        # 后台执行前再次校验原始账号索引，防止旧窗口/过期回调传入越界索引。
        valid_indices = []
        seen_indices = set()
        for raw_index in list(indices or []):
            try:
                index = int(raw_index)
            except (TypeError, ValueError, OverflowError):
                continue
            if 0 <= index < len(self.accounts) and index not in seen_indices:
                valid_indices.append(index)
                seen_indices.add(index)
        indices = valid_indices
        if not indices:
            self.signals.log.emit("本轮没有有效的账号索引，已安全取消执行。")
            self.signals.finished.emit()
            return
        total = len(indices)
        if int(options.get("concurrency", 1) or 1) > 1:
            self.run_all_concurrent(exe, csv_path, wf, indices, options)
            return
        pm = ProcessManager()
        active_pid = None
        try:
            for offset, i in enumerate(indices, 1):
                if self.stop_requested:
                    break
                a = self.accounts[i]
                if options["skip_expired"] and is_expired(a):
                    self._run_stats["skipped"] += 1
                    self.signals.row.emit(i, "跳过：已过期")
                    self._record_csv_daily_result(csv_path, a.account, "已过期")
                    self.refresh_run_stats_signal()
                    self.save_runtime_safe(exe, csv_path, i + 2, a.account, "跳过：已过期")
                    continue
                if options["skip_empty"] and not a.password:
                    self._run_stats["skipped"] += 1
                    self.signals.row.emit(i, "跳过：密码为空")
                    self._record_csv_daily_result(csv_path, a.account, "跳过")
                    self.refresh_run_stats_signal()
                    self.save_runtime_safe(exe, csv_path, i + 2, a.account, "跳过：密码为空")
                    continue

                self.signals.progress.emit(offset, total)
                self.signals.row.emit(i, "正在准备软件")
                self.signals.log.emit(f"正在运行账号 {i + 1}/{len(self.accounts)} 登录账号：{a.account}")
                success = False
                result_text = ""
                try:
                    # 每个账号都启动一个新的软件实例；旧实例保持运行，上号器绝不主动关闭。
                    # 取消了原来的“每处理一个账号都重新启动”复选框，但现在按固定策略逐账号启动，避免第二个账号复用第一个实例。
                    active_pid = pm.start(exe)
                    self._register_process_record(active_pid, a.account, i, exe)
                    self.signals.log.emit(f"第 {i + 1} 个账号：{a.account}，启动软件 PID：{active_pid}（不会自动关闭旧实例）")
                    self.signals.row.emit(i, "等待软件启动")
                    self.engine.wait(options["start_wait"])

                    self.signals.row.emit(i, "正在执行工作流")
                    self._engine_current_row = i
                    self.signals.log.emit(f"账号 {a.account}：开始执行工作流，共 {len(wf.get('steps', []))} 个步骤，PID={active_pid}")
                    self.engine.run(wf, a, active_pid, run_no=offset, total=total)
                    self.signals.log.emit(f"账号 {a.account}：工作流执行完成")
                    self.signals.log.emit(f"运行结束：成功 账号序号={i + 1}/{len(self.accounts)} 登录账号：{a.account}")
                    final_status = str(self.engine.runtime_context.get("status", "") or "完成")
                    err = str(self.engine.runtime_context.get("last_error", "") or "")
                    if err:
                        final_status = f"{final_status}（异常：{err}）"
                    self.signals.row.emit(i, final_status)
                    self._record_csv_daily_result(csv_path, a.account, final_status)
                    success = True
                    self._failed_indices.discard(i)
                    self._run_stats["success"] += 1
                    self._set_process_result(active_pid, final_status)
                    self.refresh_run_stats_signal()
                    result_text = final_status
                    self.append_run_history(a.account, wf.get("name", ""), result_text, active_pid, self.engine.runtime_context.get("step", ""), "工作流执行完成")
                except WorkflowExit as exc:
                    if getattr(exc, "terminate_process", False):
                        # “结束该次循环”：明确计为失败；WorkflowEngine 在抛出异常前已经关闭当前账号对应的目标进程。
                        self._failed_indices.add(i)
                        if active_pid:
                            self._killed_processes.append({"pid": int(active_pid), "account": a.account, "index": i, "reason": "工作流检测重试耗尽"})
                        self._set_process_result(active_pid, "失败")
                        for _r in getattr(self, "_process_history", []):
                            if int(_r.get("pid", -1)) == int(active_pid): _r["end_reason"] = "工作流检测重试耗尽"
                        self._run_stats["failed"] += 1
                        self._set_process_result(active_pid, "失败")
                        self.refresh_run_stats_signal()
                        result_text = "失败：结束该次循环"
                        self.signals.log.emit(f"账号 {a.account}：重试失败，结束该次循环，当前账号记为失败并进入下一个账号")
                        self.signals.row.emit(i, result_text)
                        self._record_csv_daily_result(csv_path, a.account, "登录失败")
                        self.append_run_history(a.account, wf.get("name", ""), "失败", active_pid, self.engine.runtime_context.get("step", ""), "重试失败后结束该次循环；已结束当前目标进程")
                        self.save_runtime_safe(exe, csv_path, i + 2, a.account, result_text)
                    else:
                        # 保留其他显式 WorkflowExit 的旧兼容行为，不将其误判为“重试失败结束循环”。
                        result_text = "结束该次循环"
                        self.signals.log.emit(f"账号 {a.account}：工作流请求结束当前账号流程，进入下一个账号")
                        self.signals.row.emit(i, result_text)
                        self._record_csv_daily_result(csv_path, a.account, result_text)
                        self.append_run_history(a.account, wf.get("name", ""), result_text, active_pid, self.engine.runtime_context.get("step", ""), "工作流显式结束账号流程")
                        self.save_runtime_safe(exe, csv_path, i + 2, a.account, result_text)
                except InterruptedError:
                    self._run_stats["stopped"] += 1
                    self._set_process_result(active_pid, "已停止")
                    self.refresh_run_stats_signal()
                    result_text = "已停止"
                    self.append_run_history(a.account, wf.get("name", ""), result_text, active_pid, self.engine.runtime_context.get("step", ""), "用户停止")
                    self.signals.log.emit(f"运行结束：失败 账号序号={i + 1}/{len(self.accounts)} 登录账号：{a.account}")
                    self.signals.row.emit(i, "已停止")
                    self._record_csv_daily_result(csv_path, a.account, "已停止")
                    self.save_runtime_safe(exe, csv_path, i + 1, a.account, result_text)
                    break
                except Exception as e:
                    self._failed_indices.add(i)
                    self._run_stats["failed"] += 1
                    self._set_process_result(active_pid, "失败")
                    self.refresh_run_stats_signal()
                    result_text = f"失败：{e}"
                    self.append_run_history(a.account, wf.get("name", ""), "失败", active_pid, self.engine.runtime_context.get("step", ""), str(e))
                    self.signals.log.emit(f"账号 {a.account}：工作流异常：{type(e).__name__}: {e}")
                    self.signals.row.emit(i, result_text)
                    self._record_csv_daily_result(csv_path, a.account, "登录失败")
                    self.signals.log.emit(f"账号 {a.account} 失败：{e}")
                    self.signals.log.emit(f"运行结束：失败 账号序号={i + 1}/{len(self.accounts)} 登录账号：{a.account}")
                    self.save_runtime_safe(exe, csv_path, i + 1, a.account, "失败")

                if success:
                    self.save_runtime_safe(exe, csv_path, i + 2, a.account, result_text)
                if offset < total and not self.stop_requested:
                    try:
                        self.engine.wait(options["interval"])
                    except InterruptedError:
                        break
        finally:
            # 常规运行器不主动关闭目标软件；仅工作流明确选择“结束该次循环”且重试耗尽时，才会结束当前账号对应进程。
            self.signals.finished.emit()

    def run_all_concurrent(self, exe, csv_path, wf, indices, options):
        """3.0 并发运行：每个账号独立 Engine/句柄/变量上下文，共享暂停/停止事件。"""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        total=len(indices); max_workers=max(1,min(int(options.get("concurrency",2)),32))
        shared_stop=self.engine.stop_event; shared_pause=self.engine.pause_event
        completed_lock = threading.Lock()
        completed = set()
        def mark_completed(offset, index, account, result):
            # 只把“连续完成”的前缀写入断点，避免并发中后面的账号先完成而跳过前面的未完成账号。
            with completed_lock:
                completed.add(int(index))
                next_index = None
                for original in sorted(indices):
                    if original not in completed:
                        next_index = original + 1
                        break
                if next_index is None and indices:
                    next_index = max(indices) + 2
            self.save_runtime_safe(exe, csv_path, next_index or 1, account, result)
        def worker(offset_i):
            offset,i=offset_i; a=self.accounts[i]; pid=""; result="失败"; worker_completed=False; engine=WorkflowEngine()
            engine.stop_event=shared_stop; engine.pause_event=shared_pause; engine.logger=lambda m,idx=i:self.signals.log.emit(f"[账号 {self.accounts[idx].account}] {m}")
            engine.status_callback=lambda status,idx=i:self.signals.row.emit(idx,str(status))
            try:
                if options["skip_expired"] and is_expired(a):
                    with self._stats_lock:self._run_stats["skipped"]+=1
                    self.signals.row.emit(i,"跳过：已过期"); self._record_csv_daily_result(csv_path, a.account, "已过期"); self.refresh_run_stats_signal(); mark_completed(offset, i, a.account, "跳过：已过期"); return
                if options["skip_empty"] and not str(a.password or ""):
                    with self._stats_lock:self._run_stats["skipped"]+=1
                    self.signals.row.emit(i,"跳过：空密码"); self._record_csv_daily_result(csv_path, a.account, "跳过"); self.refresh_run_stats_signal(); mark_completed(offset, i, a.account, "跳过：空密码"); return
                if self.stop_requested: return
                pm=ProcessManager(); pid=pm.start(exe); self._register_process_record(pid, a.account, i, exe); self.signals.row.emit(i,"等待软件启动"); engine.wait(options["start_wait"]); self.signals.row.emit(i,"正在执行工作流")
                engine.run(wf,a,pid,run_no=offset,total=total); result=str(engine.runtime_context.get("status") or "完成"); err=str(engine.runtime_context.get("last_error") or "")
                if err:
                    result=f"{result}（异常：{err}）"
                worker_completed=True
                self.signals.row.emit(i,result)
                self._record_csv_daily_result(csv_path, a.account, result)
                with self._stats_lock:self._run_stats["success"]+=1
                self._set_process_result(pid, result)
                self._failed_indices.discard(i); self.append_run_history(a.account,wf.get("name",""),result,pid,engine.runtime_context.get("step",""),"并发工作流执行完成")
            except WorkflowExit as exc:
                if getattr(exc, "terminate_process", False):
                    # “结束该次循环”：计为失败；目标进程已在 WorkflowEngine 的重试耗尽处理里结束。
                    result = "失败：结束该次循环"
                    worker_completed=True
                    self.signals.row.emit(i, result)
                    self._record_csv_daily_result(csv_path, a.account, "登录失败")
                    self.append_run_history(a.account,wf.get("name",""),"失败",pid,engine.runtime_context.get("step",""),"重试失败后结束该次循环；已结束当前目标进程")
                    self.signals.log.emit(f"账号 {a.account}：重试失败，结束该次循环，当前账号记为失败并进入下一个账号")
                    with self._stats_lock:
                        self._run_stats["failed"] += 1
                        self._set_process_result(pid, "失败")
                        self._failed_indices.add(i)
                        if pid:
                            self._killed_processes.append({"pid": int(pid), "account": a.account, "index": i, "reason": "工作流检测重试耗尽"})
                    self._set_process_result(pid, "失败")
                    for _r in getattr(self, "_process_history", []):
                        if int(_r.get("pid", -1)) == int(pid): _r["end_reason"] = "工作流检测重试耗尽"
                else:
                    result = "结束该次循环"
                    worker_completed=True
                    self.signals.row.emit(i, result)
                    self._record_csv_daily_result(csv_path, a.account, result)
                    self.append_run_history(a.account,wf.get("name",""),result,pid,engine.runtime_context.get("step",""),"工作流显式结束账号流程")
                    self.signals.log.emit(f"账号 {a.account}：工作流请求结束当前账号流程，进入下一个账号")
            except InterruptedError:
                # 被停止的账号尚未完成；不要将它计入连续完成前缀，否则断点可能越过该账号。
                worker_completed=False
                result="已停止"
                with self._stats_lock:self._run_stats["stopped"]+=1
                self.signals.row.emit(i,"已停止"); self._record_csv_daily_result(csv_path, a.account, "已停止"); self.append_run_history(a.account,wf.get("name",""),"已停止",pid,engine.runtime_context.get("step",""),"用户停止")
            except Exception as e:
                worker_completed=True
                with self._stats_lock:self._run_stats["failed"]+=1
                self._failed_indices.add(i); self._set_process_result(pid, "失败"); self.signals.row.emit(i,f"失败：{e}"); self._record_csv_daily_result(csv_path, a.account, "登录失败"); self.append_run_history(a.account,wf.get("name",""),"失败",pid,engine.runtime_context.get("step",""),str(e)); self.signals.log.emit(f"账号 {a.account} 并发失败：{e}")
            finally:
                if worker_completed:
                    mark_completed(offset, i, a.account, result)
                self.refresh_run_stats_signal()
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures=[pool.submit(worker,(n,i)) for n,i in enumerate(indices,1)]
            for f in as_completed(futures):
                try:f.result()
                except Exception as e:self.signals.log.emit(f"并发任务线程异常：{e}")
        self.signals.finished.emit()

    def append_run_history(self, account, workflow, result, pid="", step="", message=""):
        safe_message = self._secret_redactor.redact(message) if hasattr(self, "_secret_redactor") else str(message or "")
        rec={"time":time.strftime("%Y-%m-%d %H:%M:%S"),"account":str(account),"workflow":str(workflow),"result":str(result),"pid":str(pid or ""),"step":str(step or ""),"message":safe_message}
        with self._history_lock:
            self._run_history.append(rec)
            self._run_history=self._run_history[-1000:]
            try:
                hp=Path(__file__).resolve().parent / "config" / "run_history.jsonl"
                hp.parent.mkdir(parents=True, exist_ok=True)
                with hp.open("a", encoding="utf-8") as f: f.write(json.dumps(rec, ensure_ascii=False)+"\n")
                if hp.exists() and hp.stat().st_size > 5*1024*1024:
                    lines=hp.read_text(encoding="utf-8").splitlines()[-2000:]
                    tmp=hp.with_suffix(".jsonl.tmp")
                    tmp.write_text("\n".join(lines)+"\n", encoding="utf-8")
                    os.replace(tmp, hp)
            except Exception:
                pass

    def save_runtime_safe(self, exe, csv_path, next_index, account, result):
        try:
            self.memory.save_runtime(
                exe,
                csv_path,
                next_index=max(1, int(next_index)),
                last_account=str(account),
                last_result=str(result),
                last_run_time=time.strftime("%Y-%m-%d %H:%M:%S"),
            )
        except Exception as exc:
            # 断点写入失败不应中断账号执行，但必须留下可见诊断，避免用户误以为已保存。
            try:
                self.signals.log.emit(f"运行断点保存失败：{type(exc).__name__}: {exc}")
            except Exception:
                pass

    def pause(self):
        self.engine.pause()
        self.write_log("已暂停，当前工作流会停在下一次可暂停的位置。")

    def resume(self):
        self.engine.resume()
        self.write_log("已继续运行。")

    def stop(self):
        self.stop_requested = True
        self.engine.stop()
        self.engine.resume()
        self.write_log("正在停止运行...")

    def finished(self):
        self.running = False
        # 进程检测始终可打开，不再受“本轮是否完成”限制。
        if hasattr(self, "process_check_btn"):
            self.process_check_btn.setEnabled(True)
            self.process_check_btn.setToolTip("随时打开进程检测；会检测当前已有记录、由上号器启动过的软件进程。")
        # 一轮任务结束后彻底结束键鼠锁定会话；F11/F12 此后不再影响电脑。
        try:
            self.input_lock.end_session()
        except Exception:
            pass

        if self._last_run_exe and self._last_run_csv:
            runtime = self.memory.get_runtime(
                self._last_run_exe, self._last_run_csv
            )
            self.refresh_memory_label(runtime)

        self.setWindowTitle(f"句柄上号器 · 自动化工作流平台 {APP_VERSION}（v22）")
        self.refresh_run_stats()
        self.write_log(f"本次账号范围处理结束。统计：成功 {self._run_stats['success']}，失败 {self._run_stats['failed']}，跳过 {self._run_stats['skipped']}，停止 {self._run_stats['stopped']}")

        # 高级调度的自动重跑：运行结束后只调用“进程检测”已有的三种重跑集合，
        # 不再在高级调度里复制并发、启动间隔或工作流失败重试逻辑。
        sc=getattr(self,'_advanced_schedule',{}) or {}
        if sc.get('auto_process_retry') and not self.stop_requested:
            mode=sc.get('process_retry_mode','重跑未进行全部')
            if self._auto_process_retry_round >= 1:
                self.write_log("高级调度：自动重跑已达到本轮最大重跑次数（1 次），停止继续递归重跑。")
            else:
                retry_indices=self._get_process_retry_indices(mode)
                if retry_indices:
                    self._auto_process_retry_round += 1
                    label=f"进程检测·{mode}"
                    self.write_log(f"高级调度：运行结束，按进程检测“{mode}”准备重跑 {len(retry_indices)} 个账号（自动重跑第 {self._auto_process_retry_round}/1 轮）。")
                    QTimer.singleShot(0, lambda inds=retry_indices, lab=label: self.retry_accounts(inds, lab, automatic=True))
                else:
                    self.write_log(f"高级调度：运行结束，进程检测“{mode}”没有可重跑账号。")

    def refresh_run_stats_signal(self):
        self.signals.log.emit(f"__RUN_STATS__:{self._run_stats_generation}|{self._run_stats['success']}|{self._run_stats['failed']}|{self._run_stats['skipped']}|{self._run_stats['stopped']}")

    def refresh_run_stats(self):
        if hasattr(self, 'run_stats_label'):
            r = self._run_stats
            failed_count = len(self._failed_indices)
            self.run_stats_label.setText(f"本轮统计：成功 {r['success']} ｜ 失败 {r['failed']} ｜ 跳过 {r['skipped']} ｜ 停止 {r['stopped']}")
            if hasattr(self, "process_check_btn"):
                # 不论任务是否正在运行，进程检测窗口都可以打开。
                self.process_check_btn.setEnabled(True)
                self.process_check_btn.setToolTip("随时打开进程检测；会检测当前已有记录、由上号器启动过的软件进程。")

    def write_log_force(self, msg):
        """绕过“简化输出”过滤，强制写入已脱敏的诊断信息。"""
        if not hasattr(self, "log"):
            return
        safe_msg = self._secret_redactor.redact(msg) if hasattr(self, "_secret_redactor") else str(msg)
        self.log.append(f"[{time.strftime('%H:%M:%S')}] {safe_msg}")

    def _get_process_identity(self, pid):
        """返回 Windows 进程身份令牌（PID + 创建时间）。PID 被系统复用时不会误认成原进程。"""
        try:
            import ctypes
            k=ctypes.WinDLL("kernel32", use_last_error=True)
            QUERY=0x1000
            h=k.OpenProcess(QUERY, False, int(pid))
            if not h: return ""
            try:
                creation=ctypes.c_ulonglong(); exit_t=ctypes.c_ulonglong(); kernel=ctypes.c_ulonglong(); user=ctypes.c_ulonglong()
                k.GetProcessTimes.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulonglong),ctypes.POINTER(ctypes.c_ulonglong),ctypes.POINTER(ctypes.c_ulonglong),ctypes.POINTER(ctypes.c_ulonglong)]
                k.GetProcessTimes.restype=ctypes.c_int
                if k.GetProcessTimes(h,ctypes.byref(creation),ctypes.byref(exit_t),ctypes.byref(kernel),ctypes.byref(user)):
                    return str(int(creation.value))
            finally:
                k.CloseHandle(h)
        except Exception:
            pass
        return ""

    def _register_process_record(self, pid, account, index, exe):
        """登记一次启动。每个账号只保留最新一条进程记录，重跑只递增“次数”。"""
        pid = int(pid)
        history = getattr(self, "_process_history", [])
        prior = next((r for r in history if int(r.get("index", -1)) == int(index)), None)
        attempt = int(prior.get("attempt", 1) or 1) + 1 if prior else 1
        record = {
            "pid": pid, "account": str(account), "index": int(index), "exe": str(exe),
            "started": time.strftime("%H:%M:%S"), "start_identity": self._get_process_identity(pid), "attempt": attempt,
            "result": "运行中",
        }
        if prior is not None:
            # 重跑覆盖该账号之前的记录，但保留累计重跑次数。
            prior.clear()
            prior.update(record)
            record = prior
        else:
            history.append(record)
        self._run_processes[pid] = record
        return record

    def _set_process_result(self, pid, result):
        try:
            pid = int(pid)
        except Exception:
            return
        for record in getattr(self, "_process_history", []):
            if int(record.get("pid", -1)) == pid:
                record["result"] = str(result)
                break

    def check_run_processes(self):
        """随时检测当前已登记的进程，并打开独立的简洁结果窗口。

        不再要求“本轮运行完成”；运行过程中已经启动的账号会立即出现在检测结果中，
        尚未启动任何账号时也允许打开窗口，等待后续记录产生。
        """
        history = list(getattr(self, "_process_history", []) or [])
        records = {int(r.get("pid")): r for r in history if r.get("pid")}
        if not records:
            self.write_log_force("进程检测：当前暂无由上号器启动的软件进程记录，打开空检测窗口等待后续记录。")

        def process_alive(pid, expected_identity=""):
            return self._process_pid_alive(pid, expected_identity)


        killed = list(getattr(self, "_killed_processes", []) or [])
        killed_map = {}
        for item in killed:
            try:
                killed_map[int(item.get("pid", 0))] = item
            except Exception:
                pass

        rows = []
        alive_count = 0
        exited_count = 0
        killed_count = 0

        # 统一整理成“展示数据”，UI 不再直接处理原始运行记录。
        for pid, record in records.items():
            try:
                pid_int = int(pid)
            except Exception:
                continue

            account = str(record.get("account", "") or "")
            exe = str(record.get("exe", "") or "")
            started = str(record.get("started", "") or "—")
            if record.get("excluded"):
                rows.append({
                    "account": account, "pid": str(pid_int), "state": "主动排除",
                    "started": started, "reason": "用户主动排除",
                    "result": "登录成功", "attempt": int(record.get("attempt", 1) or 1),
                    "exe": exe, "index": int(record.get("index", -1)),
                })
                continue
            expected_identity = str(record.get("start_identity", "") or "")
            alive = process_alive(pid_int, expected_identity)
            current_identity = self._get_process_identity(pid_int) if alive or expected_identity else ""
            if alive:
                end_reason = "—"
            elif expected_identity and current_identity and current_identity != expected_identity:
                end_reason = "PID 已被系统复用，当前进程不是原启动进程"
            else:
                end_reason = "—"

            if alive:
                alive_count += 1
                state = "运行中"
                end_reason = "—"
            else:
                exited_count += 1
                killed_item = killed_map.get(pid_int)
                if killed_item:
                    killed_count += 1
                    state = "已退出"
                    end_reason = str(record.get("end_reason") or killed_item.get("reason", "上号器主动结束") or "上号器主动结束")
                else:
                    state = "已退出"
                    end_reason = str(record.get("end_reason") or "进程自然退出")
                if expected_identity and current_identity and current_identity != expected_identity:
                    end_reason = "PID 已被系统复用，当前进程不是原启动进程"

            rows.append({
                "account": account,
                "pid": str(pid_int),
                "state": state,
                "started": started,
                "reason": end_reason,
                "result": str(record.get("result", "运行中") or "运行中"),
                "attempt": int(record.get("attempt", 1) or 1),
                "exe": exe,
                "index": int(record.get("index", -1)),
            })

        # 默认把“已退出”放前面；同状态下保持本轮启动顺序。
        rows.sort(key=lambda item: (0 if item["state"] == "已退出" else 1))

        self.write_log_force("========== 本轮进程检测 ==========")
        self.write_log_force(f"本轮启动：{len(rows)} 个；已退出：{exited_count} 个；运行中：{alive_count} 个；主动结束：{killed_count} 个")
        for item in rows:
            if item["state"] == "已退出":
                self.write_log_force(
                    f"已退出：PID={item['pid']}，账号={item['account']}，方式={item['reason']}"
                )
            else:
                self.write_log_force(
                    f"运行中：PID={item['pid']}，账号={item['account']}"
                )
        self.write_log_force("========== 进程检测结束 ==========")

        if getattr(self, "_process_check_dialog", None) is not None:
            try:
                if self._process_check_dialog.isVisible():
                    self._process_check_dialog.raise_()
                    self._process_check_dialog.activateWindow()
                    return
            except Exception:
                pass
        dlg = ProcessCheckDialog(
            rows,
            total_count=len(rows),
            exited_count=exited_count,
            alive_count=alive_count,
            killed_count=killed_count,
            failed_indices=getattr(self, "_failed_indices", set()),
            parent=self,
        )
        dlg.retry_requested.connect(self.retry_accounts)
        dlg.exclude_requested.connect(self.exclude_process_account)
        dlg.restore_requested.connect(self.restore_process_account)
        dlg.locate_requested.connect(self.locate_run_account)
        self._process_check_dialog = dlg
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def exclude_process_account(self, index, account):
        """主动排除：记录排除前状态，从失败/退出重跑集合移除，并把 CSV 状态设为登录成功。"""
        try:
            index = int(index)
        except Exception:
            return
        csv_path = self.csv.text().strip()
        previous_csv_status = "未运行"
        try:
            rows = load_rows(csv_path)
            for row in rows:
                if str(row.get("account", "") or "").strip() == str(account).strip():
                    previous_csv_status = str(row.get("status", "") or "未运行").strip() or "未运行"
                    break
        except Exception:
            pass
        for record in getattr(self, "_process_history", []):
            if int(record.get("index", -1)) == index:
                record["excluded"] = True
                record["previous_result"] = record.get("result", "运行中")
                record["previous_reason"] = record.get("end_reason", "—")
                record["previous_csv_status"] = previous_csv_status
                record["result"] = "登录成功"
                record["end_reason"] = "用户主动排除"
                break
        self._failed_indices.discard(index)
        if 0 <= index < len(getattr(self, "accounts", [])):
            try:
                self._record_csv_daily_result(csv_path, self.accounts[index].account, "登录成功")
                self.update_row(index, "登录成功")
            except Exception as exc:
                self.write_log(f"主动排除账号状态写回失败：{exc}")
        self.write_log_force(f"进程检测：账号 {account} 已主动排除，不再参与重跑，CSV 状态已设为登录成功。")
        self.refresh_run_stats()

    def restore_process_account(self, index, account):
        """恢复主动排除：撤销排除标记，并恢复排除前的 CSV 状态。"""
        try:
            index = int(index)
        except Exception:
            return
        restored_status = "未运行"
        restored_result = "运行中"
        restored_reason = "—"
        restored = False
        for record in getattr(self, "_process_history", []):
            if int(record.get("index", -1)) == index:
                restored = True
                record["excluded"] = False
                restored_result = str(record.get("previous_result") or "运行中")
                restored_reason = str(record.get("previous_reason") or "—")
                restored_status = str(record.get("previous_csv_status") or "未运行")
                record["result"] = restored_result
                record["end_reason"] = restored_reason
                break
        self._failed_indices.discard(index)
        if 0 <= index < len(getattr(self, "accounts", [])):
            try:
                self._record_csv_daily_result(csv_path := self.csv.text().strip(), self.accounts[index].account, restored_status)
                self.update_row(index, restored_status)
            except Exception as exc:
                self.write_log(f"恢复主动排除时 CSV 状态写回失败：{exc}")
        self.write_log_force(f"进程检测：账号 {account} 已恢复主动排除，CSV 状态恢复为“{restored_status}”。")
        self.refresh_run_stats()
        # 重新打开/刷新检测窗口时会根据进程实际状态重新生成展示状态；
        # 当前窗口则直接更新对应行，避免恢复后仍显示为“主动排除”。
        dlg = getattr(self, "_process_check_dialog", None)
        if restored and dlg is not None and dlg.isVisible():
            for data in dlg.rows:
                try: same = int(data.get("index", -1)) == index
                except Exception: same = False
                if same:
                    data["state"] = restored_result if restored_result in ("运行中", "已退出") else "运行中"
                    data["result"] = restored_result
                    data["reason"] = restored_reason
                    break
            dlg._refresh_table()

    def locate_run_account(self, index):
        """定位到运行中心对应账号并高亮。"""
        try:
            index = int(index)
        except Exception:
            return
        if not (0 <= index < len(getattr(self, "accounts", []))):
            return
        if hasattr(self, "tabs"):
            self.tabs.setCurrentIndex(0)
        if hasattr(self, "run_account_search"):
            self.run_account_search.clear()
        self.filter_run_accounts()
        if 0 <= index < self.table.rowCount():
            self.table.setRowHidden(index, False)
            self.table.setCurrentCell(index, 0)
            self.table.selectRow(index)
            self.table.scrollToItem(self.table.item(index, 0), QAbstractItemView.PositionAtCenter)
            self.table.setFocus(Qt.OtherFocusReason)

    def _process_pid_alive(self, pid, expected_identity=""):
        """查询进程是否仍运行；如提供创建时间，则同时校验 PID 是否仍属于原进程。"""
        try:
            import ctypes
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            SYNCHRONIZE = 0x00100000
            STILL_ACTIVE = 259
            kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
            kernel32.OpenProcess.restype = ctypes.c_void_p
            kernel32.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
            kernel32.GetExitCodeProcess.restype = ctypes.c_int
            kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
            kernel32.CloseHandle.restype = ctypes.c_int
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, 0, int(pid))
            if not handle:
                return False
            try:
                code = ctypes.c_uint32(0)
                if not (bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == STILL_ACTIVE):
                    return False
            finally:
                kernel32.CloseHandle(handle)

            expected_identity = str(expected_identity or "")
            if expected_identity:
                current_identity = self._get_process_identity(pid)
                # 有历史身份但无法取得当前身份时宁可判定为非原进程，避免 PID 复用误判。
                return bool(current_identity) and current_identity == expected_identity
            return True
        except Exception:
            return False

    def _get_process_retry_indices(self, mode):
        """按进程检测三种规则生成重跑集合；退出状态实时按 PID 判断，不依赖不存在的 state 字段。"""
        history=list(getattr(self,'_process_history',[]) or [])
        excluded={int(r.get('index',-1)) for r in history if int(r.get('index',-1))>=0 and bool(r.get('excluded'))}
        failed={int(i) for i in getattr(self,'_failed_indices',set()) if int(i)>=0}
        exited=set()
        for r in history:
            try: idx=int(r.get('index',-1)); pid=int(r.get('pid',0))
            except Exception: continue
            expected_identity = str(r.get("start_identity", "") or "")
            if idx >= 0 and pid > 0 and not r.get('excluded') and not self._process_pid_alive(pid, expected_identity):
                exited.add(idx)
        if mode=='重跑失败账号': result=failed
        elif mode=='重跑已退出账号': result=exited
        else: result=failed | exited
        return sorted(result-excluded)

    def retry_accounts(self, indices, label="账号", automatic=False):
        """从进程检测窗口发起重跑；indices 为 accounts 的原始 0-based 索引。"""
        if self.running:
            QMessageBox.information(self, "正在运行", "当前任务仍在运行，请等待本轮结束后再重跑。")
            return
        requested_indices = set()
        for raw_index in indices or []:
            try:
                requested_indices.add(int(raw_index))
            except (TypeError, ValueError, OverflowError):
                continue
        indices = sorted(i for i in requested_indices if 0 <= i < len(self.accounts))
        stale_indices = requested_indices - set(indices)
        if stale_indices:
            self.write_log_force("重跑保护：忽略越界或无效账号索引 " + ", ".join(str(i) for i in sorted(stale_indices)))
        # 进程检测窗口可能在 CSV 重新载入后仍然存在；账号身份不匹配时不把旧记录套到新账号。
        history_by_index = {}
        for record in getattr(self, "_process_history", []) or []:
            try:
                history_by_index[int(record.get("index", -1))] = record
            except Exception:
                continue
        identity_mismatch = []
        safe_indices = []
        for index in indices:
            record = history_by_index.get(index)
            if record and str(record.get("account", "")).strip() != str(self.accounts[index].account).strip():
                identity_mismatch.append(index)
            else:
                safe_indices.append(index)
        if identity_mismatch:
            self.write_log_force("重跑保护：账号文件内容已变化，忽略与旧进程记录不匹配的索引 " + ", ".join(str(i) for i in identity_mismatch))
        indices = safe_indices
        if not indices:
            QMessageBox.information(self, "没有可重跑账号", "当前没有有效且与当前账号文件匹配的可重跑账号。")
            return
        exe=self.exe.text().strip(); csv_path=self.csv.text().strip(); wfpath=self.workflow_combo.currentData()
        if not os.path.isfile(exe) or not os.path.isfile(csv_path) or not wfpath or not os.path.isfile(wfpath):
            QMessageBox.warning(self, "无法重跑", "请确认启动项目、账号文件和工作流仍然有效。")
            return
        try:
            workflow=self.store.load(wfpath); validation=self.engine.validate_workflow(workflow)
            if validation.get("errors"):
                QMessageBox.warning(self,"工作流检查未通过","\n".join(validation["errors"])); return
        except Exception as e:
            QMessageBox.critical(self,"工作流读取失败",str(e)); return
        options={"start_wait":self.start_wait.value(),"interval":self.interval.value(),"skip_expired":self.skip_expired.isChecked(),"skip_empty":self.skip_empty.isChecked(),"concurrency":self.concurrency.value()}
        self.stop_requested=False; self.running=True; self._simple_logged_accounts.clear()
        if hasattr(self,"process_check_btn"):
            self.process_check_btn.setEnabled(False); self.process_check_btn.setToolTip("随时打开进程检测；会检测当前已有记录、由上号器启动过的软件进程。")
        if self.lock_input_on_start.isChecked():
            try:self.input_lock.begin_session(locked=True)
            except Exception as e:
                self.running=False; QMessageBox.warning(self,"键鼠锁定失败",f"无法启用全局键鼠锁定：\n{e}"); return
        self._run_stats={"success":0,"failed":0,"skipped":0,"stopped":0}; self._run_processes={}; self._killed_processes=[]; self.refresh_run_stats()
        self.engine.logger=lambda message:self.signals.log.emit(str(message))
        self.engine.status_callback=lambda status:self.signals.row.emit(self._engine_current_row,str(status)) if self._engine_current_row>=0 else None
        self.engine.stop_event.clear(); self.engine.resume(); self._last_run_exe=exe; self._last_run_csv=csv_path
        self.write_log(f"开始重跑{label}，共 {len(indices)} 个：" + ", ".join(str(i+1) for i in indices))
        threading.Thread(target=self.run_all,args=(exe,csv_path,workflow,indices,options),daemon=True).start()

    def retry_failed(self):
        self.retry_accounts(sorted(self._failed_indices), "失败账号")

    def build_advanced_tab(self):
        w=QWidget(); lay=QVBoxLayout(w); title=QLabel("3.0 高级中心"); title.setStyleSheet("font-size:20px;font-weight:700;"); lay.addWidget(title)
        box=QGroupBox("工作流工程") ; bl=QHBoxLayout(box)
        for text,fn in [("可视化条件编辑器",self.open_condition_builder),("单步调试器",self.open_debugger),("日志中心 / 运行报告",self.open_log_center),("高级调度",self.open_advanced_scheduler)]:
            b=QPushButton(text); b.clicked.connect(fn); bl.addWidget(b)
        lay.addWidget(box)
        update_box=QGroupBox("安全更新与回滚")
        update_layout=QVBoxLayout(update_box)
        update_row=QHBoxLayout()
        self.update_source_label=QLabel(self._update_source_summary())
        self.update_source_label.setWordWrap(True)
        update_row.addWidget(self.update_source_label,1)
        for text,fn in [("设置更新源",self.configure_update_source),("检查并下载",self.check_and_download_update),("打开更新目录",self.open_update_directory),("回滚上次更新",self.rollback_update)]:
            b=QPushButton(text); b.clicked.connect(fn); update_row.addWidget(b)
        update_layout.addLayout(update_row)
        update_hint=QLabel("首次使用：点“设置更新源”，填公开的 HTTPS 清单地址（或本地 JSON 清单路径）；之后点“检查并下载”。发布者可用随附“生成更新清单.py”自动计算 SHA-256。清单 version 必须是完整版本号（如 3.0.22），不再接受有歧义的 v22。下载后先校验摘要和 ZIP，再确认应用；config/、workflows/、JSON、CSV 和日志不会被更新包覆盖。")
        update_hint.setWordWrap(True); update_hint.setStyleSheet("color:#6b7280;")
        update_layout.addWidget(update_hint)
        lay.addWidget(update_box)
        info=QTextEdit(); info.setReadOnly(True); info.setPlainText("""3.0 已集成：

✓ 可视化 IF / AND / OR / NOT 条件编辑
✓ 单步执行、断点、实时变量/句柄监视
✓ CSV 多选、状态筛选、批量状态
✓ 工作流步骤搜索、分组、批量编辑
✓ 工作流版本历史、备份与恢复
✓ 日志中心、运行报告导出
✓ 多任务并发运行（运行中心并发数 > 1）
✓ 高级一次/每日/每小时/每N分钟调度
✓ 异常状态分类、状态迁移诊断与账号行颜色提示

注意：并发模式下每个账号使用独立 WorkflowEngine 和运行上下文；目标软件实例仍由每个账号单独启动。"""); lay.addWidget(info,1); return w

    def _update_settings_path(self):
        return Path(__file__).resolve().parent / "config" / "update_settings.json"

    def _load_update_settings(self):
        path=self._update_settings_path()
        try:
            data=json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
            return data if isinstance(data,dict) else {}
        except Exception:
            return {}

    def _save_update_source(self, source):
        path=self._update_settings_path(); path.parent.mkdir(parents=True,exist_ok=True)
        payload=json.dumps({"manifest_source":str(source or "").strip()},ensure_ascii=False,indent=2)+"\n"
        temp_path=None
        try:
            with tempfile.NamedTemporaryFile(mode="w",encoding="utf-8",newline="",dir=str(path.parent),prefix="update_settings.",suffix=".tmp",delete=False) as f:
                temp_path=Path(f.name); f.write(payload); f.flush(); os.fsync(f.fileno())
            os.replace(str(temp_path),str(path)); temp_path=None
        finally:
            if temp_path is not None:
                try: temp_path.unlink(missing_ok=True)
                except Exception: pass
        if hasattr(self,"update_source_label"):
            self.update_source_label.setText(self._update_source_summary())

    def _update_source_summary(self):
        source=str(self._load_update_settings().get("manifest_source","") or "").strip()
        return "更新源："+(source if source else "尚未配置（支持 HTTPS 清单 URL 或本地 JSON 清单路径）")

    def configure_update_source(self):
        current=str(self._load_update_settings().get("manifest_source","") or "")
        value,ok=QInputDialog.getText(self,"设置更新源","输入公开 HTTPS 更新清单 URL（例如 https://你的站点/manifest.json），或本地 JSON 清单路径：",QLineEdit.Normal,current)
        if ok:
            self._save_update_source(value)
            self.write_log("已保存更新源配置；在线地址必须使用 HTTPS。")

    def check_and_download_update(self):
        if self.running:
            QMessageBox.information(self,"暂不能更新","请先停止运行任务，再检查或应用更新。")
            return
        source=str(self._load_update_settings().get("manifest_source","") or "").strip()
        if not source:
            value,ok=QInputDialog.getText(self,"设置更新源","输入公开 HTTPS 更新清单 URL（例如 https://你的站点/manifest.json），或本地 JSON 清单路径：")
            if not ok or not str(value).strip(): return
            source=str(value).strip(); self._save_update_source(source)
        try:
            manifest=load_manifest(source)
            current=APP_VERSION
            if not is_newer_version(manifest["version"], current):
                QMessageBox.information(self,"检查更新",f"清单版本（{manifest['version']}）不高于当前版本（{current}），不会建议安装降级包。\n\n{manifest.get('notes','')}")
                return
            prompt=f"发现清单版本：{manifest['version']}\n当前程序版本：{current}\nSHA-256：{manifest['sha256']}\n\n更新说明：{manifest.get('notes') or '（清单未提供）'}\n\n是否下载并校验？"
            if QMessageBox.question(self,"发现更新",prompt,QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)!=QMessageBox.Yes: return
            destination=Path(__file__).resolve().parent/"config"/"updates"/"staged_update.zip"
            result=download_and_verify(manifest,destination)
            self.write_log(f"更新包下载完成并通过 SHA-256 / ZIP 校验：版本 {manifest['version']}，{result['size']} 字节。")
            reply=QMessageBox.question(self,"更新包已验证",f"版本 {manifest['version']} 已下载并校验通过。\n文件：{destination}\n\n现在退出程序，由独立更新进程备份旧文件、应用更新并尝试重启吗？",QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
            if reply==QMessageBox.Yes:
                self._launch_update_helper(destination, rollback=False)
        except Exception as exc:
            QMessageBox.critical(self,"更新失败",f"未应用任何更新。\n{type(exc).__name__}: {exc}")
            self.write_log(f"更新失败，未应用更新：{type(exc).__name__}: {exc}")

    def _launch_update_helper(self, package=None, rollback=False):
        if getattr(sys,"frozen",False):
            QMessageBox.warning(self,"需要更新助手","当前是打包后的 EXE 环境，但发行包未包含独立 update_helper.exe。为避免覆盖运行中的程序，本次不会自动应用；请保留下载包并在源码发行版中使用更新助手，或先将助手一并打包。")
            return
        helper=Path(__file__).resolve().parent/"update_manager.py"
        if not helper.is_file():
            QMessageBox.warning(self,"更新助手缺失",f"找不到更新助手：{helper}")
            return
        args=[sys.executable,str(helper),"--target",str(Path(__file__).resolve().parent),"--wait-pid",str(os.getpid()),"--restart",str(Path(sys.argv[0]).resolve())]
        if rollback: args.append("--rollback")
        else: args.extend(["--apply",str(Path(package).resolve())])
        try:
            import subprocess
            subprocess.Popen(args,cwd=str(Path(__file__).resolve().parent),close_fds=True)
            self.write_log("已启动独立更新助手；当前程序即将退出，助手会等待进程退出后再备份并应用文件。")
            QTimer.singleShot(300,self.close)
        except Exception as exc:
            QMessageBox.critical(self,"无法启动更新助手",str(exc))

    def open_update_directory(self):
        folder=Path(__file__).resolve().parent/"config"/"updates"
        folder.mkdir(parents=True,exist_ok=True)
        try:
            if os.name=="nt": os.startfile(str(folder))
            else:
                import subprocess; subprocess.Popen(["xdg-open",str(folder)])
        except Exception as exc:
            QMessageBox.information(self,"更新目录",f"目录位置：{folder}\n打开失败：{exc}")

    def rollback_update(self):
        if self.running:
            QMessageBox.information(self,"暂不能回滚","请先停止运行任务，再执行回滚。")
            return
        latest=Path(__file__).resolve().parent/"config"/"updates"/"last_update.json"
        if not latest.is_file():
            QMessageBox.information(self,"没有可回滚版本","尚无更新助手应用的更新记录。")
            return
        if QMessageBox.question(self,"确认回滚","将恢复上一次更新前备份的程序文件，并尝试重启程序。继续吗？",QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes: return
        self._launch_update_helper(rollback=True)

    def open_condition_builder(self):
        if not self.editor:
            QMessageBox.information(self,"条件编辑器","请先打开工作流并选择一个 IF / ELSE 条件步骤。") ; return
        row=self.editor.list.currentRow()
        if row<0 or row>=len(self.editor.data.get("steps",[])) or self.editor.data["steps"][row].get("action")!="if_condition":
            QMessageBox.information(self,"条件编辑器","请在工作流编辑器中选择“条件判断 IF / ELSE”步骤。") ; return
        s=self.editor.data["steps"][row]
        logic=s.get("logic") or s.get("conditions")
        if not logic:
            logic={"op":"and","items":[{"condition":s.get("condition","keyword_contains"),"target":s.get("target",""),"keyword":s.get("keyword",s.get("expected",""))}]}
        dlg=ConditionBuilderDialog(self,logic)
        if dlg.exec()==QDialog.Accepted:
            s["logic"]=dlg.get_logic(); self.editor.refresh(); self.write_log("已使用可视化条件编辑器更新当前 IF 条件。")

    def open_debugger(self):
        if not self.accounts:
            QMessageBox.information(self,"单步调试器","请先读取账号文件。")
            return
        exe=self.exe.text().strip()
        if not os.path.isfile(exe):
            QMessageBox.warning(self,"调试器","当前启动项目 EXE 不存在。请先配置启动项目。")
            return
        paths=self.store.list()
        if not paths:
            QMessageBox.information(self,"单步调试器","当前没有可调试的工作流，请先创建或导入工作流。")
            return
        dlg=QDialog(self); dlg.setWindowTitle("选择要调试的工作流"); dlg.resize(520,240)
        lay=QVBoxLayout(dlg)
        lay.addWidget(QLabel("请选择工作流，然后选择用于调试的账号："))
        wf_combo=QComboBox(); wf_combo.addItems([Path(p).stem for p in paths]);
        if self.current_workflow_path:
            for i,p in enumerate(paths):
                if str(p)==str(self.current_workflow_path): wf_combo.setCurrentIndex(i); break
        lay.addWidget(wf_combo)
        acc_combo=QComboBox()
        acc_combo.addItems([f"{i+1}. {a.account}" for i,a in enumerate(self.accounts)])
        current_row=self.table.currentRow() if hasattr(self,'table') else -1
        if 0<=current_row<len(self.accounts): acc_combo.setCurrentIndex(current_row)
        lay.addWidget(acc_combo)
        bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); lay.addWidget(bb); bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        if dlg.exec()!=QDialog.Accepted: return
        try:
            wf=self.store.load(paths[wf_combo.currentIndex()])
        except Exception as e:
            QMessageBox.critical(self,"调试器","读取工作流失败："+str(e)); return
        account=self.accounts[acc_combo.currentIndex()]
        DebuggerDialog(self,wf,account,exe,ProcessManager,WorkflowEngine).exec()

    def open_log_center(self):
        hist=list(self._run_history)
        if not hist:
            hp=Path(__file__).resolve().parent/"config"/"run_history.jsonl"
            if hp.exists():
                for line in hp.read_text(encoding="utf-8").splitlines():
                    try: hist.append(json.loads(line))
                    except Exception: pass
        LogCenterDialog(self,hist).exec()

    def open_advanced_scheduler(self):
        current=getattr(self,"_advanced_schedule",{})
        dlg=AdvancedSchedulerDialog(self,current)
        if dlg.exec()==QDialog.Accepted:
            self._advanced_schedule=dlg.get_data(); self.write_log("高级调度已保存："+json.dumps(self._advanced_schedule,ensure_ascii=False)); self._save_advanced_schedule()

    def _save_advanced_schedule(self):
        try:
            p=Path(__file__).resolve().parent/"config"/"advanced_schedule.json"; p.write_text(json.dumps(getattr(self,"_advanced_schedule",{}),ensure_ascii=False,indent=2),encoding="utf-8")
        except Exception: pass

    # =========================
    # 窗口句柄
    # =========================

    def show_tree(self):
        if getattr(self, '_handle_viewer', None) is not None:
            try:
                self._handle_viewer.raise_(); self._handle_viewer.activateWindow(); return
            except Exception: pass
        self._handle_viewer=HandleViewerDialog(self)
        self._handle_viewer.setAttribute(Qt.WA_DeleteOnClose, True)
        self._handle_viewer.destroyed.connect(lambda *_: setattr(self,'_handle_viewer',None))
        self._handle_viewer.show()

    # =========================
    # 关闭时保存所有记忆
    # =========================

    def closeEvent(self, event):
        if self.running:
            answer = QMessageBox.question(
                self,
                "任务正在运行",
                "当前还有任务正在运行。\n\n确定要关闭程序吗？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                event.ignore()
                return

            self.stop_requested = True
            self.engine.stop()
            self.engine.resume()

        try:
            self._save_table_memory()
            self._save_csv_table_memory()

            self.memory.save_settings(
                last_exe=self.exe.text().strip(),
                last_csv=self.csv.text().strip(),
                last_workflow=self.current_workflow_path or "",
                window_geometry=bytes(self.saveGeometry().toBase64()).decode("ascii"),
                schedule_enabled=self.schedule_enable.isChecked(),
                schedule_time=self.schedule_time.time().toString("HH:mm"),
                simplify_output=(
                    self.simplify_output.isChecked()
                    if hasattr(self, "simplify_output") else False
                ),
            )

            if self.exe.text().strip() and self.csv.text().strip():
                self.save_current_memory()

            self.memory.save_all()
        except Exception:
            pass

        try:
            self.input_lock.stop()
        except Exception:
            pass
        try:
            self._flush_and_close_log_file()
        except Exception:
            pass
        event.accept()
