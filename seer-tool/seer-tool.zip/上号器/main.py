import os
import sys
import ctypes
import subprocess
import traceback
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
ERROR_LOG = BASE_DIR / "startup_error.log"


def write_startup_error(title, exc=None):
    try:
        lines = [
            "句柄上号器启动错误",
            f"时间: {__import__('datetime').datetime.now().isoformat(sep=' ', timespec='seconds')}",
            f"程序目录: {BASE_DIR}",
            f"Python: {sys.executable}",
            f"Python版本: {sys.version}",
            f"标题: {title}",
        ]
        if exc is not None:
            lines += ["", "异常信息:", "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))]
        ERROR_LOG.write_text("\n".join(lines), encoding="utf-8")
    except Exception:
        pass


def show_error(title, message):
    """启动阶段尽量不用 Qt，保证 Qt 本身导入失败时也能看到错误。"""
    try:
        ctypes.windll.user32.MessageBoxW(None, str(message), str(title), 0x10)
    except Exception:
        pass


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def restart_as_admin():
    """以管理员权限重新启动当前 main.py。返回 True=当前已管理员，None=已发起重启，False=失败。"""
    if is_admin():
        return True

    script = str(Path(sys.argv[0]).resolve())
    params = subprocess.list2cmdline([script, *sys.argv[1:]])
    workdir = str(BASE_DIR)

    try:
        ret = ctypes.windll.shell32.ShellExecuteW(
            None,
            "runas",
            sys.executable,
            params,
            workdir,
            1,
        )
    except Exception as exc:
        write_startup_error("请求管理员权限时发生异常", exc)
        return False

    if ret <= 32:
        write_startup_error(f"请求管理员权限失败，ShellExecuteW 返回值：{ret}")
        return False

    return None


def main():
    admin_result = restart_as_admin()

    if admin_result is None:
        # 原进程只负责等待管理员进程接管，避免双开。
        return 0

    if admin_result is False:
        show_error(
            "权限不足",
            "程序无法请求管理员权限。\n\n"
            f"详细信息已写入：\n{ERROR_LOG}",
        )
        return 1

    # 到这里已经是管理员进程。
    try:
        os.chdir(BASE_DIR)

        from PySide6.QtWidgets import QApplication
        from PySide6.QtGui import QIcon
        from gui import MainWindow

        app = QApplication(sys.argv)
        app.setApplicationName("句柄上号器")
        app.setApplicationVersion("3.0")
        icon_path = BASE_DIR / "app_icon.ico"
        if icon_path.exists():
            app.setWindowIcon(QIcon(str(icon_path)))

        window = MainWindow()
        if app.windowIcon().isNull() is False:
            window.setWindowIcon(app.windowIcon())
        window.show()
        return app.exec()

    except Exception as exc:
        write_startup_error("主程序初始化失败", exc)
        show_error(
            "句柄上号器启动失败",
            "程序启动时发生错误。\n\n"
            f"{type(exc).__name__}: {exc}\n\n"
            f"完整错误信息已写入：\n{ERROR_LOG}",
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
