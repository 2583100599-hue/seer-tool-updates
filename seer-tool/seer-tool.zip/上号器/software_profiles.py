import json
from pathlib import Path


class SoftwareProfileStore:
    """启动项目只负责保存 软件 EXE + 账号文件。"""
    FIELDS = ("name", "exe", "csv")
    RUNTIME_DEFAULTS = {
        "start_wait": 3, "interval": 2, "concurrency": 1,
        "range_start": 1, "range_end": 1,
        "skip_expired": False, "skip_empty": True,
    }

    def __init__(self, base_dir):
        self.path = Path(base_dir) / "config" / "software_profiles.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = self._load()

    def _clean(self, value):
        if not isinstance(value, dict):
            return None
        name = str(value.get("name", "")).strip()
        exe = str(value.get("exe", "")).strip()
        csv = str(value.get("csv", "")).strip()
        if not name:
            exe_name = Path(exe).stem or "启动项目"
            csv_name = Path(csv).stem
            name = f"{exe_name} - {csv_name}" if csv_name else exe_name
        item = {"name": name, "exe": exe, "csv": csv}
        # 旧版项目只有 name/exe/csv；保留这种格式的兼容性，只有用户保存完整配置后才添加 runtime。
        runtime = value.get("runtime")
        if isinstance(runtime, dict):
            clean_runtime = {}
            for key, default in self.RUNTIME_DEFAULTS.items():
                raw = runtime.get(key, default)
                try:
                    if isinstance(default, bool):
                        if isinstance(raw, str):
                            token = raw.strip().lower()
                            if token in ("1", "true", "yes", "on", "是"):
                                clean_runtime[key] = True
                            elif token in ("0", "false", "no", "off", "否", ""):
                                clean_runtime[key] = False
                            else:
                                clean_runtime[key] = default
                        else:
                            clean_runtime[key] = bool(raw)
                    else:
                        clean_runtime[key] = int(raw)
                except (TypeError, ValueError):
                    clean_runtime[key] = default
            clean_runtime["start_wait"] = max(0, min(300, clean_runtime["start_wait"]))
            clean_runtime["interval"] = max(0, min(300, clean_runtime["interval"]))
            clean_runtime["concurrency"] = max(1, min(32, clean_runtime["concurrency"]))
            clean_runtime["range_start"] = max(1, clean_runtime["range_start"])
            clean_runtime["range_end"] = max(clean_runtime["range_start"], clean_runtime["range_end"])
            item["runtime"] = clean_runtime
        workflow = str(value.get("workflow", "") or "").strip()
        if workflow:
            item["workflow"] = workflow
        return item

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                value = json.load(f)
            if not isinstance(value, list):
                return []
            return [x for x in (self._clean(v) for v in value) if x is not None]
        except Exception:
            return []

    def save(self):
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
        tmp.replace(self.path)

    def upsert(self, profile):
        item = self._clean(profile)
        if not item or not item["name"]:
            raise ValueError("启动项目名称不能为空")
        for i, old in enumerate(self.data):
            if old.get("name") == item["name"]:
                self.data[i] = item
                self.save()
                return
        self.data.append(item)
        self.save()

    def delete(self, name):
        self.data = [x for x in self.data if x.get("name") != name]
        self.save()
